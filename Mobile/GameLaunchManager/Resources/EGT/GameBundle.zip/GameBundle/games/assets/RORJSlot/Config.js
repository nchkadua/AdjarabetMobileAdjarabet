function Config()
{
    this.reelWidth = 132 ;
    this.reelHeight = 396;
    this.reelSpacing = 16;

    this.portraitReelWidth = 96;
    this.portraitReelSpacing = 12;

    this.numImages = 13;
    this.numReels = 5;
    this.numReelCards = 3;
    this.wildIndex = 11;
    this.linesCount = [1, 5, 7, 10, 15];
    this.fixedLinesCount = false;
    this.hasFreespins = true;

    this.coinAnimationCoef = 15;

    this.linesSelectActiveColor = 0xfce702;
    this.linesSelectInactiveColor = 0xb6b2ab;
    this.linesSelectActiveGlowColor = 0x451f00;
    this.linesSelectInactiveGlowColor = 0x01060f;
    this.gameNumberTimeHelpColor = 0xf6cf2a;
    this.labelsColor = 0xe99b14;
    this.paytableExitColor = 0x02323c;
    this.bonusPopUpStrokeColor = 0xf0ac18;

    this.toolTipMainTextColor = 0xFFFFFF;
    this.toolTipUsernameTextColor = 0xe7d271;
    this.toolTipWinAmountTextColor = 0xFFFFFF;
    this.toolTipCurrencyTextColor = 0xe7d271;
    this.toolTipDateTextColor = 0xbfbfbf;
    this.toolTipNumberOfWinnersTextColor = 0xe7d271;
    this.toolTipDateSeparator = "/";

    this.landscapeReelsBackgroundPosition = {x: 56, y: 53}
    this.portraitReelsBackgroundPosition = {x: 3, y: 142}

    this.paytablePageCount = 4;
    this.paytableGamblePage = 1;

    this.portraitGameNameBackgroundColor = '#471401'
    this.gambleBackgroundBorderColor = 0xd79a1f
    this.jackpotBackgroundColorStart = '#000000';
    this.jackpotBackgroundColorEnd = '#b2041e';
    this.jackpotBackgroundBorderColor = '#d79a1f';

    this.scatterConfig  = [
        {index: 12, minCount: 2, freespinMinCount: 3,
            validReels: [ true, true, true, true, true ], freespinVideoIndex: 13, freespinSound: "winScatterFs",
            stopSounds:["stopScatterSound", "stopScatterSound", "stopScatterSound", "stopScatterSound", "stopScatterSound"]}
    ];

    this.reelVideos = [
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        {src:["images/videos/08-0.json"], fps: 7},
        {src:["images/videos/09-0.json"], fps: 7},
        {src:["images/videos/10-0.json"], fps: 12},
        {src:["images/videos/11-0.json"], fps: 7},
        {src:["images/videos/12-0.json"], fps: 7},
        {src:["images/videos/13-0.json"], fps: 7, loopIndex: 17}];

    this.reelImages = ["reelImages.json"];

    this.linesCoords = [
        {coords:[124,256, 835,256], color:0xfff221},
        {coords:[124,124, 835,124], color:0xf9af0c},
        {coords:[124,394, 835,394], color:0x17e614},
        {coords:[124,129, 183,129, 480,402, 775,129, 835,129], color:0xdf3d3d},
        {coords:[124,401, 183,401, 480,116, 775,401, 835,401], color:0xc90404},
        {coords:[124,118, 327,118, 631,387, 835,387], color:0x60bad},
        {coords:[124,387, 337,387, 634,118, 835,118], color:0x1189ba},
        {coords:[124,269, 183,269, 326,400, 644,400, 775,269, 835,269], color:0xc86b07},
        {coords:[124,244, 183,244, 341,117, 624,117, 769,244, 835,244], color:0x3bb108},
        {coords:[124,111, 172,111, 331,262, 627,262, 791,111, 835,111], color:0x4a82f3},
        {coords:[124,380, 199,380, 333,249, 624,249, 759,380, 835,380], color:0xce0089},
        {coords:[124,274, 196,274, 324,394, 629,117, 808,274, 835,274], color:0xce52a1},
        {coords:[124,238, 185,238, 333,118, 645,394, 799,238, 835,238], color:0xaf2dc5},
        {coords:[124,134, 202,134, 329,255, 480,111, 628,256, 761,134, 835,134], color:0x3a9e26},
        {coords:[124,408, 165,408, 326,250, 480,394, 634,252, 794,408, 835,408], color:0x227ab3}
    ];

    this.fullLineSounds = [
        {card:0, name:"fullLine1"}, {card:1, name:"fullLine1"},
        {card:2, name:"fullLine1"}, {card:3, name:"fullLine1"},
        {card:4, name:"fullLine2"}, {card:5, name:"fullLine2"},
        {card:6, name:"fullLine3"}, {card:7, name:"fullLine3"},
        {card:8, name:"fullLine3"}, {card:9, name:"fullLine4"},
        {card:10, name:"fullLine4"}, {card:11, name:"fullLine4"}];

    this.gameSounds = [
        {
            src: "shortSounds.mp3", sounds:[
                {name: "reelAccelerateSound", start:1.7, duration: 1.9},
                {name: "stopScatterSound", start:0, duration: 1.4}]
        },
        {
            src: "winSounds.mp3", sounds:[
                {name: "win8", start:0, duration: 4.1},
                {name: "win9", start:5, duration: 3.7},
                {name: "win10", start:9, duration: 4.95},
                {name: "win11", start:14, duration: 1.5},
                {name: "win12", start:16, duration: 5.2},
                {name: "winScatterFs", start:23, duration: 8.5},
                {name: "creditAnimationSound", start:32, duration: 10.0}]
        }];

    this.freespinSounds = [
        {
            src: "freespinSounds.mp3", id: "freespinSounds", sounds:[
                {name: "pressStartSound", start:0, duration: 8},
                {name: "introSound", start:9, duration: 14.2},
                {name: "outroSound", start:24, duration: 12.4},
                {name: "doorOpenSound", start:37, duration: 3.03},
                {name: "doorHitSound", start:41, duration: 2.28},
                {name: "doorCloseSound", start:53, duration: 3.03},
                {name: "freeSpinsBackgroundSound", start:45 , duration: 7.6}]
        }];

    this.helpLanguages = ["en", "bg", "ro", "es", "pt", "it", "da","sv", 'cs'];
    this.paytableLanguages = ['en', 'bg', 'ru', 'mk', 'fr', 'nl', 'es','ro', "pt", 'it','da','hu', 'sv', 'de', 'cs'];
    this.freespinLanguages = ['en', 'bg', 'ru', 'mk', 'fr', 'nl', 'es', 'ro', 'pt', 'it', 'da', 'hu', 'sv', 'de'];
}

window["egtGlobal"].Config = Config;