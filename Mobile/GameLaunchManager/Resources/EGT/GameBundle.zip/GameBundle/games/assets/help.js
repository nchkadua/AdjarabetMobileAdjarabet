function configureHelp(rtp, currencyISO, shouldHideStopAll, hasAutoplayLimit, hasTotalsInfo, jackpotAllowed, lineGame, gameVersion,
                       isAutoplayDisabled, currencyDoNotDisplayCredits, minBet, maxBet, qBets, language, scarabJackpot) {
    var autoplayLimitLink = document.getElementById("autoplayLimitLink")
    if (autoplayLimitLink != null) {
        autoplayLimitLink.parentNode.removeChild(autoplayLimitLink)
    }

    if (currencyDoNotDisplayCredits)
        removeElementsByClass("displayCredits");
    else
        removeElementsByClass("doNotDisplayCredits");

    if (gameVersion != "") {
        var versionDiv = document.createElement("div");
        versionDiv.textContent = gameVersion;
        document.getElementById("HelpContent").appendChild(versionDiv);
    }

    if (rtp != null)
        document.getElementById("rtp").textContent = rtp + "%";
    else {
        var rtpLink = document.getElementById("rtp_link");
        rtpLink.parentNode.removeChild(rtpLink);
        var returnToPlayer = document.getElementById("return_to_player");
        var rtpParagraph = document.getElementById("rtp_paragraph");

        returnToPlayer.parentNode.removeChild(returnToPlayer);
        rtpParagraph.parentNode.removeChild(rtpParagraph);
    }

    var suffix = currencyISO == "EGT" ? currencyISO : "";

    var denominationImage = document.getElementById("DenomImage");
    denominationImage.src = (currencyDoNotDisplayCredits) ? "games/assets/helpImages/noCreditButton.png" : "games/assets/helpImages/" + language + "/denomButton" + suffix + ".png";
    var betButtonImage = document.getElementById("BetButtonImage");
    betButtonImage.src = "games/assets/helpImages/" + "/activebet" + suffix + ".png";

    var paylinesImage = document.getElementById("PaylinesImage");
    if (lineGame) {
        paylinesImage.src = "games/assets/helpImages/" + "/activelines.png";
    } else {
        paylinesImage.src = "games/assets/helpImages/" + "/activeways.png";
    }

    configureResponsibleGaming(shouldHideStopAll, hasAutoplayLimit, hasTotalsInfo);

    configureMinMaxBet(minBet, maxBet);

    if (isAutoplayDisabled) {
        var betTableRow = betButtonImage.parentNode.parentNode;
        var startAutoplayTableRow = betTableRow.nextElementSibling;
        var stopAutoplayTableRow = startAutoplayTableRow.nextElementSibling;
        startAutoplayTableRow.parentNode.removeChild(startAutoplayTableRow);
        stopAutoplayTableRow.parentNode.removeChild(stopAutoplayTableRow);

        var node = document.getElementById("autoplayMode");
        if (node)
            node.parentNode.removeChild(node);

        node = document.getElementById("autoplaySettingsRow");
        if (node)
            node.parentNode.removeChild(node);

        node = document.getElementById("autoplayInSettings");
        if (node)
            node.parentNode.removeChild(node);

        node = document.getElementById("autoplayInExit");
        if (node)
            node.parentNode.removeChild(node);
    } else {
        var node = document.getElementById("noAutoplayInSettings");
        if (node)
            node.parentNode.removeChild(node);

        node = document.getElementById("noAutoplayInExit");
        if (node)
            node.parentNode.removeChild(node);
    }

    configureJackpot(jackpotAllowed, scarabJackpot, qBets);
}

function removeElementsByClass(className) {
    var elements = document.getElementsByClassName(className);
    while (elements.length > 0) {
        elements[0].parentNode.removeChild(elements[0]);
    }
}

function configureResponsibleGaming(shouldHideStopAll, hasAutoplayLimit, hasTotalsInfo) {
    if (!hasAutoplayLimit) {
        if (!hasAutoplayLimit && !hasTotalsInfo) {
            var responsibleGaming = document.getElementById("responsibleGaming");
            responsibleGaming.parentNode.removeChild(responsibleGaming);
            var responsibleGamingLink = document.getElementById("responsibleGamingLink");
            responsibleGamingLink.parentNode.removeChild(responsibleGamingLink.nextSibling);
            responsibleGamingLink.parentNode.removeChild(responsibleGamingLink);
        } else {
            var autoplayLimit = document.getElementById("autoplayLimit");
            autoplayLimit.parentNode.removeChild(autoplayLimit);
        }

        // TODO: Remove comment lines when autoplay logic in line 3, 4, 5
        // is deleted

        // var autoplayLimitLink = document.getElementById("autoplayLimitLink");
        // autoplayLimitLink.parentNode.removeChild(autoplayLimitLink);
    } else if (!hasTotalsInfo) {
        var totalsInfo = document.getElementById("totalsInfo");
        totalsInfo.parentNode.removeChild(totalsInfo);
    }
}

function configureMinMaxBet(minBet, maxBet) {
    var minMaxBet = document.getElementById("minMaxBet")
    if (minMaxBet) {
        minMaxBet.textContent = minBet + " / " + maxBet;
    }
}

function configureJackpot(jackpotAllowed, scarabJackpot, qBets) {
    var jackpotCardsLink = document.getElementById("jackpotCardsLink");
    var jackpotCardsParagraph = document.getElementById("jackpotCardsParagraph");
    var scarabJackpotLink = document.getElementById("scarabJackpotLink");
    var scarabJackpotParagraph = document.getElementById("scarabJackpotParagraph");

    if (jackpotAllowed) {
        if (!scarabJackpot) {
            var qBetsElement = document.getElementById("qBets");
            qBetsElement.textContent = qBets;
            if (scarabJackpotLink) {
                scarabJackpotLink.parentNode.removeChild(scarabJackpotLink);
            }

            if (scarabJackpotParagraph) {
                scarabJackpotParagraph.parentNode.removeChild(scarabJackpotParagraph);
            }
        } else {
            if (scarabJackpotLink) {
                var qBetsSJ = document.getElementById("qBetsSJ");
                qBetsSJ.textContent = qBets;
            }
            jackpotCardsLink.parentNode.removeChild(jackpotCardsLink);
            jackpotCardsParagraph.parentNode.removeChild(jackpotCardsParagraph);
        }


        var bonusesLink = document.getElementById("bonusesLink");
        var bonusesParagraph = document.getElementById("bonusesParagraph");
        if (bonusesLink) {
            bonusesLink.parentNode.removeChild(bonusesLink);
            bonusesParagraph.parentNode.removeChild(bonusesParagraph);
        }

        var bonusesLinkText = document.getElementById("bonusesLinkText");
        var bonusesHeadingText = document.getElementById("bonusesHeadingText");
        var bonusesFirstSentence = document.getElementById("bonusesFirstSentence");
        if (bonusesLinkText) {
            bonusesLinkText.parentNode.removeChild(bonusesLinkText);
            bonusesHeadingText.parentNode.removeChild(bonusesHeadingText);
            bonusesFirstSentence.parentNode.removeChild(bonusesFirstSentence);
        }

    } else {
        if (scarabJackpotLink) {
            scarabJackpotLink.parentNode.removeChild(scarabJackpotLink);
            scarabJackpotParagraph.parentNode.removeChild(scarabJackpotParagraph);
        }
        jackpotCardsLink.parentNode.removeChild(jackpotCardsLink);
        jackpotCardsParagraph.parentNode.removeChild(jackpotCardsParagraph);

        var freespinsLinkText = document.getElementById("freespinsLinkText");
        var freespinsHeadingText = document.getElementById("freespinsHeadingText");
        if (freespinsLinkText) {
            freespinsLinkText.parentNode.removeChild(freespinsLinkText);
            freespinsHeadingText.parentNode.removeChild(freespinsHeadingText);
        }
    }
}