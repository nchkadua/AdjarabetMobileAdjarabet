function Config()
{
    this.reelWidth = 132 ;
    this.reelHeight = 396;
    this.reelSpacing = 16;

    this.portraitReelWidth = 96;
    this.portraitReelSpacing = 12;

    this.numImages = 11
    this.numReels = 5;
    this.numReelCards = 4;
    this.wildIndex = 9;
    this.linesCount = [1, 10, 20, 30, 50];
    this.hasFreespins = true;
    this.coinAnimationCoef = 20;
    this.linesSelectActiveColor = 0xfffe00;
    this.linesSelectInactiveColor = 0xffffff;
    this.linesSelectActiveGlowColor = 0xbd0000;
    this.linesSelectInactiveGlowColor = 0x241d24;
    this.gameNumberTimeHelpColor = 0xc38602;
    this.labelsColor = 0xc38602;
    this.toolTipMainTextColor = 0xFFFFFF;
    this.toolTipUsernameTextColor = 0xc38602;
    this.toolTipWinAmountTextColor = 0xFFFFFF;
    this.toolTipCurrencyTextColor = 0xc38602;
    this.toolTipDateTextColor = 0xbfbfbf;
    this.toolTipNumberOfWinnersTextColor = 0xc38602;
    this.toolTipDateSeparator = "/";
    this.paytablePageCount = 5;
    this.paytableGamblePage = 2;
    
    this.landscapeReelsBackgroundPosition = {x: 55, y: 59}
    this.portraitReelsBackgroundPosition = {x: 6, y: 145}

    this.landscapeReelBorderPosition = {x: 111, y: 50}
    this.portraitReelBorderPosition = {x: 4, y: 142}

    this.portraitGameNameBackgroundColor = '#005309'
    this.gambleBackgroundBorderColor = 0xc28602
    this.jackpotBackgroundColorStart = '#000000'
    this.jackpotBackgroundColorEnd = '#b57513'
    this.jackpotBackgroundBorderColor = '#c28602'

    this.bonusPopUpStrokeColor = 0xc08500;

    this.scatterConfig  = [
        {index: 10, minCount: 10, freespinMinCount: 10, maxScattersOnReel: 4, freespinMinCountInFs: -1,
            validReels: [ false, true, true, true, false ], freespinVideoIndex: 10, freespinSound: "winScatterFs",
            stopSounds:[null , "stopScatterSound2", "stopScatterSound3", "stopScatterSound4", null]}
    ];
    this.reelVideos = [
        {src:["images/videos/00-0.json"], fps: 18},
        {src:["images/videos/01-0.json"], fps: 18},
        {src:["images/videos/02-0.json"], fps: 18},
        {src:["images/videos/03-0.json"], fps: 18},
        {src:["images/videos/04-0.json"], fps: 18},
        {src:["images/videos/05-0.json"], fps: 18},
        {src:["images/videos/06-0.json"], fps: 18},
        {src:["images/videos/07-0.json"], fps: 18},
        {src:["images/videos/08-0.json"], fps: 18},
        {src:["images/videos/09-0.json", "images/videos/09-1.json"], fps: 18},
        {
            top: {
                src:["images/videos/10top-0.json", "images/videos/10top-1.json"], fps: 17
            }
        }]
    this.reelImages = ["reelImages.json", "reelImages_1.json"];
    this.linesCoords = [
        {coords:[124,206, 835,206], color:0xc170c2},
        {coords:[124,308, 835,308], color:0xe0a23d},
        {coords:[124,109, 835,109], color:0xac53a1},
        {coords:[124,404, 835,404], color:0x4cc3b9},
        {coords:[124,211, 197,211, 477,397, 762,211, 835,211], color:0xb8d1da},
        {coords:[124,302, 197,302, 477,117, 762,302, 835,302], color:0x5ec5df},
        {coords:[124,105, 322,105, 768,399, 835,399], color:0xd2cfbf},
        {coords:[124,409, 322,409, 768,114, 835,114], color:0xa16a5f},
        {coords:[124,312, 190,312, 340,409, 614,409, 762,312, 835,312], color:0xd579e1},
        {coords:[124,201, 187,201, 334,105, 618,105, 772,201, 835,201], color:0x7ac496},
        {coords:[124,115, 187,115, 627,409, 835,409], color:0xc7c8e3},
        {coords:[124,399, 187,399, 630,105, 835,105], color:0x8f63c6},
        {coords:[124,298, 181,298, 340,402, 623,215, 777,316, 835,316], color:0xa780d8},
        {coords:[124,214, 179,214, 340,109, 622,296, 773,197, 835,197], color:0xfa668d},
        {coords:[124,100, 176,100, 333,206, 477,109, 621,203, 777,100, 835,100], color:0x957812},
        {coords:[124,414, 176,414, 333,308, 477,403, 621,309, 780,414, 835,414], color:0xd84950},
        {coords:[124,197, 184,197, 333,295, 624,102, 803,216, 835,216], color:0x9bdef8},
        {coords:[124,316, 180,316, 333,218, 622,411, 797,297, 835,297], color:0xa454b8},
        {coords:[124,95, 178,95, 330,200, 616,200, 776,95, 835,95], color:0xb8dc50},
        {coords:[124,417, 178,417, 336,311, 616,311, 779,417, 835,417], color:0xdebe36},
        {coords:[124,192, 315,192, 653,421, 835,421], color:0x4463e5},
        {coords:[124,319, 317,319, 660,92, 835,92], color:0xb6c7f3},
        {coords:[124,119, 183,119, 453,301, 627,301, 770,394, 835,394], color:0xcb712},
        {coords:[124,394, 186,394, 463,210, 630,210, 771,118, 835,118], color:0xd6e3d7},
        {coords:[124,218, 197,218, 323,301, 635,301, 772,390, 835,390], color:0xe0a47e},
        {coords:[124,294, 198,294, 326,210, 637,210, 772,121, 835,121], color:0x77847e},
        {coords:[124,92, 320,92, 475,194, 637,87, 835,87], color:0x9b9f0d},
        {coords:[124,421, 318,421, 475,317, 637,424, 835,424], color:0xd2b267},
        {coords:[124,324, 350,324, 477,407, 610,320, 835,320], color:0x8c79b8},
        {coords:[124,188, 352,188, 477,105, 611,192, 835,192], color:0x71b4e8},
        {coords:[124,86, 457,86, 769,291, 835,291], color:0xe2aec3},
        {coords:[124,424, 457,424, 769,219, 835,219], color:0x3eaec8},
        {coords:[124,327, 207,327, 336,413, 481,413, 770,223, 835,223], color:0x784eb2},
        {coords:[124,184, 205,184, 333,100, 487,100, 771,287, 835,287], color:0x1f7c94},
        {coords:[124,122, 180,122, 318,215, 506,215, 769,387, 835,387], color:0x99c6d4},
        {coords:[124,390, 184,390, 322,297, 508,297, 775,125, 835,125], color:0xc781d3},
        {coords:[124,290, 180,290, 352,404, 775,128, 835,128], color:0x98a9db},
        {coords:[124,221, 173,221, 351,106, 771,382, 835,382], color:0x708cb5},
        {coords:[124,121, 178,121, 629,409, 755,323, 835,323], color:0x128bcd},
        {coords:[124,387, 188,387, 625,95, 769,189, 835,189], color:0x5fcefe},
        {coords:[124,183, 180,183, 333,299, 481,87, 624,404, 769,179, 835,179], color:0x677b96},
        {coords:[124,304, 181,303, 328,200, 474,408, 619,104, 769,305, 835,305], color:0xb64d4e},
        {coords:[124,95, 180,95, 327,209, 467,404, 620,302, 766,100, 835,100], color:0xb8adcd},
        {coords:[124,407, 182,407, 351,305, 471,102, 625,201, 775,410, 835,410], color:0x1b52a5},
        {coords:[124,202, 178,202, 330,202, 475,311, 623,104, 773,407, 835,407], color:0x95304},
        {coords:[124,301, 182,301, 328,301, 475,204, 623,406, 769,102, 835,102], color:0x764cb9},
        {coords:[124,198, 176,198, 328,310, 470,403, 623,100, 773,210, 835,210], color:0x73875},
        {coords:[124,304, 182,304, 329,200, 473,99, 626,408, 773,304, 835,304], color:0x1fb51b},
        {coords:[124,302, 181,302, 327,396, 474,200, 623,406, 765,102, 835,102], color:0x941614},
        {coords:[124,199, 182,199, 331,99, 474,305, 623,102, 770,403, 835,403], color:0xcc2e78},
    ];
    this.fullLineSounds = [
        {card:0, name:"fullLine1"}, {card:1, name:"fullLine1"},
        {card:2, name:"fullLine1"}, {card:3, name:"fullLine1"},
        {card:4, name:"fullLine2"}, {card:5, name:"fullLine2"},
        {card:6, name:"fullLine2"}, {card:7, name:"fullLine3"},
        {card:8, name:"fullLine3"}, {card:9, name:"fullLine4"},
        {card:10, name:"fullLine4"}];
    this.gameSounds = [
        {
            src: "shortSounds.mp3", sounds:[
            {name: "reelAccelerateSound", start:3, duration: 2.074},
            {name: "stopScatterSound2", start:0, duration: 0.939},
            {name: "stopScatterSound3", start:1, duration: 0.925},
            {name: "stopScatterSound4", start:2, duration: 0.931}]
        },
        {
            src: "winSounds.mp3", sounds:[
            {name: "win4", start:0, duration: 3.9},
            {name: "win5", start:5, duration: 3},
            {name: "win6", start:9, duration: 3.2},
            {name: "win7", start:19, duration: 4.3},
            {name: "win8", start:13, duration: 5.2},
            {name: "win9", start:24, duration: 6.3},
            {name: "winScatterFs", start:31, duration: 10.94},
            {name: "creditAnimationSound", start:43, duration: 10.0}]
        }];
    this.freespinSounds = [
        {
            src: "freespinSounds.mp3", id: "freespinSounds", sounds:[
            {name: "pressStartSound", start:0, duration: 8},
            {name: "introSound", start:9, duration: 6},
            {name: "outroSound", start:17, duration: 7},
            {name: "freeSpinsBackgroundSound", start:25 , duration: 9.6}]
        }];
        this.helpLanguages = ["en", "bg", "ro", "es"];
        this.paytableLanguages = ['en', 'bg', 'ru', 'mk', 'fr', 'nl', 'es', 'ro', 'hu', 'pt', 'da'];
        this.freespinLanguages = ['en', 'bg', 'ru', 'mk', 'fr', 'nl', 'es', 'ro', 'hu', 'pt', 'da'];
}

window["egtGlobal"].Config = Config;
