function Config()
{
    this.reelWidth = 132 ;
    this.reelHeight = 396;
    this.reelSpacing = 16;

    this.portraitReelWidth = 96;
    this.portraitReelSpacing = 12;

    this.numImages = 11;
    this.numReels = 5;
    this.numReelCards = 3;
    this.wildIndex = 8;
    this.linesCount = [1, 3, 5, 7, 10];
    this.fixedLinesCount = true;

    this.coinAnimationCoef = 25;

    this.linesSelectActiveColor = 0xf08947;
    this.linesSelectInactiveColor = 0xffffff;
    this.linesSelectActiveGlowColor = 0x671300;
    this.linesSelectInactiveGlowColor = 0x01060f;
    this.gameNumberTimeHelpColor = 0xcea349;
    this.labelsColor = 0xcec51b;
    this.paytableExitColor = 0x472403;
    this.bonusPopUpStrokeColor = 0xcec51b;

    this.toolTipMainTextColor = 0xFFFFFF;
    this.toolTipUsernameTextColor = 0xcec51b;
    this.toolTipWinAmountTextColor = 0xFFFFFF;
    this.toolTipCurrencyTextColor = 0xcec51b;
    this.toolTipDateTextColor = 0xbfbfbf;
    this.toolTipNumberOfWinnersTextColor = 0xcec51b;
    this.toolTipDateSeparator = "/";

    this.landscapeReelsBackgroundPosition = {x: 57, y: 54}
    this.portraitReelsBackgroundPosition = {x: 3, y: 142}

    this.paytablePageCount = 4;
    this.paytableGamblePage = 1;

    this.portraitGameNameBackgroundColor = '#500100'
    this.gambleBackgroundBorderColor = 0xc1b916
    this.jackpotBackgroundColorStart = '#000000';
    this.jackpotBackgroundColorEnd = '#7a1700';
    this.jackpotBackgroundBorderColor = '#c1b916';

    this.scatterConfig  = [
        {index: 9, minCount: 3, validReels: [ true, false, true, false, true ],
            stopSounds:["stopStar1", null, "stopStar2", null, "stopStar3"]},
        {index: 10, minCount: 3, validReels: [ true, true, true, true, true ],
            stopSounds:["stopDollar1", "stopDollar2", "stopDollar3", "stopDollar4", "stopDollar5"]}];

    this.reelVideos = [
        {src:["images/videos/00-0.json"], fps: 8, loopIndex: 30},
        {src:["images/videos/01-0.json"], fps: 8, loopIndex: 30},
        {src:["images/videos/02-0.json"], fps: 8, loopIndex: 30},
        {src:["images/videos/03-0.json"], fps: 8, loopIndex: 30},
        {src:["images/videos/04-0.json"], fps: 8, loopIndex: 30},
        {src:["images/videos/05-0.json"], fps: 8, loopIndex: 30},
        {src:["images/videos/06-0.json"], fps: 8, loopIndex: 30},
        {src:["images/videos/07-0.json"], fps: 8, loopIndex: 30},
        {src:["images/videos/08-0.json"], fps: 8, loopIndex: 30},
        {src:["images/videos/09-0.json"], fps: 8, loopIndex: 30},
        {src:["images/videos/10-0.json"], fps: 8, loopIndex: 30}];

    this.expandVideo = {src:["images/videos/expand-0.json", "images/videos/expand-1.json"], fps: 14};

    this.reelImages = ["reelImages.json"];

    this.linesCoords = [
        {coords:[124,256, 835,256], color:0xfff221},
        {coords:[124,124, 835,124], color:0xf9af0c},
        {coords:[124,394, 835,394], color:0x17e614},
        {coords:[124,129, 183,129, 480,402, 775,129, 835,129], color:0xdf3d3d},
        {coords:[124,401, 183,401, 480,116, 775,401, 835,401], color:0xc90404},
        {coords:[124,118, 327,118, 631,387, 835,387], color:0x60bad},
        {coords:[124,387, 337,387, 634,118, 835,118], color:0x1189ba},
        {coords:[124,269, 183,269, 326,400, 644,400, 775,269, 835,269], color:0xc86b07},
        {coords:[124,244, 183,244, 341,117, 624,117, 769,244, 835,244], color:0x3bb108},
        {coords:[124,111, 172,111, 331,262, 627,262, 791,111, 835,111], color:0x4a82f3}
    ];

    this.fullLineSounds = [
        {"card":0, name:"fullLine1"}, {"card":1, name:"fullLine1"},
        {"card":2, name:"fullLine1"}, {"card":3, name:"fullLine1"},
        {"card":4, name:"fullLine2"}, {"card":5, name:"fullLine3"},
        {"card":6, name:"fullLine3"}, {"card":7, name:"fullLine4"},
        {"card":8, name:"fullLine4"}];

    this.gameSounds = [
        {
            src: "shortSounds.mp3", sounds:[
                {name: "stopWildSound", start:0, duration: 0.6},
                {name: "stopDollar1", start:2, duration: 0.7},
                {name: "stopDollar2", start:4,duration: 0.75},
                {name: "stopDollar3", start:6, duration: 0.8},
                {name: "stopDollar4", start:8, duration: 0.7},
                {name: "stopDollar5", start:10, duration: 0.75},
                {name: "stopStar1", start:12, duration: 1.5},
                {name: "stopStar2", start:14, duration: 1.55},
                {name: "stopStar3", start:16, duration: 1.35}]
        },
        {
            src: "winSounds.mp3", sounds:[
                {name: "win0", start:3,	duration: 2.3},
                {name: "win1", start:16, duration: 1.4},
                {name: "win2", start:18, duration: 1.4},
                {name: "win3", start:20, duration: 2},
                {name: "win4", start:0, duration: 2.3},
                {name: "win5", start:13, duration: 2.2},
                {name: "win6", start:33, duration: 3},
                {name: "win7", start:37, duration: 2.7},
                {name: "win9", start:28, duration: 4.4},
                {name: "win10", start:11, duration: 1.7},
                {name: "creditAnimationSound", start:41, duration: 10.0},
                {name: "expandSound", start:6, duration: 4.4}]
        }];

    this.helpLanguages = ["en", "bg", "ro", "es", "pt", "it", "da", "sv", 'cs'];
    this.paytableLanguages = ['en', 'bg', 'ru', 'mk', 'fr', 'nl', 'es','ro', "pt", 'it','da','hu','sv','de', 'cs'];
}

window["egtGlobal"].Config = Config;