
function setPaytableContent(paytableCoeficients, denominations, currDenomIndex, betPerLine, totalBet, jackpotMinBet, jackpotMaxBet, currencyType, diamondPlay, currency, noCoins, Device, Utils, jackpotType)
{
	var div;
	for(var index in paytableCoeficients)
	{
		var len = paytableCoeficients[index].coef.length;
		for(var i = 0;i < len;i++)
		{
			div = $("#LineContent"+i+"-"+index);
			if(!div[0])
				continue;
				
			var bet;
			if(index == 9 || index == 10)
				bet = totalBet;
			else
				bet = betPerLine;

			if(currency)
				div[0].innerHTML = Utils.formatMoney(bet*paytableCoeficients[index].coef[i], 100, !diamondPlay, noCoins) + " " + "<span class='currency'>"+currencyType+"</span>";
			else
				div[0].innerHTML = Utils.formatMoney(bet*paytableCoeficients[index].coef[i], denominations[currDenomIndex][0]);
		}
	}
	
	var maxGambleAmount = Math.min(denominations[currDenomIndex][2], denominations[currDenomIndex][1] * totalBet) / 2;
	div = $("#GambleTextLine");
	if(currency)
		div[0].innerHTML = Utils.formatMoney(maxGambleAmount, 100, !diamondPlay, noCoins) + " " + "<span class='jackpotGambleCurrency'>"+currencyType+"</span>";
	else
		div[0].innerHTML = Utils.formatMoney(maxGambleAmount, denominations[currDenomIndex][0]);
	
	div = $("#JackpotTextLine");
	if( div[0] ) {
		if(currency)
			div[0].innerHTML = Utils.formatMoney(jackpotMinBet, 100, !diamondPlay, noCoins) + " " + "<span class='jackpotGambleCurrency'>"+currencyType+"</span>" + " - " +
							Utils.formatMoney(jackpotMaxBet, 100, !diamondPlay, noCoins) + " " + "<span class='jackpotGambleCurrency'>"+currencyType+"</span>";
		else
			div[0].innerHTML = Utils.formatMoney(jackpotMinBet, denominations[currDenomIndex][0]) + " - " + Utils.formatMoney(jackpotMaxBet, denominations[currDenomIndex][0]);
	}

	div = $("#ScarabJackpotTextLine");
	if( div[0] ) {
		if(currency)
			div[0].innerHTML = Utils.formatMoney(jackpotMinBet, 100, !diamondPlay, noCoins) + " " + "<span class='jackpotGambleCurrency'>"+currencyType+"</span>" + " - " +
							Utils.formatMoney(jackpotMaxBet, 100, !diamondPlay, noCoins) + " " + "<span class='jackpotGambleCurrency'>"+currencyType+"</span>";
		else
			div[0].innerHTML = Utils.formatMoney(jackpotMinBet, denominations[currDenomIndex][0]) + " - " + Utils.formatMoney(jackpotMaxBet, denominations[currDenomIndex][0]);
	}
	
	if( jackpotType === 'ScarabJackpot' ) {
		const jp = document.querySelector('#jackpot');
		if( jp ) jp.remove();
	} else {
		const jpScarab = document.querySelector('#jackpotSJ');
		if( jpScarab ) jpScarab.remove();
	}

	if(Device.isiOS)
	{
		$("#PaytableContent .paytableLine").addClass("iOS");
		$("#PaytableContent .textLine.lineContent").addClass("iOS");
		$("#PaytableContent .paytableLine.firstLine.seven").addClass("iOS");

	}
}