var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var gpts;
(function (gpts) {
    var services;
    (function (services) {
        var Message = (function () {
            function Message(command, qName) {
                if (command === void 0) { command = null; }
                if (qName === void 0) { qName = null; }
                this._data = {};
                this.command = command;
                this.qName = qName;
            }
            Message.prototype.encode = function () {
                var that = this;
                return JSON.stringify(this, function (k, v) {
                    if (k === '_data')
                        return undefined;
                    return v;
                });
            };
            Message.prototype.getData = function () {
                return this._data;
            };
            Message.prototype.setData = function (data) {
                this._data = data;
                var keys = Object.keys(this._data);
                for (var _i = 0, keys_1 = keys; _i < keys_1.length; _i++) {
                    var name = keys_1[_i];
                    try {
                        if (this[name] instanceof Message)
                            this[name].setData(this._data[name]);
                        else
                            this[name] = this._data[name];
                    }
                    catch (error) {
                    }
                }
                return this;
            };
            Message.prototype.toString = function () {
                return '{ messageId: ' + this.messageId + ', command: ' + this.command + ', qName: ' + this.qName + '}';
            };
            return Message;
        }());
        services.Message = Message;
    })(services = gpts.services || (gpts.services = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var services;
    (function (services) {
        var messages;
        (function (messages) {
            var response;
            (function (response) {
                var trace = gamy.trace;
                var BaseResponse = (function (_super) {
                    __extends(BaseResponse, _super);
                    function BaseResponse(command, eventTimestamp, msg, complex, reason, qName) {
                        if (command === void 0) { command = null; }
                        if (eventTimestamp === void 0) { eventTimestamp = -1; }
                        if (msg === void 0) { msg = null; }
                        if (complex === void 0) { complex = null; }
                        if (reason === void 0) { reason = null; }
                        if (qName === void 0) { qName = null; }
                        var _this = _super.call(this, command, qName) || this;
                        _this.eventTimestamp = eventTimestamp;
                        _this.msg = msg;
                        _this.complex = complex;
                        _this.reason = reason;
                        return _this;
                    }
                    BaseResponse.prototype.toString = function () {
                        var result = _super.prototype.toString.call(this);
                        return result.substr(0, result.length - 1).concat(', eventTimestamp: ' + this.eventTimestamp + ', msg: ' + this.msg + ', complex: ' + this.complex.toString() + ', reason: ' + this.reason + '}');
                    };
                    BaseResponse.prototype.setData = function (data) {
                        _super.prototype.setData.call(this, data);
                        trace(gpts.ELogger.MAPPING, '\nJSON: ' + data.toString() + '\nMAP WITH: ' + this.constructor.className);
                        return this;
                    };
                    BaseResponse.className = 'gpts.services.messages.response.BaseResponse';
                    return BaseResponse;
                }(services.Message));
                response.BaseResponse = BaseResponse;
            })(response = messages.response || (messages.response = {}));
        })(messages = services.messages || (services.messages = {}));
    })(services = gpts.services || (gpts.services = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var services;
    (function (services) {
        var messages;
        (function (messages) {
            var response;
            (function (response) {
                var LoginResponse = (function (_super) {
                    __extends(LoginResponse, _super);
                    function LoginResponse(command, eventTimestamp, msg, complex, reason, balance, playerName, currency, languages, qName, groups, showRtp, multigame, autoplayLimit, minimumSpinTime, sendTotalsInfo) {
                        if (command === void 0) { command = null; }
                        if (eventTimestamp === void 0) { eventTimestamp = -1; }
                        if (msg === void 0) { msg = null; }
                        if (complex === void 0) { complex = null; }
                        if (reason === void 0) { reason = null; }
                        if (balance === void 0) { balance = -1; }
                        if (playerName === void 0) { playerName = null; }
                        if (currency === void 0) { currency = null; }
                        if (languages === void 0) { languages = null; }
                        if (qName === void 0) { qName = null; }
                        if (groups === void 0) { groups = null; }
                        if (showRtp === void 0) { showRtp = null; }
                        if (multigame === void 0) { multigame = true; }
                        if (autoplayLimit === void 0) { autoplayLimit = null; }
                        if (minimumSpinTime === void 0) { minimumSpinTime = 0; }
                        if (sendTotalsInfo === void 0) { sendTotalsInfo = false; }
                        var _this = _super.call(this, command, eventTimestamp, msg, complex, reason, qName) || this;
                        _this.balance = balance;
                        _this.playerName = playerName;
                        _this.currency = currency;
                        _this.languages = languages;
                        _this.groups = groups;
                        _this.showRtp = showRtp;
                        _this.multigame = multigame;
                        _this.autoplayLimit = autoplayLimit;
                        _this.minimumSpinTime = minimumSpinTime;
                        _this.sendTotalsInfo = sendTotalsInfo;
                        return _this;
                    }
                    LoginResponse.prototype.toString = function () {
                        var result = _super.prototype.toString.call(this);
                        return result.substr(0, result.length - 1).concat(', balance: ' + this.balance + ', playerName: ' + this.playerName + ', currency: ' + this.currency + ', languages: ' + this.languages + ', groups: ' + this.groups + ', showRtp: ' + this.showRtp + ', multigame: ' + this.multigame + ', autoplayLimit: ' + this.autoplayLimit + ', minimumSpinTime: ' + this.minimumSpinTime + ', sendTotalsInfo: ' + this.sendTotalsInfo + '}');
                    };
                    LoginResponse.className = 'gpts.services.messages.response.LoginResponse';
                    return LoginResponse;
                }(response.BaseResponse));
                response.LoginResponse = LoginResponse;
            })(response = messages.response || (messages.response = {}));
        })(messages = services.messages || (services.messages = {}));
    })(services = gpts.services || (gpts.services = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Reflection = (function () {
        function Reflection() {
        }
        Reflection.prototype.toString = function () {
            return 'Reflection';
        };
        return Reflection;
    }());
    gpts.Reflection = Reflection;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var services;
    (function (services) {
        var messages;
        (function (messages) {
            var request;
            (function (request) {
                var BaseRequest = (function (_super) {
                    __extends(BaseRequest, _super);
                    function BaseRequest(command, sessionKey, qName) {
                        if (command === void 0) { command = null; }
                        if (sessionKey === void 0) { sessionKey = null; }
                        if (qName === void 0) { qName = null; }
                        var _this = _super.call(this, command, qName) || this;
                        _this.sessionKey = sessionKey;
                        return _this;
                    }
                    BaseRequest.prototype.toString = function () {
                        var result = _super.prototype.toString.call(this);
                        return result.substr(0, result.length - 1).concat(', sessionKey: ' + this.sessionKey + '}');
                    };
                    return BaseRequest;
                }(services.Message));
                request.BaseRequest = BaseRequest;
            })(request = messages.request || (messages.request = {}));
        })(messages = services.messages || (services.messages = {}));
    })(services = gpts.services || (gpts.services = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var services;
    (function (services) {
        var messages;
        (function (messages) {
            var request;
            (function (request) {
                var GameRequest = (function (_super) {
                    __extends(GameRequest, _super);
                    function GameRequest(command, sessionKey, gameIdentificationNumber, gameNumber, qName) {
                        if (command === void 0) { command = null; }
                        if (sessionKey === void 0) { sessionKey = null; }
                        if (gameIdentificationNumber === void 0) { gameIdentificationNumber = NaN; }
                        if (gameNumber === void 0) { gameNumber = -1; }
                        if (qName === void 0) { qName = null; }
                        var _this = _super.call(this, command, sessionKey, qName) || this;
                        _this.gameIdentificationNumber = gameIdentificationNumber;
                        _this.gameNumber = gameNumber;
                        return _this;
                    }
                    GameRequest.prototype.toString = function () {
                        var result = _super.prototype.toString.call(this);
                        return result.substr(0, result.length - 1).concat(', gameIdentificationNumber: ' + this.gameIdentificationNumber + ', gameNumber: ' + this.gameNumber + '}');
                    };
                    return GameRequest;
                }(request.BaseRequest));
                request.GameRequest = GameRequest;
            })(request = messages.request || (messages.request = {}));
        })(messages = services.messages || (services.messages = {}));
    })(services = gpts.services || (gpts.services = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var GameData = (function () {
            function GameData(balance, language, settings, command, bets, looseConnection, iData, currency, languages, currencyISO) {
                if (balance === void 0) { balance = NaN; }
                if (language === void 0) { language = null; }
                if (settings === void 0) { settings = null; }
                if (command === void 0) { command = null; }
                if (bets === void 0) { bets = null; }
                if (looseConnection === void 0) { looseConnection = false; }
                if (iData === void 0) { iData = null; }
                if (currency === void 0) { currency = null; }
                if (languages === void 0) { languages = null; }
                if (currencyISO === void 0) { currencyISO = null; }
                this.balance = balance;
                this.language = language;
                this.settings = settings;
                this.command = command;
                this.bets = bets;
                this.looseConnection = looseConnection;
                this.iData = iData;
                this.currency = currency;
                this.languages = languages;
                this.currencyISO = currencyISO;
            }
            GameData.prototype.merge = function (message, withJSON) {
                if (withJSON === void 0) { withJSON = false; }
                var json = message.getData();
                var keys = json == null ? [] : Object.keys(json);
                if (withJSON) {
                    for (var _i = 0, keys_2 = keys; _i < keys_2.length; _i++) {
                        var name = keys_2[_i];
                        try {
                            this[name] = json[name];
                        }
                        catch (error) {
                        }
                    }
                    return this;
                }
                for (var _a = 0, keys_3 = keys; _a < keys_3.length; _a++) {
                    name = keys_3[_a];
                    try {
                        this[name] = message[name];
                    }
                    catch (error) {
                    }
                }
                if (keys.length == 0) {
                    keys = Object.keys(message);
                    for (var _b = 0, keys_4 = keys; _b < keys_4.length; _b++) {
                        name = keys_4[_b];
                        try {
                            this[name] = message[name];
                        }
                        catch (error) {
                        }
                    }
                }
                return this;
            };
            GameData.prototype.toString = function () {
                var keys = Object.keys(this);
                var result = '';
                for (var _i = 0, keys_5 = keys; _i < keys_5.length; _i++) {
                    var name = keys_5[_i];
                    result += '\n' + name + ': ' + this[name];
                }
                return result;
            };
            return GameData;
        }());
        abstract_games.GameData = GameData;
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var services;
    (function (services) {
        var messages;
        (function (messages) {
            var response;
            (function (response) {
                var GameResponse = (function (_super) {
                    __extends(GameResponse, _super);
                    function GameResponse(command, eventTimestamp, msg, complex, reason, gameIdentificationNumber, gameNumber, qName) {
                        if (command === void 0) { command = null; }
                        if (eventTimestamp === void 0) { eventTimestamp = -1; }
                        if (msg === void 0) { msg = null; }
                        if (complex === void 0) { complex = null; }
                        if (reason === void 0) { reason = null; }
                        if (gameIdentificationNumber === void 0) { gameIdentificationNumber = NaN; }
                        if (gameNumber === void 0) { gameNumber = -1; }
                        if (qName === void 0) { qName = null; }
                        var _this = _super.call(this, command, eventTimestamp, msg, complex, reason, qName) || this;
                        _this.gameIdentificationNumber = gameIdentificationNumber;
                        _this.gameNumber = gameNumber;
                        return _this;
                    }
                    GameResponse.prototype.toString = function () {
                        var result = _super.prototype.toString.call(this);
                        return result.substr(0, result.length - 1).concat(', gameIdentificationNumber: ' + this.gameIdentificationNumber + ', gameNumber: ' + this.gameNumber + ', balance: ' + this.balance + '}');
                    };
                    GameResponse.className = 'gpts.services.messages.response.GameResponse';
                    return GameResponse;
                }(response.BaseResponse));
                response.GameResponse = GameResponse;
            })(response = messages.response || (messages.response = {}));
        })(messages = services.messages || (services.messages = {}));
    })(services = gpts.services || (gpts.services = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var MovieClip = PIXI.extras.AnimatedSprite;
    var trace = gamy.trace;
    var SpriteSheet = (function (_super) {
        __extends(SpriteSheet, _super);
        function SpriteSheet(frames) {
            var _this = this;
            var textures = [];
            var length = frames.length;
            for (var i = 0; i < length; i++) {
                textures[i] = frames[i].texture;
            }
            _this = _super.call(this, textures) || this;
            _this._frames = frames;
            return _this;
        }
        SpriteSheet.prototype.gotoAndStopToLabel = function (label) {
            var length = this._frames.length;
            for (var i = 0; i < length; i++) {
                if (this._frames[i].label == label) {
                    this.gotoAndStop(i);
                    break;
                }
            }
        };
        SpriteSheet.prototype.dispose = function () {
            var length = this._frames.length;
            for (var i = 0; i < length; i++)
                this._frames[i].dispose();
            this._frames.length = 0;
            trace(gpts.ELogger.PORTAL, 'dispose SpriteSheet');
        };
        return SpriteSheet;
    }(MovieClip));
    gpts.SpriteSheet = SpriteSheet;
    var Frame = (function () {
        function Frame(texture, label) {
            this.texture = texture;
            this.label = label;
        }
        Frame.prototype.dispose = function () {
            this.texture = null;
        };
        return Frame;
    }());
    gpts.Frame = Frame;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Container = PIXI.Container;
    var ArrayTools = gamy.ArrayTools;
    var Hash = gamy.Hash;
    var DisplayObject = PIXI.DisplayObject;
    var Holder = (function (_super) {
        __extends(Holder, _super);
        function Holder(options) {
            var _this = _super.call(this) || this;
            _this._options = new Hash({
                autoDispose: true
            }).merge(options);
            if (_this._options.autoDispose)
                _this.on('removed', _this.onRemoveFromDisplayTree, _this);
            return _this;
        }
        Holder.prototype.onRemoveFromDisplayTree = function (event) {
            this.off('removed', this.onRemoveFromDisplayTree, this);
            this.dispose();
        };
        Holder.prototype.dispose = function () {
            if (this.hasListener('removed'))
                this.off('removed', this.onRemoveFromDisplayTree, this);
            var length = this.children.length;
            for (var i = 0; i < length; i++) {
                var child = this.children[i];
                if (typeof child.dispose == 'function')
                    child.dispose();
            }
        };
        Holder.prototype.attrs = function (options) {
            if (options) {
                var keys = Object.keys(options);
                for (var _i = 0, keys_6 = keys; _i < keys_6.length; _i++) {
                    var name = keys_6[_i];
                    this[name] = options[name];
                }
            }
            return this;
        };
        Holder.prototype.addChildren = function () {
            var rest = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                rest[_i] = arguments[_i];
            }
            var children = ArrayTools.flatten(rest);
            var length = children.length;
            for (var i = 0; i < length; i++) {
                if (children[i].parent == this)
                    continue;
                this.addChild(children[i]);
            }
        };
        Holder.prototype.hasListener = function (type) {
            return this.listeners(type).length > 0;
        };
        return Holder;
    }(Container));
    gpts.Holder = Holder;
    DisplayObject.prototype['preorder'] = function (callback) {
        var length = this.children.length;
        for (var i = 0; i < length; i++) {
            if (this.children.length > 0) {
                if (this.children.length != length) {
                    i--;
                    length = this.children.length;
                }
                if (this.children[i].preorder instanceof Function) {
                    this.children[i].preorder(callback);
                }
            }
        }
        callback(this);
    };
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Hash = gamy.Hash;
    var Graphics = PIXI.Graphics;
    var trace = gamy.trace;
    var Capabilities = gamy.Capabilities;
    var EVENT_TYPE = gamy.EVENT_TYPE;
    var Button = (function (_super) {
        __extends(Button, _super);
        function Button(src, options) {
            if (src === void 0) { src = null; }
            if (options === void 0) { options = null; }
            var _this = _super.call(this, options) || this;
            _this.graphics = new Graphics();
            _this._options = new Hash({
                supportedStates: {
                    idle: 0xb0d911
                },
                label: true,
                defaultGraphics: true,
                enableEff: false
            }).merge(_this._options);
            _this.src = src;
            _this.addChild(_this.graphics);
            if (_this._options.label) {
                _this.createLabel();
                _this.addChild(_this.label);
            }
            if (_this._options.enableEff) {
                _this.on(Capabilities.eventType(EVENT_TYPE.DOWN), _this.onDown, _this);
                _this.on(Capabilities.eventType(EVENT_TYPE.OVER), _this.onOver, _this);
                _this.on(Capabilities.eventType(EVENT_TYPE.UP), _this.onUp, _this);
                _this.on(Capabilities.eventType(EVENT_TYPE.OUT), _this.onUp, _this);
            }
            return _this;
        }
        Object.defineProperty(Button.prototype, "src", {
            get: function () {
                return this._src;
            },
            set: function (value) {
                if (this._src) {
                    this.removeChild(this._src);
                }
                this._src = value;
                if (this._src) {
                    this.addChild(this._src);
                }
            },
            enumerable: true,
            configurable: true
        });
        Button.prototype.onOver = function (event) {
            try {
                this.src.gotoAndStopToLabel('over');
            }
            catch (error) {
            }
        };
        Button.prototype.onDown = function (event) {
            try {
                this.src.gotoAndStopToLabel('down');
            }
            catch (error) {
            }
        };
        Button.prototype.onUp = function (event) {
            try {
                this.src.gotoAndStopToLabel(this._state);
            }
            catch (error) {
            }
        };
        Button.prototype.createLabel = function () {
            this.label = new PIXI.Text('Game Type', {
                fontFamily: 'Arial',
                fontSize: 13,
                fill: '#ffffff'
            });
            this.label.text = 'label';
        };
        Button.prototype.getState = function () {
            return this._state;
        };
        Button.prototype.setState = function (value) {
            this._state = value;
            try {
                this.src.gotoAndStopToLabel(this._state);
            }
            catch (error) {
                if (this._options.defaultGraphics) {
                    this.graphics.clear();
                    var color = this._options.supportedStates[this._state] != undefined ? this._options.supportedStates[this._state] : Button.STATE_UNSUPPORTED;
                    this.graphics.beginFill(color);
                    this.graphics.drawRect(0, 0, 44, 44);
                    this.graphics.endFill();
                }
            }
        };
        Button.prototype.dispose = function () {
            _super.prototype.dispose.call(this);
            if (this.src && this.src.parent == this) {
                trace(gpts.ELogger.PORTAL, 'dispose Button src');
                this.removeChild(this.src);
                this.src = null;
            }
            if (this.label)
                this.label.destroy(true);
            this.label = null;
            this.graphics = null;
            if (this._options.enableEff) {
                this.removeAllListeners(Capabilities.eventType(EVENT_TYPE.DOWN));
                this.removeAllListeners(Capabilities.eventType(EVENT_TYPE.UP));
                this.removeAllListeners(Capabilities.eventType(EVENT_TYPE.OVER));
                this.removeAllListeners(Capabilities.eventType(EVENT_TYPE.OUT));
            }
        };
        Button.STATE_UNSUPPORTED = 0xff0000;
        return Button;
    }(gpts.Holder));
    gpts.Button = Button;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var services;
    (function (services) {
        var Proxy = puremvc.Proxy;
        var IMessageProxy = (function (_super) {
            __extends(IMessageProxy, _super);
            function IMessageProxy(proxyName, data) {
                if (proxyName === void 0) { proxyName = null; }
                if (data === void 0) { data = null; }
                var _this = _super.call(this, proxyName, data) || this;
                _this.timeStamp = 0;
                _this.timeToLive = 0;
                return _this;
            }
            return IMessageProxy;
        }(Proxy));
        services.IMessageProxy = IMessageProxy;
    })(services = gpts.services || (gpts.services = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var services;
    (function (services) {
        var trace = gamy.trace;
        var MessageProxy = (function (_super) {
            __extends(MessageProxy, _super);
            function MessageProxy(message) {
                return _super.call(this, message.messageId, message) || this;
            }
            MessageProxy.prototype.onRegister = function () {
                _super.prototype.onRegister.call(this);
                if (this.proxyName != null) {
                    if (this.timeToLive == 0)
                        throw new Error('Message should have finite live');
                    this.timeStamp = new Date().getTime();
                    var that_1 = this;
                    this._id = setTimeout(function () {
                        that_1.onTimeout();
                    }, this.timeToLive * 1000);
                }
            };
            MessageProxy.prototype.onTimeout = function () {
                trace('[Message timeout] [t] ' + '\nid: ' + this.proxyName + '\ndata: ' + this.getData().toString());
                this.facade().dispatchEvent(new services.MessagesEvent(services.MessagesEvent.TIME_OUT, this.getData(), this.proxyName));
            };
            MessageProxy.prototype.onRemove = function () {
                _super.prototype.onRemove.call(this);
                if (!isNaN(this._id))
                    clearTimeout(this._id);
            };
            return MessageProxy;
        }(services.IMessageProxy));
        services.MessageProxy = MessageProxy;
    })(services = gpts.services || (gpts.services = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var services;
    (function (services) {
        var Model = puremvc.Model;
        var MessagesModel = (function (_super) {
            __extends(MessagesModel, _super);
            function MessagesModel() {
                var _this = _super.call(this, services.MessagesFacade.NAME) || this;
                _this.commands_map = {};
                return _this;
            }
            MessagesModel.prototype.registerProxy = function (proxy) {
                if (proxy instanceof services.MessageProxy) {
                    var command = proxy.getData().command;
                    this.commands_map[command] = proxy.getData();
                }
                _super.prototype.registerProxy.call(this, proxy);
            };
            MessagesModel.prototype.removeProxy = function (proxyName) {
                var proxy = this.retrieveProxy(proxyName);
                if (proxy instanceof services.IMessageProxy) {
                    delete this.commands_map[proxy.getData().command];
                }
                return _super.prototype.removeProxy.call(this, proxyName);
            };
            MessagesModel.prototype.pendingCommand = function (commandName) {
                return this.commands_map[commandName] != undefined;
            };
            MessagesModel.prototype.getCommand = function (commandName) {
                return this.commands_map[commandName];
            };
            return MessagesModel;
        }(Model));
        services.MessagesModel = MessagesModel;
    })(services = gpts.services || (gpts.services = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var LogOptions = gamy.LogOptions;
    var LogLevels = gamy.LogLevels;
    var ELogger = (function (_super) {
        __extends(ELogger, _super);
        function ELogger(name, options) {
            if (options === void 0) { options = null; }
            return _super.call(this, name, options) || this;
        }
        ELogger.RUNTIME_ERRORS = new ELogger('runtime_errors', { level: LogLevels.VERBOSE });
        ELogger.UNCAUGHT_ERRORS = new ELogger('uncaught_errors', { level: LogLevels.VERBOSE });
        ELogger.MAPPING = new ELogger('mapping', { level: LogLevels.VERBOSE });
        ELogger.STATE_MACHINE = new ELogger('state_machine', { level: LogLevels.VERBOSE });
        ELogger.APP_FACADE = new ELogger('app_facade', { level: LogLevels.VERBOSE });
        ELogger.GAME_DATA = new ELogger('game_data', { level: LogLevels.VERBOSE });
        ELogger.PING = new ELogger('ping', { level: LogLevels.VERBOSE });
        ELogger.GAME = new ELogger('game', { level: LogLevels.VERBOSE });
        ELogger.MEMORY_TRACKER = new ELogger('memory_tracker', { level: LogLevels.VERBOSE });
        ELogger.LATENCY = new ELogger('latency', { level: LogLevels.VERBOSE });
        ELogger.PORTAL = new ELogger('portal', { level: LogLevels.VERBOSE });
        ELogger.NAVIGATION_PROXY = new ELogger('navigation_proxy', { level: LogLevels.VERBOSE });
        return ELogger;
    }(LogOptions));
    gpts.ELogger = ELogger;
    LogOptions.DEFAULT_LOG = new ELogger('default_log', { level: LogLevels.VERBOSE });
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var services;
    (function (services) {
        var trace = gamy.trace;
        var Ping = (function () {
            function Ping(interval) {
                this.lastMsgTimeStamp = 0;
                this.elapsed_time = 0;
                this._interval = interval;
            }
            Ping.prototype.start = function () {
                var that = this;
                this._id = setInterval(function () {
                    that.onTick();
                }, this._interval * 1000);
            };
            Ping.prototype.stop = function () {
                clearInterval(this._id);
            };
            Ping.prototype.onTick = function () {
                this.elapsedTime = new Date().getTime() - this.lastMsgTimeStamp;
                trace(gpts.ELogger.PING, 'elapsedTime: ' + this.elapsedTime);
                if (this.elapsedTime <= services.MessagesFacade.LOST_CONNECTION_INTERVAL) {
                    if (this.elapsedTime > services.MessagesFacade.PING_INTERVAL)
                        services.MessagesFacade.getInstance().send(services.MessagesFacade.getInstance().pingMessage);
                }
                else {
                    services.MessagesFacade.getInstance().close();
                    this.stop();
                    services.MessagesFacade.getInstance().dispatchEvent(new services.MessagesEvent(services.MessagesEvent.LOOSE_CONNECTION));
                }
            };
            Object.defineProperty(Ping.prototype, "elapsedTime", {
                get: function () {
                    return this.elapsed_time;
                },
                set: function (value) {
                    this.elapsed_time = value;
                    var event = document.createEvent("CustomEvent");
                    event.initCustomEvent(services.MessagesFacade.CONNECTION_STATUS, false, false, null);
                    services.MessagesFacade.getInstance().dispatchEvent(event);
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Ping.prototype, "running", {
                get: function () {
                    return !isNaN(this._id);
                },
                enumerable: true,
                configurable: true
            });
            return Ping;
        }());
        services.Ping = Ping;
    })(services = gpts.services || (gpts.services = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var services;
    (function (services) {
        var SimpleCommand = puremvc.SimpleCommand;
        var Hash = gamy.Hash;
        var trace = gamy.trace;
        var getDefinitionByName = gamy.getDefinitionByName;
        var SuccessMessageCommand = (function (_super) {
            __extends(SuccessMessageCommand, _super);
            function SuccessMessageCommand() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            SuccessMessageCommand.prototype.execute = function (notification) {
                var timeStamp = new Date().getTime();
                _super.prototype.execute.call(this, notification);
                var facade = this.facade();
                var message = this.serialize(notification.getBody());
                trace('[Receive message] [<=] ' + '\nid: ' + message.messageId + '\ndata: ' + message.toString());
                if (!message.isEmpty()) {
                    var messageId = message.messageId;
                    if (facade.hasProxy(messageId)) {
                        facade.ping.lastMsgTimeStamp = new Date().getTime();
                        var messageProxy = facade.retrieveProxy(messageId);
                        var elapsedTime = timeStamp - messageProxy.timeStamp;
                        trace(gpts.ELogger.LATENCY, 'id: ' + messageId + '\nlatency: ' + elapsedTime);
                        if (elapsedTime <= 1000 * messageProxy.timeToLive) {
                            facade.removeProxy(messageId);
                            facade.dispatchEvent(new services.MessagesEvent(services.MessagesEvent.MESSAGE, this.map(message), messageId));
                        }
                    }
                    else {
                        if (messageId.substr(0, 4) == services.MessagesFacade.REQUEST_RESPONSE_IDENTIFICATOR) {
                            if (facade.isTimeoutRequestSkippable(facade.getModuleName(message), message.command))
                                return;
                            else
                                facade.ping.lastMsgTimeStamp = new Date().getTime();
                        }
                        facade.dispatchEvent(new services.MessagesEvent(services.MessagesEvent.MESSAGE, this.map(message)));
                    }
                }
            };
            SuccessMessageCommand.prototype.serialize = function (body) {
                var message;
                var facade = this.facade();
                try {
                    message = new Hash().merge(JSON.parse(body), false);
                }
                catch (error) {
                    trace(gpts.ELogger.RUNTIME_ERRORS, '[SuccessMessageCommand]', error.message, error.stack);
                    message = new Hash();
                }
                return message;
            };
            SuccessMessageCommand.prototype.map = function (message) {
                try {
                    var definition = getDefinitionByName('gpts' + message.qName.substr(3));
                    var msg = new definition();
                    msg.setData(message);
                }
                catch (error) {
                    trace(gpts.ELogger.MAPPING, '\nUNSUCCESSFUL MAP: ' + message.toString() + '\n' + error.message);
                    return new services.Message();
                }
                return msg;
            };
            return SuccessMessageCommand;
        }(SimpleCommand));
        services.SuccessMessageCommand = SuccessMessageCommand;
    })(services = gpts.services || (gpts.services = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var services;
    (function (services) {
        var SimpleCommand = puremvc.SimpleCommand;
        var GUID = gamy.GUID;
        var trace = gamy.trace;
        var SendMessageCommand = (function (_super) {
            __extends(SendMessageCommand, _super);
            function SendMessageCommand() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            SendMessageCommand.prototype.execute = function (notification) {
                _super.prototype.execute.call(this, notification);
                var data = notification.getBody().data;
                var timeToLive = notification.getBody().timeToLive;
                var facade = this.facade();
                try {
                    data.messageId = services.MessagesFacade.REQUEST_RESPONSE_IDENTIFICATOR + GUID.create();
                    var t = facade.getServiceTimeout(facade.getModuleName(data), data.command);
                    timeToLive = isNaN(t) ? timeToLive : t;
                    trace('[Send message] [=>] ' + '\nid: ' + data.messageId + '\ndata: ' + data.toString() + '\ntimeToLive: ' + timeToLive);
                    facade.socket.send(data.encode());
                    var msgProxy = new services.MessageProxy(data);
                    msgProxy.timeToLive = timeToLive;
                    facade.registerProxy(msgProxy);
                }
                catch (error) {
                    trace(gpts.ELogger.RUNTIME_ERRORS, '[SendMessageCommand]', error.message, error.stack);
                }
            };
            return SendMessageCommand;
        }(SimpleCommand));
        services.SendMessageCommand = SendMessageCommand;
    })(services = gpts.services || (gpts.services = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var services;
    (function (services) {
        var Facade = puremvc.Facade;
        var EventDispatcher = gamy.EventDispatcher;
        var MessagesModel = gpts.services.MessagesModel;
        var trace = gamy.trace;
        var MessagesFacade = (function (_super) {
            __extends(MessagesFacade, _super);
            function MessagesFacade() {
                return _super.call(this, MessagesFacade.NAME) || this;
            }
            MessagesFacade.getInstance = function () {
                if (!Facade.hasCore(MessagesFacade.NAME))
                    Facade.instanceMap[MessagesFacade.NAME] = new MessagesFacade();
                return Facade.getInstance(MessagesFacade.NAME);
            };
            MessagesFacade.prototype.initializeFacade = function () {
                this._socket = new WebSocket(gpts.AppFacade.getInstance().tcpHost + ':' + gpts.AppFacade.getInstance().tcpPort);
                this.configureListeners();
                this._dispatcher = new EventDispatcher(this);
                this._ping = new services.Ping(MessagesFacade.PING_TICK_INTERVAL);
                _super.prototype.initializeFacade.call(this);
            };
            MessagesFacade.prototype.initializeController = function () {
                _super.prototype.initializeController.call(this);
                this.registerCommand(MessagesFacade.MESSAGE_SUCCESS, services.SuccessMessageCommand);
                this.registerCommand(MessagesFacade.SEND_MESSAGE, services.SendMessageCommand);
            };
            MessagesFacade.prototype.initializeModel = function () {
                if (!this.model)
                    this.model = new MessagesModel();
            };
            MessagesFacade.prototype.configureListeners = function () {
                var that = this;
                this._socket.onopen = function (event) {
                    that._connected = true;
                    that.onSocketOpen(event);
                };
                this._socket.onmessage = function (event) {
                    that.onSocketMessage(event);
                };
                this._socket.onerror = function (event) {
                    that._connected = false;
                    that.onSocketError(event);
                };
                this._socket.onclose = function (event) {
                    that._connected = false;
                    that.onSocketClose(event);
                };
            };
            MessagesFacade.prototype.onSocketOpen = function (event) {
                trace('socket connected');
                this.dispatchEvent(event);
            };
            MessagesFacade.prototype.onSocketMessage = function (event) {
                this.sendNotification(MessagesFacade.MESSAGE_SUCCESS, event.data);
            };
            MessagesFacade.prototype.onSocketError = function (event) {
                this.dispatchEvent(event);
            };
            MessagesFacade.prototype.onSocketClose = function (event) {
                this.dispatchEvent(event);
            };
            MessagesFacade.prototype.addEventListener = function (type, callback, context) {
                this._dispatcher.addEventListener(type, callback, context);
            };
            MessagesFacade.prototype.dispatchEvent = function (event) {
                this._dispatcher.dispatchEvent(event);
            };
            MessagesFacade.prototype.removeEventListener = function (type, callback, context) {
                this._dispatcher.removeEventListener(type, callback, context);
            };
            MessagesFacade.prototype.hasEventListener = function (type) {
                return this._dispatcher.hasEventListener(type);
            };
            MessagesFacade.prototype.pendingCommand = function (commandName) {
                if (!this.model)
                    return false;
                return this.model.pendingCommand(commandName);
            };
            MessagesFacade.prototype.getCommand = function (commandName) {
                if (!this.model)
                    return null;
                return this.model.getCommand(commandName);
            };
            MessagesFacade.prototype.close = function () {
                try {
                    this._socket.close();
                    this._connected = false;
                }
                catch (error) {
                }
            };
            MessagesFacade.prototype.send = function (data, timeToLive) {
                if (timeToLive === void 0) { timeToLive = 15; }
                this.sendNotification(MessagesFacade.SEND_MESSAGE, { data: data, timeToLive: timeToLive });
            };
            MessagesFacade.prototype.getServiceTimeout = function (moduleName, serviceName) {
                try {
                    return this.services[moduleName][serviceName].timeToLive;
                }
                catch (error) {
                }
                return NaN;
            };
            MessagesFacade.prototype.isTimeoutRequestSkippable = function (moduleName, serviceName) {
                try {
                    return this.services[moduleName][serviceName].skipTimeout;
                }
                catch (error) {
                }
                return true;
            };
            Object.defineProperty(MessagesFacade.prototype, "socket", {
                get: function () {
                    return this._socket;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(MessagesFacade.prototype, "ping", {
                get: function () {
                    return this._ping;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(MessagesFacade.prototype, "connected", {
                get: function () {
                    return this._connected;
                },
                enumerable: true,
                configurable: true
            });
            MessagesFacade.NAME = 'messagesFacade';
            MessagesFacade.MESSAGE_SUCCESS = 'successMessageCommand';
            MessagesFacade.SEND_MESSAGE = 'sendMessageCommand';
            MessagesFacade.CONNECTION_STATUS = 'connectionStatus';
            MessagesFacade.LOST_CONNECTION_INTERVAL = 20 * 1000;
            MessagesFacade.PING_INTERVAL = 4 * 1000;
            MessagesFacade.PING_TICK_INTERVAL = 5;
            MessagesFacade.REQUEST_RESPONSE_IDENTIFICATOR = 'r-r_';
            return MessagesFacade;
        }(Facade));
        services.MessagesFacade = MessagesFacade;
    })(services = gpts.services || (gpts.services = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var trace = gamy.trace;
    var EventDispatcher = gamy.EventDispatcher;
    var Dispatcher = (function () {
        function Dispatcher() {
            this._dispatcher = new EventDispatcher(this);
        }
        Dispatcher.prototype.addEventListener = function (type, callback, context) {
            this._dispatcher.addEventListener(type, callback, context);
        };
        Dispatcher.prototype.hasEventListener = function (type) {
            return this._dispatcher.hasEventListener(type);
        };
        Dispatcher.prototype.dispatchEvent = function (event) {
            this._dispatcher.dispatchEvent(event);
        };
        Dispatcher.prototype.removeEventListener = function (type, callback) {
            this._dispatcher.removeEventListener(type, callback);
        };
        Dispatcher.prototype.toString = function () {
            return 'Dispatcher';
        };
        return Dispatcher;
    }());
    var Handler1 = (function () {
        function Handler1(dispatcher) {
            this._dispatcher = dispatcher;
            this._dispatcher.addEventListener('change', this.handler, this);
            this._dispatcher.addEventListener('connect', this.handler, this);
        }
        Handler1.prototype.handler = function (event) {
            trace(this, event.type, event.target);
        };
        Handler1.prototype.toString = function () {
            return 'Handler 1';
        };
        Handler1.prototype.dispose = function () {
            this._dispatcher.removeEventListener('change', this.handler);
        };
        return Handler1;
    }());
    var DebugCode = (function () {
        function DebugCode() {
        }
        return DebugCode;
    }());
    gpts.DebugCode = DebugCode;
    var A = (function () {
        function A(prop) {
            this.prop = prop;
        }
        return A;
    }());
    var B = (function (_super) {
        __extends(B, _super);
        function B() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        B.prototype.foo = function () {
        };
        return B;
    }(A));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var LoaderMax = gamy.LoaderMax;
    var ErrorTest = (function () {
        function ErrorTest(errorID) {
            switch (errorID) {
                case 'connectionClosed':
                    gpts.Router.getInstance().redirectTo(gpts.Router.SESSION_CLOSED_PAGE, { reason: gpts.EMessage.CONNECTION_CLOSED });
                    break;
                case 'ipBlocked':
                    gpts.Router.getInstance().redirectTo(gpts.Router.SESSION_CLOSED_PAGE, { reason: gpts.EMessage.IP_BLOCKED, });
                    break;
                case 'mobileGamesOnDesktopBrowser':
                    gpts.Router.getInstance().redirectTo(gpts.Router.SESSION_CLOSED_PAGE, { reason: gpts.EMessage.USE_MOBILE_DEVICES });
                    break;
                case 'incorrectGIN':
                    var content = LoaderMax.getContent(gpts.Main.CONTENT);
                    gpts.Alert.show(content.incorrectGIN[gpts.Router.getInstance().language]);
                    break;
            }
        }
        return ErrorTest;
    }());
    gpts.ErrorTest = ErrorTest;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var trace = gamy.trace;
        var Hash = gamy.Hash;
        var DataHandler = (function () {
            function DataHandler() {
                throw new Error('static class');
            }
            DataHandler.set = function (view, data) {
                trace(gpts.ELogger.GAME_DATA, data, '\nCOMPLEX: ' + new Hash(data.complex));
                view.data = data;
            };
            return DataHandler;
        }());
        abstract_games.DataHandler = DataHandler;
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var Mediator = puremvc.Mediator;
        var MessagesFacade = gpts.services.MessagesFacade;
        var GameMediator = (function (_super) {
            __extends(GameMediator, _super);
            function GameMediator(gameType) {
                var _this = _super.call(this, gameType) || this;
                _this._events = [];
                _this.messages_facade = MessagesFacade.getInstance();
                return _this;
            }
            GameMediator.prototype.listNotificationInterests = function () {
                return [
                    GameMediator.LOOSE_CONNECTION + this.mediatorName,
                    GameMediator.EVENTS + this.mediatorName,
                    GameMediator.SHOW + this.mediatorName,
                    this.mediatorName
                ];
            };
            GameMediator.prototype.handleNotification = function (notification) {
                _super.prototype.handleNotification.call(this, notification);
                var data = notification.getBody();
                switch (notification.getName()) {
                    case GameMediator.LOOSE_CONNECTION + this.mediatorName:
                        var d = new abstract_games.GameData();
                        d.command = GameMediator.LOOSE_CONNECTION;
                        abstract_games.DataHandler.set(this.viewComponent, d);
                        break;
                    case GameMediator.EVENTS + this.mediatorName:
                        this._events = notification.getBody();
                        break;
                    default:
                        break;
                }
            };
            GameMediator.prototype.onRemove = function () {
                _super.prototype.onRemove.call(this);
                this.viewComponent = null;
            };
            Object.defineProperty(GameMediator.prototype, "events", {
                get: function () {
                    return this._events;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(GameMediator.prototype, "_facade", {
                get: function () {
                    return this.facade();
                },
                enumerable: true,
                configurable: true
            });
            GameMediator.LOOSE_CONNECTION = 'looseConnection';
            GameMediator.EVENTS = 'events';
            GameMediator.SHOW = 'show';
            GameMediator.SUCCESS = 'success';
            GameMediator.RETURN_BETS = 'returnBets';
            return GameMediator;
        }(Mediator));
        abstract_games.GameMediator = GameMediator;
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var SimpleCommand = puremvc.SimpleCommand;
    var LoaderMax = gamy.LoaderMax;
    var ArrayTools = gamy.ArrayTools;
    var StringTools = gamy.StringTools;
    var getDefinitionByName = gamy.getDefinitionByName;
    var GameMediator = gpts.abstract_games.GameMediator;
    var Hash = gamy.Hash;
    var LoginCommand = (function (_super) {
        __extends(LoginCommand, _super);
        function LoginCommand() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        LoginCommand.prototype.execute = function (notification) {
            _super.prototype.execute.call(this, notification);
            var facade = this.facade();
            var router = gpts.Router.getInstance();
            var message = notification.getBody();
            facade.balance = message.balance;
            facade.currencyISO = message.currency;
            facade.currency = this.displayCurrency(message.currency);
            facade.playerName = message.playerName;
            facade.languages = this.intersect(message.languages, LoaderMax.getContent(gpts.Main.CONTENT).languages).reverse();
            facade.groups = message.groups;
            facade.showRtp = message.showRtp;
            facade.autoplayLimit = message.autoplayLimit;
            facade.immediatelyClosePopup = !message.multigame;
            facade.minimumSpinTime = message.minimumSpinTime;
            facade.sendTotalsInfo = message.sendTotalsInfo;
            facade.isEGTCurrency = facade.currency == gpts.Main.EGT;
            facade.originalGamesList = message.complex;
            if (!ArrayTools.has(facade.languages, router.language))
                router.redirectTo(router.page, new Hash(router.parameters).merge({ language: facade.languages.length == 0 ? 'en' : (ArrayTools.has(facade.languages, 'en') ? 'en' : facade.languages[0]) }));
            if (DEBUG)
                this.modifyGamesList(message);
            if (MINI || MOB)
                this.spliceGamesListForAMiniPortal(message);
            var keys = Object.keys(message.complex);
            for (var _i = 0, keys_7 = keys; _i < keys_7.length; _i++) {
                var gameType = keys_7[_i];
                for (var _a = 0, _b = message.complex[gameType]; _a < _b.length; _a++) {
                    var gameItem = _b[_a];
                    gameItem.playerName = message.playerName;
                    gameItem.gameType = gameType;
                    facade.gamesList[gameItem.gameIdentificationNumber] = gameItem;
                    facade.gamesRecoveryList[gameItem.gameIdentificationNumber] = gameItem.recovery;
                    if (gameItem.bonusSpins && gameItem.bonusSpins.remainingBonusSpins > 0) {
                        facade.gamesWithBonusesList[gameItem.gameIdentificationNumber] = gameItem;
                    }
                    this.setInterests(gameType);
                }
                var className = 'gpts.abstract_games.' + StringTools.toPackageNameConvention(gameType) + '.' + gameType;
                try {
                    var definition = getDefinitionByName(className + 'ReturnBetsCommand');
                    this.facade().registerCommand(GameMediator.RETURN_BETS + gameType, definition);
                }
                catch (error) {
                }
            }
            facade.singleGameMode = facade.gamesList.length == 1;
        };
        LoginCommand.prototype.setInterests = function (gameType) {
            if (gameType === void 0) { gameType = null; }
            var facade = this.facade();
            if (facade.interests.has(gameType))
                return;
            var loaders = LoaderMax.getContent(gpts.Main.CONTENT).loaders;
            var length = loaders.length;
            for (var i = 0; i < length; i++) {
                if (loaders[i].vars.name == gpts.Main.GAME_INTERFACE) {
                    loaders = loaders[i].children;
                    length = loaders.length;
                    break;
                }
            }
            for (i = 0; i < length; i++) {
                var loaderName = loaders[i].vars.name;
                var interests = loaderName.split('-');
                if (ArrayTools.has(interests, gameType)) {
                    facade.interests[gameType] = loaderName;
                    break;
                }
            }
        };
        LoginCommand.prototype.displayCurrency = function (currencyISOFormat) {
            var currencyOptions = LoaderMax.getContent(gpts.Main.CONTENT).currency[currencyISOFormat];
            if (currencyOptions && currencyOptions.displayName)
                return currencyOptions.displayName;
            return currencyISOFormat;
        };
        LoginCommand.prototype.modifyGamesList = function (message) {
        };
        LoginCommand.prototype.spliceGamesListForAMiniPortal = function (message) {
            var facade = this.facade();
            var gamesList = {};
            var gin = facade.gameIdentificationNumber != -1 ? String(facade.gameIdentificationNumber) : null;
            var keys = Object.keys(message.complex);
            for (var _i = 0, keys_8 = keys; _i < keys_8.length; _i++) {
                var gameType = keys_8[_i];
                for (var _a = 0, _b = message.complex[gameType]; _a < _b.length; _a++) {
                    var gameItem = _b[_a];
                    if (gin == null || gin == gameItem.gameIdentificationNumber) {
                        gamesList[gameType] = [gameItem];
                        message.complex = gamesList;
                        return;
                    }
                }
            }
            gamesList[gameType] = [gameItem];
            message.complex = gamesList;
        };
        LoginCommand.prototype.intersect = function (array1, array2) {
            var intersection = [];
            var length = array1.length;
            for (var i = 0; i < length; i++)
                if (ArrayTools.has(array2, array1[i]))
                    intersection.push(array1[i]);
            return intersection;
        };
        return LoginCommand;
    }(SimpleCommand));
    gpts.LoginCommand = LoginCommand;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var Proxy = puremvc.Proxy;
        var IGame = (function (_super) {
            __extends(IGame, _super);
            function IGame(proxyName, data) {
                if (proxyName === void 0) { proxyName = null; }
                if (data === void 0) { data = null; }
                return _super.call(this, proxyName, data) || this;
            }
            IGame.prototype.startGame = function () {
            };
            return IGame;
        }(Proxy));
        abstract_games.IGame = IGame;
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var SimpleCommand = puremvc.SimpleCommand;
    var IGame = gpts.abstract_games.IGame;
    var GameData = gpts.abstract_games.GameData;
    var DataHandler = gpts.abstract_games.DataHandler;
    var LoaderMax = gamy.LoaderMax;
    var UpdateBalanceCommand = (function (_super) {
        __extends(UpdateBalanceCommand, _super);
        function UpdateBalanceCommand() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        UpdateBalanceCommand.prototype.execute = function (notification) {
            _super.prototype.execute.call(this, notification);
            var gameProxy = this.facade().retrieveProxy(gpts.Router.getInstance().parameters.gameIdentificationNumber);
            if (gameProxy instanceof IGame) {
                var data = new GameData(gpts.AppFacade.getInstance().balance);
                data.command = gpts.EMessage.BALANCE;
                DataHandler.set(LoaderMax.getLoader(gameProxy.interests()).content, data);
            }
        };
        return UpdateBalanceCommand;
    }(SimpleCommand));
    gpts.UpdateBalanceCommand = UpdateBalanceCommand;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var SimpleCommand = puremvc.SimpleCommand;
    var LoaderMax = gamy.LoaderMax;
    var DisposeCheckCommand = (function (_super) {
        __extends(DisposeCheckCommand, _super);
        function DisposeCheckCommand() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        DisposeCheckCommand.prototype.execute = function (notification) {
            _super.prototype.execute.call(this, notification);
            var loaderName = notification.getBody();
            var gameType = notification.getType();
            var interests = loaderName.split('-');
            var facade = this.facade();
            facade.removeMediator(gameType);
            var game = LoaderMax.getLoader(loaderName).content;
            if (game) {
                var amount = 0;
                var length_1 = interests.length;
                for (var i = 0; i < length_1; i++)
                    amount += facade.gamesEnum[interests[i]];
                if (amount == 0) {
                    game.dispose();
                    LoaderMax.getLoader(loaderName).unload();
                }
            }
        };
        return DisposeCheckCommand;
    }(SimpleCommand));
    gpts.DisposeCheckCommand = DisposeCheckCommand;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Mediator = puremvc.Mediator;
    var MessagesFacade = gpts.services.MessagesFacade;
    var BaseMediator = (function (_super) {
        __extends(BaseMediator, _super);
        function BaseMediator(name, view) {
            if (name === void 0) { name = null; }
            if (view === void 0) { view = null; }
            var _this = _super.call(this, name, view) || this;
            _this.portal_proxy = gpts.Router.getInstance().retrieveProxy(gpts.PortalProxy.NAME);
            _this.app_facade = gpts.AppFacade.getInstance();
            _this.messages_facade = MessagesFacade.getInstance();
            _this._router = gpts.Router.getInstance();
            return _this;
        }
        BaseMediator.prototype.onRegister = function () {
            _super.prototype.onRegister.call(this);
            this._stage = gpts.Router.getInstance().retrieveMediator(gpts.StageMediator.NAME);
        };
        BaseMediator.prototype.listNotificationInterests = function () {
            return [gpts.Router.CHANGE_PAGE];
        };
        BaseMediator.prototype.sendFront = function () {
            if (this.viewComponent.parent != null)
                this._stage.view.stage.setChildIndex(this.viewComponent, this._stage.view.stage.children.length - 1);
        };
        return BaseMediator;
    }(Mediator));
    gpts.BaseMediator = BaseMediator;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var IGame = gpts.abstract_games.IGame;
    var trace = gamy.trace;
    var GameMediator = gpts.abstract_games.GameMediator;
    var GameInterfaceMediator = (function (_super) {
        __extends(GameInterfaceMediator, _super);
        function GameInterfaceMediator() {
            return _super.call(this, GameInterfaceMediator.NAME) || this;
        }
        GameInterfaceMediator.prototype.onRegister = function () {
            _super.prototype.onRegister.call(this);
            var gameMediator = this.app_facade.retrieveMediator(this._router.parameters.gameType);
            var gameProxy = this.app_facade.retrieveProxy(this._router.parameters.gameIdentificationNumber);
            this.viewComponent = gameMediator.getViewComponent();
            this._events = gameMediator.events;
            trace('Prepare to display game ' + gameProxy.gameType() + ' with events: ' + this._events);
            this.app_facade.sendNotification(GameMediator.SHOW + gameProxy.gameType());
            if (this.viewComponent != null) {
                this._stage.view.stage.addChild(this.viewComponent);
                this.configureListeners();
            }
        };
        GameInterfaceMediator.prototype.configureListeners = function (add) {
            if (add === void 0) { add = true; }
            if (add) {
                for (var _i = 0, _a = this._events; _i < _a.length; _i++) {
                    var type = _a[_i];
                    this.viewComponent.addEventListener(type, this.eventHandler, this);
                }
            }
            else {
                for (var _b = 0, _c = this._events; _b < _c.length; _b++) {
                    var type = _c[_b];
                    this.viewComponent.removeEventListener(type, this.eventHandler, this);
                }
            }
        };
        GameInterfaceMediator.prototype.eventHandler = function (event) {
            var gameProxy = this.app_facade.retrieveProxy(this._router.parameters.gameIdentificationNumber);
            switch (event.type) {
                case gpts.GameEvent.HIDE:
                    if (!this.app_facade.singleGameMode)
                        this.app_facade.sendNotification(gpts.AppFacade.PLAY_SOUND, gpts.AppFacade.HIDE_GAME);
                    if (this.app_facade.singleGameMode || this.app_facade.immediatelyClosePopup)
                        this.app_facade.sendNotification(gpts.AppFacade.EXIT_PLATFORM);
                    else {
                        this._router.redirectTo(gpts.Router.HOME_PAGE, { groupId: this._router.oldParameters.groupId });
                        gameProxy.eventHandler(event);
                    }
                    break;
                default:
                    gameProxy.eventHandler(event);
                    break;
            }
        };
        GameInterfaceMediator.prototype.onRemove = function () {
            _super.prototype.onRemove.call(this);
            this.configureListeners(false);
            var gameProxy = this.app_facade.retrieveProxy(this._router.oldParameters.gameIdentificationNumber);
            if (gameProxy instanceof IGame && gameProxy.currentState == gpts.EMessage.FAILURE) {
                this.app_facade.removeProxy(this._router.oldParameters.gameIdentificationNumber);
                this.app_facade.gamesRecoveryList[this._router.oldParameters.gameIdentificationNumber] = gameProxy.canContinueAfterFailure ? gpts.EMessage.NO_RECOVERY : gpts.EMessage.FAILURE;
            }
            this._stage.view.stage.removeChild(this.viewComponent);
            trace('dispose GameInterfaceMediator');
            this.viewComponent = null;
        };
        GameInterfaceMediator.NAME = 'GameInterfaceMediator';
        return GameInterfaceMediator;
    }(gpts.BaseMediator));
    gpts.GameInterfaceMediator = GameInterfaceMediator;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var LoaderMax = gamy.LoaderMax;
    var SessionClosedMediator = (function (_super) {
        __extends(SessionClosedMediator, _super);
        function SessionClosedMediator() {
            return _super.call(this, SessionClosedMediator.NAME) || this;
        }
        SessionClosedMediator.prototype.onRegister = function () {
            _super.prototype.onRegister.call(this);
            var content = LoaderMax.getContent(gpts.Main.CONTENT);
            var reason = this._router.parameters.reason;
            $('#sessionClosed').css('display', 'table');
            var container = $('#sessionClosedLabel');
            container.append(content[reason] == null ? content.defaultSessionClosed[this._router.language] : content[reason][this._router.language]);
        };
        SessionClosedMediator.NAME = 'SessionClosedMediator';
        return SessionClosedMediator;
    }(gpts.BaseMediator));
    gpts.SessionClosedMediator = SessionClosedMediator;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Graphics = PIXI.Graphics;
    var Text = PIXI.Text;
    var GameLoading = (function (_super) {
        __extends(GameLoading, _super);
        function GameLoading() {
            var _this = _super.call(this) || this;
            _this.progressBar = new Graphics();
            _this.progressBarFixed = new Graphics();
            _this.background = new Graphics();
            _this._progress = 0;
            var width = MINI ? 200 : 400;
            var thickness = 2;
            _this.progressBar.beginFill(0xffffff);
            _this.progressBar.drawRect(0, 0, width, thickness);
            _this.progressBar.endFill();
            _this.progressBarFixed.beginFill(0x666666);
            _this.progressBarFixed.drawRect(0, 0, width, thickness);
            _this.progressBarFixed.endFill();
            _this.progressPercentage = new Text('loading 0 %', {
                fontFamily: 'Arial',
                fontSize: 13,
                fill: '#ffffff'
            });
            _this.addChildren(_this.background, _this.progressBarFixed, _this.progressBar, _this.progressPercentage);
            return _this;
        }
        Object.defineProperty(GameLoading.prototype, "progress", {
            get: function () {
                return this._progress;
            },
            set: function (value) {
                this._progress = value;
                this.progressBar.scale.set(this._progress, 1);
                this.star.x = this.progressBar.width + this.progressBar.x - this.star.width / 2;
                this.progressPercentage.text = 'loading ' + Math.ceil(100 * this._progress) + ' %';
                this.progressPercentage.x = this.progressBarFixed.x + (this.progressBarFixed.width - this.progressPercentage.width) / 2;
            },
            enumerable: true,
            configurable: true
        });
        return GameLoading;
    }(gpts.Holder));
    gpts.GameLoading = GameLoading;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var LoaderMax = gamy.LoaderMax;
    var LoaderEvent = gamy.LoaderEvent;
    var trace = gamy.trace;
    var Sprite = PIXI.Sprite;
    var IGame = gpts.abstract_games.IGame;
    var GameLoadingMediator = (function (_super) {
        __extends(GameLoadingMediator, _super);
        function GameLoadingMediator() {
            return _super.call(this, GameLoadingMediator.NAME) || this;
        }
        GameLoadingMediator.prototype.onRegister = function () {
            _super.prototype.onRegister.call(this);
            this.viewComponent = new gpts.GameLoading();
            this.viewComponent.background.interactive = true;
            this.viewComponent.companyLogo = new Sprite(this.portal_proxy.getTexture(gpts.PortalProxy.COMPANY_LOGO));
            if (MINI) {
                this.viewComponent.companyLogo.scale.set(0.8, 0.8);
            }
            this.viewComponent.star = new Sprite(this.portal_proxy.getTexture(gpts.PortalProxy.STAR_ICON));
            this.viewComponent.addChildren(this.viewComponent.star, this.viewComponent.companyLogo);
            this._loader = LoaderMax.getLoader(gpts.Main.GAME_INTERFACE);
            this._loader.addEventListener(LoaderEvent.CHILD_OPEN, this.onStartLoadingGame, this);
            this._loader.addEventListener(LoaderEvent.CHILD_FAIL, this.onFailLoadingGame, this);
            this._loader.addEventListener(LoaderEvent.CHILD_COMPLETE, this.onCompleteLoadingGame, this);
            var that = this;
            function onOrientationChange() {
                that.viewComponent.background.clear();
                that.viewComponent.background.beginFill(0x000000, 1);
                that.viewComponent.background.drawRect(0, 0, that._stage.view.stageWidth, that._stage.view.stageHeight);
                that.viewComponent.background.endFill();
                that.viewComponent.companyLogo.x = (that._stage.view.stageWidth - that.viewComponent.companyLogo.width) / 2;
                that.viewComponent.companyLogo.y = (that._stage.view.stageHeight - that.viewComponent.companyLogo.height) / 2;
                that.viewComponent.progressBarFixed.x = (that._stage.view.stageWidth - that.viewComponent.progressBarFixed.width) / 2;
                that.viewComponent.progressBarFixed.y = that.viewComponent.companyLogo.y + that.viewComponent.companyLogo.height + 50;
                that.viewComponent.progressBar.x = that.viewComponent.progressBarFixed.x;
                that.viewComponent.progressBar.y = that.viewComponent.progressBarFixed.y;
                that.viewComponent.star.y = that.viewComponent.progressBar.y - (that.viewComponent.star.height - that.viewComponent.progressBar.height) / 2;
                that.viewComponent.progressPercentage.y = that.viewComponent.progressBar.y + that.viewComponent.progressBar.height + 10;
                that.viewComponent.progress = that.viewComponent.progress;
            }
            onOrientationChange();
            if (MOB) {
                window.addEventListener('orientationchange', onOrientationChange);
            }
        };
        GameLoadingMediator.prototype.onStartLoadingGame = function (event) {
            trace(gpts.ELogger.PORTAL, 'start loading game');
            this._integrated = event.target.vars.integrated;
            this._stage.view.stage.addChild(this.viewComponent);
            this.viewComponent.progress = 0;
            this._stage.view.stage.visible = true;
        };
        GameLoadingMediator.prototype.onFailLoadingGame = function (event) {
            trace(gpts.ELogger.PORTAL, 'fail loading game');
            TweenMax.killTweensOf(this.viewComponent);
            if (this.viewComponent.parent != null) {
                this._stage.view.stage.removeChild(this.viewComponent);
            }
            if (event.type == gpts.GameEvent.FAIL_INTEGRATION) {
                this.configureListeners(false);
                this._game = null;
                if (!this.app_facade.singleGameMode)
                    this._router.redirectTo('homepage', { groupId: this._router.oldParameters.groupId });
                this.app_facade.removeProxy(this._router.oldParameters.gameIdentificationNumber);
            }
        };
        GameLoadingMediator.prototype.onCompleteLoadingGame = function (event) {
            trace(gpts.ELogger.PORTAL, 'complete loading game');
            var that = this;
            if (this._integrated) {
                TweenMax.to(this.viewComponent, GameLoadingMediator.PROGRESS_TIME, { progress: 0.5 });
                this._game = event.target.content;
                this.configureListeners();
            }
            else {
                TweenMax.to(this.viewComponent, GameLoadingMediator.PROGRESS_TIME, {
                    progress: 1,
                    onComplete: function () {
                        that._stage.view.stage.removeChild(that.viewComponent);
                    }
                });
                if (!this.app_facade.singleGameMode)
                    this.app_facade.sendNotification(gpts.AppFacade.PLAY_SOUND, gpts.AppFacade.SHOW_GAME);
            }
        };
        GameLoadingMediator.prototype.configureListeners = function (add) {
            if (add === void 0) { add = true; }
            this._game[add ? 'addEventListener' : 'removeEventListener'](gpts.GameEvent.INTEGRATED_PROGRESS, this.onIntegratedProgress, this);
            this._game[add ? 'addEventListener' : 'removeEventListener'](gpts.GameEvent.COMPLETE_INTEGRATION, this.onIntegratedProgressComplete, this);
            this._game[add ? 'addEventListener' : 'removeEventListener'](gpts.GameEvent.FAIL_INTEGRATION, this.onFailLoadingGame, this);
        };
        GameLoadingMediator.prototype.onIntegratedProgress = function (event) {
            TweenMax.to(this.viewComponent, GameLoadingMediator.PROGRESS_TIME, { progress: 0.5 + 0.5 * event.data.progress / 2 });
        };
        GameLoadingMediator.prototype.onIntegratedProgressComplete = function (event) {
            trace(gpts.ELogger.PORTAL, 'complete integrated progress');
            this.configureListeners(false);
            this._game = null;
            var that = this;
            var gameProxy = that.app_facade.retrieveProxy(this._router.parameters.gameIdentificationNumber);
            TweenMax.to(this.viewComponent, GameLoadingMediator.PROGRESS_TIME, {
                progress: 1,
                onComplete: function () {
                    that._stage.view.stage.removeChild(that.viewComponent);
                    if (!that.app_facade.singleGameMode) {
                        that.app_facade.sendNotification(gpts.AppFacade.PLAY_SOUND, gpts.AppFacade.SHOW_GAME);
                    }
                    gameProxy.startGame();
                }
            });
        };
        GameLoadingMediator.prototype.handleNotification = function (notification) {
            _super.prototype.handleNotification.call(this, notification);
            switch (notification.getName()) {
                case gpts.Router.CHANGE_PAGE:
                    this.sendFront();
                    if (this._router.page == gpts.Router.SINGLE_GAME_PAGE) {
                        var gameProxy = this.app_facade.retrieveProxy(this._router.parameters.gameIdentificationNumber);
                        var gameLoader = LoaderMax.getLoader(gameProxy.interests());
                        if (gameLoader.vars && gameLoader.vars.integrated) {
                            this._game = gameLoader.content;
                            this._integrated = true;
                            this.configureListeners();
                            this._stage.view.stage.addChild(this.viewComponent);
                            this.viewComponent.progress = 0.5;
                        }
                    }
                    else if (this._router.page == gpts.Router.HOME_PAGE) {
                        var gameProxy = this.app_facade.retrieveProxy(this._router.oldParameters.gameIdentificationNumber);
                        if (gameProxy instanceof IGame && gameProxy.filtered()) {
                            trace(gpts.ELogger.PORTAL, 'filter game: ' + gameProxy.getProxyName());
                            TweenMax.killTweensOf(this.viewComponent);
                            if (this.viewComponent.parent != null) {
                                this._stage.view.stage.removeChild(this.viewComponent);
                            }
                            if (this._game) {
                                this.configureListeners(false);
                                this._game = null;
                            }
                        }
                    }
                    break;
            }
        };
        GameLoadingMediator.NAME = 'GameLoadingMediator';
        GameLoadingMediator.PROGRESS_TIME = 0.3;
        return GameLoadingMediator;
    }(gpts.BaseMediator));
    gpts.GameLoadingMediator = GameLoadingMediator;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var StaticControls = (function (_super) {
        __extends(StaticControls, _super);
        function StaticControls() {
            return _super.call(this) || this;
        }
        return StaticControls;
    }(gpts.Holder));
    gpts.StaticControls = StaticControls;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Point = PIXI.Point;
    var Hash = gamy.Hash;
    var Capabilities = gamy.Capabilities;
    var EVENT_TYPE = gamy.EVENT_TYPE;
    var MagnifierScroll = (function () {
        function MagnifierScroll(container, holder, frame, options) {
            this._container = container;
            this._holder = holder;
            this._frame = frame;
            this._options = new Hash({ time: .5, padding: new Point() }).merge(options);
            this._padding = this._options.padding instanceof Point ? this._options.padding : new Point(this._options.padding, this._options.padding);
            delete this._options.padding;
        }
        MagnifierScroll.prototype._onMouseMove = function (event) {
            this.update(event);
        };
        MagnifierScroll.prototype.start = function () {
            this._container.on(Capabilities.eventType(EVENT_TYPE.MOVE), this._onMouseMove, this);
        };
        MagnifierScroll.prototype.stop = function () {
            this._container.off(Capabilities.eventType(EVENT_TYPE.MOVE), this._onMouseMove, this);
        };
        MagnifierScroll.prototype._update = function (local, pos_metric, dim_metric) {
            if (this._frame[dim_metric] < this._holder[dim_metric]) {
                var first_local = local;
                var left_margin = this._frame[pos_metric] + this._padding[pos_metric];
                var right_margin = this._frame[pos_metric] + this._frame[dim_metric] - 2 * this._padding[pos_metric];
                local = Math.max(left_margin, Math.min(right_margin, local));
                local -= (this._frame[pos_metric] + this._padding[pos_metric]);
                var tweenParams = this._options.dup();
                tweenParams[pos_metric] = Math.round((local + this._frame[pos_metric]) - local * ((this._holder[dim_metric] - 3 * this._padding[pos_metric]) / (right_margin - left_margin)));
                TweenMax.to(this._holder, tweenParams.time, tweenParams.withoutKeys('time').toObject());
            }
            else {
                var snap = this._options.dup();
                snap[pos_metric] = this._frame[pos_metric];
                TweenMax.to(this._holder, snap.time, snap.withoutKeys('time').toObject());
            }
        };
        MagnifierScroll.prototype.update = function (event) {
            if (this._frame.width)
                this._update(event.data.getLocalPosition(this._container).x, 'x', 'width');
            if (this._frame.height)
                this._update(event.data.getLocalPosition(this._container).y, 'y', 'height');
        };
        MagnifierScroll.prototype.dispose = function () {
            this.stop();
            TweenMax.killTweensOf(this._holder);
            this._container = null;
            this._holder = null;
        };
        Object.defineProperty(MagnifierScroll.prototype, "frame", {
            get: function () {
                return this._frame;
            },
            set: function (value) {
                this._frame = value;
            },
            enumerable: true,
            configurable: true
        });
        return MagnifierScroll;
    }());
    gpts.MagnifierScroll = MagnifierScroll;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Rectangle = PIXI.Rectangle;
    var Hash = gamy.Hash;
    var Graphics = PIXI.Graphics;
    var LanguageBar = (function (_super) {
        __extends(LanguageBar, _super);
        function LanguageBar(languages, createFlag, createCurrent, options) {
            var _this = _super.call(this, options) || this;
            _this.container = new gpts.Holder();
            _this.holder = new gpts.Holder();
            _this._options = new Hash({ maxVisible: 3, distance: 10 }).merge(_this._options);
            var length = languages.length;
            for (var i = 0; i < length; i++) {
                var button = createFlag instanceof Function ? createFlag(languages[i]) : new gpts.Button();
                button.setState('idle');
                button.y = i * button.height;
                button.interactive = true;
                button.buttonMode = true;
                button.name = languages[i];
                _this.holder.addChild(button);
            }
            _this.current = createCurrent instanceof Function ? createCurrent(languages) : null;
            if (_this.current)
                _this.addChild(_this.current);
            if (length > 1) {
                _this.special_height = button.height * Math.min(_this._options.maxVisible, length);
                _this.container.interactive = true;
                _this.container.addChild(_this.holder);
                _this.addChildAt(_this.container, 0);
                _this.container.y = -_this.special_height - _this._options.distance;
                if (length > 2) {
                    var holderMask = new Graphics();
                    holderMask.beginFill(0xff0000, .5);
                    holderMask.drawRect(0, 0, button.width, _this.special_height);
                    holderMask.endFill();
                    _this.holder.mask = holderMask;
                    _this.container.addChildAt(holderMask, 0);
                    _this.scroll = new gpts.MagnifierScroll(_this.container, _this.holder, new Rectangle(0, 0, 0, _this.special_height), { padding: 10 });
                }
            }
            return _this;
        }
        LanguageBar.prototype.prepareHolderBeforeScrollStart = function () {
            this.holder.y = -(this.holder.height - this.special_height);
        };
        return LanguageBar;
    }(gpts.Holder));
    gpts.LanguageBar = LanguageBar;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var services;
    (function (services) {
        var MessagesEvent = (function () {
            function MessagesEvent(type, data, messageId) {
                if (data === void 0) { data = null; }
                if (messageId === void 0) { messageId = null; }
                this.type = type;
                this._data = data;
                this.message_id = messageId;
            }
            Object.defineProperty(MessagesEvent.prototype, "data", {
                get: function () {
                    return this._data;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(MessagesEvent.prototype, "messageId", {
                get: function () {
                    return this.message_id;
                },
                enumerable: true,
                configurable: true
            });
            MessagesEvent.MESSAGE = 'onMessageSuccess';
            MessagesEvent.TIME_OUT = 'onTimeOutMessage';
            MessagesEvent.LOOSE_CONNECTION = 'onLooseConnection';
            return MessagesEvent;
        }());
        services.MessagesEvent = MessagesEvent;
    })(services = gpts.services || (gpts.services = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Mediator = puremvc.Mediator;
    var Capabilities = gamy.Capabilities;
    var DeviceOrientation = gamy.DeviceOrientation;
    var StageMediator = (function (_super) {
        __extends(StageMediator, _super);
        function StageMediator() {
            return _super.call(this, StageMediator.NAME) || this;
        }
        StageMediator.prototype.onRegister = function () {
            _super.prototype.onRegister.call(this);
            this.viewComponent = new gpts.Stage({
                canvasID: gpts.Main.CANVAS_ID,
                stageWidth: gpts.PortalProxy.STAGE_WIDTH,
                stageHeight: gpts.PortalProxy.STAGE_HEIGHT,
                visibleWidth: gpts.PortalProxy.VISIBLE_WIDTH,
                visibleHeight: gpts.PortalProxy.VISIBLE_HEIGHT
            });
            if (MOB) {
                this.onOrientationChange();
                var that_2 = this;
                window.addEventListener('orientationchange', function () {
                    that_2.onOrientationChange();
                });
            }
        };
        StageMediator.prototype.shouldDisplayWideResolution = function () {
            var gin = gpts.AppFacade.getInstance().gameIdentificationNumber;
            var isGameSupportingWideResolution = StageMediator.gamesSupportingWideResolutions.indexOf(gin.toString()) !== -1;
            return isGameSupportingWideResolution;
        };
        StageMediator.prototype.onOrientationChange = function () {
            if (this.shouldDisplayWideResolution()) {
                this.viewComponent.overrideAspect(gpts.StageInfo.width, gpts.StageInfo.height);
            }
            else {
                if (Capabilities.orientation == DeviceOrientation.landscapePrimary || Capabilities.orientation == DeviceOrientation.landscapeSecondary) {
                    this.viewComponent.overrideAspect(gpts.PortalProxy.STAGE_WIDTH, gpts.PortalProxy.STAGE_HEIGHT);
                }
                else {
                    this.viewComponent.overrideAspect(gpts.PortalProxy.STAGE_HEIGHT, gpts.PortalProxy.STAGE_WIDTH);
                }
            }
        };
        Object.defineProperty(StageMediator.prototype, "view", {
            get: function () {
                return this.viewComponent;
            },
            enumerable: true,
            configurable: true
        });
        StageMediator.NAME = 'StageMediator';
        StageMediator.gamesSupportingWideResolutions = [
            '200',
            '3',
            '11',
            '13',
            '14',
        ];
        return StageMediator;
    }(Mediator));
    gpts.StageMediator = StageMediator;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Capabilities = gamy.Capabilities;
    var EVENT_TYPE = gamy.EVENT_TYPE;
    var SliderNavigationItem = (function (_super) {
        __extends(SliderNavigationItem, _super);
        function SliderNavigationItem(src) {
            return _super.call(this, src, { supportedStates: { selected: 0xff0000 } }) || this;
        }
        SliderNavigationItem.prototype.setState = function (value) {
            _super.prototype.setState.call(this, value);
            if (value == 'selected') {
                this.interactive = false;
                this.buttonMode = false;
            }
            else {
                this.interactive = true;
                this.buttonMode = true;
            }
        };
        SliderNavigationItem.prototype.dispose = function () {
            _super.prototype.dispose.call(this);
            this.removeAllListeners(Capabilities.eventType(EVENT_TYPE.CLICK));
        };
        SliderNavigationItem.prototype.setLabelText = function (value) {
            this.label.text = value;
            this.label.x = (this.width - this.label.width) / 2;
            this.label.y = (this.height - this.label.height) / 2;
        };
        return SliderNavigationItem;
    }(gpts.Button));
    gpts.SliderNavigationItem = SliderNavigationItem;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Hash = gamy.Hash;
    var SliderNavigation = (function (_super) {
        __extends(SliderNavigation, _super);
        function SliderNavigation(options) {
            var _this = _super.call(this, options) || this;
            _this.selected_index = -1;
            _this.visible_first_index = 0;
            _this.visible_last_index = 0;
            _this._options = new Hash({
                maxVisible: 3,
                cyclic: true,
                count: 10,
                getSlideId: function (serialNumber) {
                    return 0;
                }
            }).merge(_this._options);
            _this._getSlideId = _this._options.getSlideId;
            _this._cyclic = _this._options.cyclic;
            _this.max_visible = _this._cyclic ? Math.min(_this._options.count, _this._options.maxVisible) : _this._options.count;
            _this.visible_last_index = _this.max_visible - 1;
            if (!_this._cyclic)
                _this.displayVisible();
            _this.selectedIndex = 0;
            return _this;
        }
        Object.defineProperty(SliderNavigation.prototype, "selectedIndex", {
            set: function (value) {
                if (this._cyclic) {
                    this.selected_index = value;
                    if (this.selected_index > this.visible_last_index) {
                        this.visible_last_index = this.selected_index;
                        this.visible_first_index = this.visible_last_index - this.max_visible + 1;
                    }
                    if (this.selected_index < this.visible_first_index) {
                        this.visible_first_index = this.selected_index;
                        this.visible_last_index = this.visible_first_index + this.max_visible - 1;
                    }
                    this.displayVisible();
                }
                else {
                    if (this.selected_index != value) {
                        if (this.selected_index > -1) {
                            var oldSelectedItem = this.getChildAt(this.selected_index);
                            oldSelectedItem.setState('idle');
                        }
                        this.selected_index = value;
                        var newSelectedItem = this.getChildAt(this.selected_index);
                        newSelectedItem.setState('selected');
                    }
                }
            },
            enumerable: true,
            configurable: true
        });
        SliderNavigation.prototype.displayVisible = function () {
            for (var i = this.visible_first_index; i < this.visible_last_index + 1; i++) {
                try {
                    var child = this.getChildAt(i - this.visible_first_index);
                }
                catch (error) {
                    child = new gpts.SliderNavigationItem(this._options.itemFrames ? new gpts.SpriteSheet(this._options.itemFrames) : null);
                    child.setState('idle');
                    child.x = (child.width + 3) * (i - this.visible_first_index);
                    this.addChild(child);
                }
                child.name = String(i);
                child.setLabelText(String(this._getSlideId(i) + 1));
                child.setState(child.name == String(this.selected_index) ? 'selected' : 'idle');
            }
        };
        Object.defineProperty(SliderNavigation.prototype, "cyclic", {
            get: function () {
                return this._cyclic;
            },
            enumerable: true,
            configurable: true
        });
        return SliderNavigation;
    }(gpts.Holder));
    gpts.SliderNavigation = SliderNavigation;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var ISlider = (function () {
        function ISlider() {
        }
        Object.defineProperty(ISlider.prototype, "slide", {
            get: function () {
                return 0;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(ISlider.prototype, "oldSlide", {
            get: function () {
                return 0;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(ISlider.prototype, "isSliding", {
            get: function () {
                return false;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(ISlider.prototype, "isDragging", {
            get: function () {
                return false;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(ISlider.prototype, "acceptClick", {
            get: function () {
                return false;
            },
            enumerable: true,
            configurable: true
        });
        return ISlider;
    }());
    gpts.ISlider = ISlider;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Point = PIXI.Point;
    var Mouse = (function () {
        function Mouse(container) {
            this._cm = new Point(0, 0);
            this._pm = new Point(0, 0);
            this._md = new Point(0, 0);
            this._container = container;
        }
        Mouse.prototype.start = function (data) {
            this._md = this._cm = this._pm = data.getLocalPosition(this._container);
            this.mouse_down = true;
        };
        Mouse.prototype.move = function (data) {
            this._pm = this._cm;
            this._cm = data.getLocalPosition(this._container);
            this.mouse_move = true;
        };
        Mouse.prototype.end = function () {
            this.mouse_down = this.mouse_move = false;
        };
        Mouse.prototype.dispose = function () {
            this._container = null;
        };
        Object.defineProperty(Mouse.prototype, "cm", {
            get: function () {
                return this._cm;
            },
            set: function (value) {
                this._cm = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Mouse.prototype, "pm", {
            get: function () {
                return this._pm;
            },
            set: function (value) {
                this._pm = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Mouse.prototype, "speedX", {
            get: function () {
                return Math.abs(this._cm.x - this._pm.x);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Mouse.prototype, "speedY", {
            get: function () {
                return Math.abs(this._cm.y - this._pm.y);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Mouse.prototype, "directionX", {
            get: function () {
                return this._cm.x > this._pm.x;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Mouse.prototype, "directionY", {
            get: function () {
                return this._cm.y > this._pm.y;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Mouse.prototype, "md", {
            get: function () {
                return this._md;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Mouse.prototype, "mouseDown", {
            get: function () {
                return this.mouse_down;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Mouse.prototype, "mouseMove", {
            get: function () {
                return this.mouse_move;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Mouse.prototype, "nearTheStartPosition", {
            get: function () {
                return Mouse.distance(this._md, this._cm) < 10;
            },
            enumerable: true,
            configurable: true
        });
        Mouse.distance = function (p1, p2) {
            return Math.sqrt((p1.x - p2.x) * (p1.x - p2.x) + (p1.y - p2.y) * (p1.y - p2.y));
        };
        return Mouse;
    }());
    gpts.Mouse = Mouse;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Hash = gamy.Hash;
    var trace = gamy.trace;
    var Graphics = PIXI.Graphics;
    var Capabilities = gamy.Capabilities;
    var EVENT_TYPE = gamy.EVENT_TYPE;
    var Rectangle = PIXI.Rectangle;
    var log = gamy.log;
    var isMobile = gamy.isMobile;
    var Slider = (function (_super) {
        __extends(Slider, _super);
        function Slider(container, holder, options) {
            var _this = _super.call(this) || this;
            _this.old_slide = 0;
            _this._slide = 0;
            _this.options = new Hash({
                width: 800,
                height: 600,
                finite: true,
                slidesAmount: 1,
                time: 1,
                maxSpeed: 15,
                delay: 0,
                ease: Quint.easeOut,
                onStartSlide: function (slide) {
                    trace(gpts.ELogger.PORTAL, 'start slide: ' + slide);
                },
                onCompleteSlide: function (slide) {
                    trace(gpts.ELogger.PORTAL, 'complete slide:' + slide);
                }
            }).merge(options);
            _this.container = container;
            _this.holder = holder;
            _this._mouse = new gpts.Mouse(_this.container);
            _this.container.hitArea = new Rectangle(0, 0, _this.options.width, _this.options.height);
            var graphics = new Graphics();
            graphics.beginFill(0xffffff);
            graphics.drawRect(0, 0, 1, 1);
            graphics.endFill();
            _this.holder.addChild(graphics);
            return _this;
        }
        Slider.prototype.getSlideSerialNumber = function (data) {
            return Math.floor((data.getLocalPosition(this.container).x - this.holder.x) / this.options.width);
        };
        Slider.prototype.onCompleteSlideAnimation = function () {
            this.options.onCompleteSlide.call(null, this._slide);
        };
        Slider.prototype.setSlide = function (value, doNotAnimate) {
            if (doNotAnimate === void 0) { doNotAnimate = false; }
            trace(gpts.ELogger.PORTAL, 'set slide: ' + value);
            if (this.options.finite) {
                if (value < 0)
                    value = 0;
                else if (value > this.options.slidesAmount - 1)
                    value = this.options.slidesAmount - 1;
            }
            this.old_slide = this._slide;
            this._slide = value;
            this.options.onStartSlide.call(null, this._slide);
            if (doNotAnimate) {
                this.holder.x = -this._slide * this.options.width;
                this.onCompleteSlideAnimation();
                return;
            }
            var that = this;
            var time = this.calculateTweenTime();
            trace(gpts.ELogger.PORTAL, 'slider:time', time);
            TweenMax.to(this.holder, time, {
                overwrite: 1,
                delay: this.options.delay,
                x: -this._slide * this.options.width,
                ease: this.options.ease,
                roundProps: ['x'],
                onComplete: function () {
                    that.onCompleteSlideAnimation();
                }
            });
        };
        Slider.prototype.calculateTweenTime = function () {
            var translationX = Math.abs(this.holder.x + this._slide * this.options.width);
            return translationX > (this.options.width / 2) ? this.options.time : gamy.Circ.easeOut(translationX, 0, this.options.time, this.options.width / 2);
        };
        Slider.prototype.getSlideId = function (serialNumber) {
            var slides = this.options.slidesAmount;
            return serialNumber % slides + (serialNumber < 0 && serialNumber % slides != 0 ? slides : 0);
        };
        Slider.prototype.dispose = function () {
            trace(gpts.ELogger.PORTAL, 'dispose Slider');
            TweenMax.killTweensOf(this.holder);
            this.container.off(Capabilities.eventType(EVENT_TYPE.DOWN), this.onMouseDown);
            this.configureMoveListeners(false);
            this.container = null;
            this.holder = null;
            this._mouse.dispose();
            this._mouse = null;
        };
        Slider.prototype.attach = function () {
            trace(gpts.ELogger.PORTAL, 'slider:attach');
            this.container.on(Capabilities.eventType(EVENT_TYPE.DOWN), this.onMouseDown, this);
            this.container.interactive = true;
        };
        Slider.prototype.detach = function () {
            this.container.off(Capabilities.eventType(EVENT_TYPE.DOWN), this.onMouseDown);
            this.container.interactive = false;
        };
        Slider.prototype.configureMoveListeners = function (add) {
            if (add === void 0) { add = true; }
            if (add) {
                this.container.on(Capabilities.eventType(EVENT_TYPE.MOVE), this.onMouseMove, this);
                this.container.on(Capabilities.eventType(EVENT_TYPE.UP), this.onMouseUp, this);
                this.container.on(Capabilities.eventType(EVENT_TYPE.OUT), this.onMouseOut, this);
            }
            else {
                this.container.off(Capabilities.eventType(EVENT_TYPE.MOVE), this.onMouseMove);
                this.container.off(Capabilities.eventType(EVENT_TYPE.UP), this.onMouseUp);
                this.container.off(Capabilities.eventType(EVENT_TYPE.OUT), this.onMouseOut);
            }
        };
        Slider.prototype.primaryTouchPointCheck = function (event) {
            return isMobile() && event.data.identifier != this.primary_touch_point_id;
        };
        Slider.prototype.onMouseDown = function (event) {
            trace(gpts.ELogger.PORTAL, 'slider:down' + Capabilities.isPrimaryTouchPoint(event));
            log(true, 'slider:down', event);
            if (isMobile()) {
                if (isNaN(this.primary_touch_point_id))
                    this.primary_touch_point_id = event.data.identifier;
                else
                    return;
            }
            this.holder_position_x = this.holder.x;
            this._mouse.start(event.data);
            this.dragged_sn = this.getSlideSerialNumber(event.data);
            TweenMax.killTweensOf(this.holder);
            this.configureMoveListeners();
        };
        Slider.prototype.onMouseMove = function (event) {
            if (this.primaryTouchPointCheck(event))
                return;
            this._mouse.move(event.data);
            this.holder.x = this.holder_position_x + this._mouse.cm.x - this._mouse.md.x;
        };
        Slider.prototype.onMouseUp = function (event) {
            if (event)
                trace(gpts.ELogger.PORTAL, 'slider:up' + Capabilities.isPrimaryTouchPoint(event));
            log(true, 'slider:up', event);
            if (event && this.primaryTouchPointCheck(event))
                return;
            this.primary_touch_point_id = NaN;
            this.configureMoveListeners(false);
            this._mouse.end();
            var draggedPosX = this.holder.x + this.dragged_sn * this.options.width;
            var center = this.options.width / 2;
            var minSpeed = 3;
            if (-draggedPosX > center) {
                if (this._mouse.speedX < minSpeed)
                    this.setSlide(this.dragged_sn + 1);
                else if (this._mouse.directionX)
                    this.setSlide(this.dragged_sn);
                else
                    this.setSlide(this.dragged_sn + 1);
            }
            else if (draggedPosX > center) {
                if (this._mouse.speedX < 3)
                    this.setSlide(this.dragged_sn - 1);
                else if (this._mouse.directionX)
                    this.setSlide(this.dragged_sn - 1);
                else
                    this.setSlide(this.dragged_sn);
            }
            else if (draggedPosX < 0) {
                if (this._mouse.speedX < 3)
                    this.setSlide(this.dragged_sn);
                else if (this._mouse.directionX)
                    this.setSlide(this.dragged_sn);
                else {
                    if (this._mouse.speedX < this.options.maxSpeed)
                        this.setSlide(this.dragged_sn);
                    else
                        this.setSlide(this.dragged_sn + 1);
                }
            }
            else if (draggedPosX > 0) {
                if (this._mouse.speedX < 3)
                    this.setSlide(this.dragged_sn);
                else if (this._mouse.directionX) {
                    if (this._mouse.speedX < this.options.maxSpeed)
                        this.setSlide(this.dragged_sn);
                    else
                        this.setSlide(this.dragged_sn - 1);
                }
                else
                    this.setSlide(this.dragged_sn);
            }
            else
                this.setSlide(this.dragged_sn);
        };
        Slider.prototype.onMouseOut = function (event) {
            if (this.primaryTouchPointCheck(event))
                return;
            if (this._mouse.mouseDown)
                this.onMouseUp();
        };
        Object.defineProperty(Slider.prototype, "slide", {
            get: function () {
                return this._slide;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Slider.prototype, "oldSlide", {
            get: function () {
                return this.old_slide;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Slider.prototype, "isSliding", {
            get: function () {
                return TweenMax.isTweening(this.holder);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Slider.prototype, "isDragging", {
            get: function () {
                return this._mouse.mouseMove;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Slider.prototype, "acceptClick", {
            get: function () {
                return this._mouse.nearTheStartPosition;
            },
            enumerable: true,
            configurable: true
        });
        return Slider;
    }(gpts.ISlider));
    gpts.Slider = Slider;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Holder = gpts.Holder;
    var trace = gamy.trace;
    var Slide = (function (_super) {
        __extends(Slide, _super);
        function Slide(id) {
            if (id === void 0) { id = 0; }
            var _this = _super.call(this) || this;
            _this.id = id;
            return _this;
        }
        Slide.prototype.dispose = function () {
            _super.prototype.dispose.call(this);
            var child = this.getChildByName('marker');
            if (child)
                this.removeChild(child);
            trace(gpts.ELogger.PORTAL, 'dispose Slide');
        };
        return Slide;
    }(Holder));
    gpts.Slide = Slide;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Holder = gpts.Holder;
    var Hash = gamy.Hash;
    var trace = gamy.trace;
    var Sprite = PIXI.Sprite;
    var Navigation = (function (_super) {
        __extends(Navigation, _super);
        function Navigation(slides, drawSlide, options) {
            var _this = _super.call(this, options) || this;
            _this.container = new Holder();
            _this.holder = new Holder();
            _this.visible_slides = [];
            _this._slides = slides;
            _this.draw_slide = drawSlide;
            if (_this._slides > 0) {
                _this.addChild(_this.container);
                _this.container.addChild(_this.holder);
                _this.marker = new Sprite(_this._options.markerTexture || new PIXI.Texture(new PIXI.BaseTexture(null)));
                _this.marker.name = 'marker';
            }
            if (_this._slides > 1) {
                var that_3 = _this;
                _this._slider = new gpts.Slider(_this.container, _this.holder, new Hash({
                    slidesAmount: _this._slides,
                    onStartSlide: function (slide) {
                        that_3.onStartSlide();
                    },
                    onCompleteSlide: function (slide) {
                        that_3.onCompleteSlide(slide);
                    }
                }).merge(_this._options.slider));
                _this._slider.attach();
                _this.sliderNavigation = new gpts.SliderNavigation(new Hash(_this._options.sliderNav).merge({
                    getSlideId: function (serialNumber) {
                        return that_3._slider.getSlideId(serialNumber);
                    }
                }));
                _this.addChild(_this.sliderNavigation);
                _this.prevNext = new gpts.SliderPrevNext(_this._options.sliderNav.rightArrowFrames);
                _this.addChild(_this.prevNext);
                _this._slider.setSlide(0, true);
            }
            else if (_this._slides == 1) {
                _this.visible_slides = [_this.createSlide()];
                _this.holder.addChildren(_this.visible_slides);
            }
            return _this;
        }
        Navigation.prototype.onCompleteSlide = function (slide) {
            this.sliderNavigation.selectedIndex = this.sliderNavigation.cyclic ? slide : this._slider.getSlideId(slide);
        };
        Navigation.prototype.onStartSlide = function () {
            var garbage;
            var slide = this._slider.slide;
            var oldSlide = this._slider.oldSlide;
            if (slide == oldSlide + 1) {
                garbage = this.visible_slides.splice(0, 1)[0];
                if (garbage instanceof gpts.Slide)
                    this.holder.removeChild(garbage);
                this.visible_slides.push(this.createSlide(slide + 1));
            }
            else if (slide == oldSlide - 1) {
                garbage = this.visible_slides.splice(this.visible_slides.length - 1, 1)[0];
                if (garbage instanceof gpts.Slide)
                    this.holder.removeChild(garbage);
                this.visible_slides.unshift(this.createSlide(slide - 1));
            }
            else {
                this.holder.removeChildren();
                this.visible_slides = [
                    this.createSlide(slide - 1),
                    this.createSlide(slide),
                    this.createSlide(slide + 1)
                ];
            }
            this.holder.addChildren(this.visible_slides);
        };
        Navigation.prototype.createSlide = function (serialNumber) {
            if (serialNumber === void 0) { serialNumber = 0; }
            var slide = new gpts.Slide(this._slider != null ? this._slider.getSlideId(serialNumber) : serialNumber);
            trace(gpts.ELogger.PORTAL, 'create slide', 'id:' + slide.id, 'serialNumber: ' + serialNumber);
            return this.draw_slide(slide).attrs({ x: (this._slider != null ? serialNumber * this._slider.options.width : 0) });
        };
        Object.defineProperty(Navigation.prototype, "slider", {
            get: function () {
                return this._slider;
            },
            enumerable: true,
            configurable: true
        });
        Navigation.prototype.dispose = function () {
            trace(gpts.ELogger.PORTAL, 'dispose Navigation');
            _super.prototype.dispose.call(this);
            if (this._slider) {
                this._slider.dispose();
                this._slider = null;
            }
            this.visible_slides.length = 0;
            this.container = null;
            this.holder = null;
            this.sliderNavigation = null;
            this.prevNext = null;
            this.marker = null;
            this.preorder(function (child) {
                if (child instanceof Sprite)
                    child.destroy(false);
                else
                    child.destroy();
            });
        };
        return Navigation;
    }(Holder));
    gpts.Navigation = Navigation;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Capabilities = gamy.Capabilities;
    var EVENT_TYPE = gamy.EVENT_TYPE;
    var Point = PIXI.Point;
    var NavigationItem = (function (_super) {
        __extends(NavigationItem, _super);
        function NavigationItem(src) {
            return _super.call(this, src, {
                supportedStates: {
                    down: 0xff0000,
                    over: 0x000000,
                    selected: 0x0000ff
                },
                defaultGraphics: false,
                enableEff: true
            }) || this;
        }
        NavigationItem.prototype.onDown = function (event) {
            if (this.src) {
                var scaleFactor = 0.97;
                this.src.x = (1 - scaleFactor) * this.src.width / 2;
                this.src.y = (1 - scaleFactor) * this.src.height / 2;
                this.src.scale.set(scaleFactor, scaleFactor);
            }
        };
        NavigationItem.prototype.onOver = function (event) {
            if (this.src)
                this.overIcon.visible = true;
        };
        NavigationItem.prototype.onUp = function (event) {
            if (this.src) {
                this.overIcon.visible = false;
                this.src.scale.set(1, 1);
                this.src.x = this.src.y = 0;
            }
        };
        NavigationItem.prototype.dispose = function () {
            _super.prototype.dispose.call(this);
            this.removeAllListeners(Capabilities.eventType(EVENT_TYPE.CLICK));
            this.removeAllListeners('mouseover');
            this.activeGameIcon = null;
            this.recoveryIcon = null;
            this.jackpotIcon = null;
            this.featuredIcon = null;
            this.overIcon = null;
        };
        NavigationItem.OVER_ICON_POS = new Point(-2, -2);
        NavigationItem.BONUS_ICON_MARGIN_TOP = 15;
        NavigationItem.BONUS_ICON_MARGIN_LEFT = 15;
        return NavigationItem;
    }(gpts.Button));
    gpts.NavigationItem = NavigationItem;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Proxy = puremvc.Proxy;
    var Hash = gamy.Hash;
    var LoaderMax = gamy.LoaderMax;
    var Loader = PIXI.loaders.Loader;
    var trace = gamy.trace;
    var Rectangle = PIXI.Rectangle;
    var IconLoaderMapItem = (function () {
        function IconLoaderMapItem(loader, hasLoaded, url) {
            this.hasLoaded = false;
            this.loader = loader;
            this.hasLoaded = hasLoaded;
            this.url = url;
        }
        return IconLoaderMapItem;
    }());
    var GameIcon = (function () {
        function GameIcon(gameType, frames) {
            this.gameType = gameType;
            this.frames = frames;
        }
        return GameIcon;
    }());
    gpts.GameIcon = GameIcon;
    var NavigationProxy = (function (_super) {
        __extends(NavigationProxy, _super);
        function NavigationProxy(groupId) {
            var _this = _super.call(this, NavigationProxy.NAME) || this;
            _this.app_facade = gpts.AppFacade.getInstance();
            _this._list = [];
            _this._status = new Hash();
            _this._slides = 0;
            _this.group_id = groupId;
            return _this;
        }
        NavigationProxy.prototype.onRegister = function () {
            _super.prototype.onRegister.call(this);
            this.filterGamesList();
            this.updateStatusHash();
            this._slides = !this._list.length ? 0 : Math.ceil(this._list.length / NavigationProxy.POSITIONS.length);
            if (!NavigationProxy._iconLoaderMap) {
                NavigationProxy.generateIconLoaderMap();
                NavigationProxy.configureIconLoaderListeners();
            }
        };
        NavigationProxy.configureIconLoaderListeners = function () {
            var keys = Object.keys(NavigationProxy._iconLoaderMap);
            for (var _i = 0, keys_9 = keys; _i < keys_9.length; _i++) {
                var name = keys_9[_i];
                var item = NavigationProxy._iconLoaderMap[name];
                item.loader.on('complete', NavigationProxy.onCompleteLoadingIcon);
            }
        };
        NavigationProxy.onCompleteLoadingIcon = function (loader, options) {
            var keys = Object.keys(NavigationProxy._iconLoaderMap);
            for (var _i = 0, keys_10 = keys; _i < keys_10.length; _i++) {
                var name = keys_10[_i];
                var item = NavigationProxy._iconLoaderMap[name];
                if (item.loader === loader) {
                    if (!loader.resources[name + '_idle'].texture.baseTexture.hasLoaded) {
                        trace(gpts.ELogger.NAVIGATION_PROXY, 'error on icon parse: ' + item.url);
                        return;
                    }
                    item.hasLoaded = true;
                    item.loader.off('complete', NavigationProxy.onCompleteLoadingIcon);
                    trace(gpts.ELogger.NAVIGATION_PROXY, 'icon: ' + item.url + ' has been loaded');
                    var iconIDLETexture = item.loader.resources[name + '_idle'].texture;
                    iconIDLETexture.frame = new Rectangle(0, 0, NavigationProxy.GAME_THUMB_WIDTH, NavigationProxy.GAME_THUMB_HEIGHT);
                    gpts.Router.getInstance().sendNotification(gpts.Router.ICON_HAS_LOADED, new GameIcon(name, [new gpts.Frame(iconIDLETexture, 'idle')]));
                    return;
                }
            }
        };
        NavigationProxy.generateIconLoaderMap = function () {
            NavigationProxy._iconLoaderMap = {};
            trace(gpts.ELogger.NAVIGATION_PROXY, 'generateIconLoaderMap()');
            var keys = Object.keys(gpts.AppFacade.getInstance().originalGamesList);
            for (var _i = 0, keys_11 = keys; _i < keys_11.length; _i++) {
                var name = keys_11[_i];
                var loader = new Loader();
                var item = new IconLoaderMapItem(loader, false, 'assets/' + name + '_idle.png?build=' + BUILD);
                NavigationProxy._iconLoaderMap[name] = item;
                loader.add(name + '_idle', item.url);
            }
        };
        NavigationProxy.prototype.filterGamesList = function () {
            var keys = Object.keys(this.app_facade.gamesList);
            for (var _i = 0, keys_12 = keys; _i < keys_12.length; _i++) {
                var name = keys_12[_i];
                var item = this.app_facade.gamesList[name];
                for (var _a = 0, _b = item.groups; _a < _b.length; _a++) {
                    var group = _b[_a];
                    if (group.name == this.group_id) {
                        item.order = group.order;
                        this._list.push(item);
                        break;
                    }
                }
            }
            this._list.sort(function (a, b) {
                return a.order - b.order;
            });
        };
        NavigationProxy.prototype.sortGamesList = function () {
            var keys = Object.keys(this.app_facade.gamesList);
            for (var _i = 0, keys_13 = keys; _i < keys_13.length; _i++) {
                var name = keys_13[_i];
                var item = this.app_facade.gamesList[name];
                for (var _a = 0, _b = item.groups; _a < _b.length; _a++) {
                    var group = _b[_a];
                    if (group.name == this.group_id) {
                        item.order = group.order;
                        break;
                    }
                }
            }
            this._list = this.app_facade.gamesList.values.sort(function (a, b) {
                return a.order - b.order;
            });
        };
        NavigationProxy.prototype.updateStatusHash = function () {
            for (var _i = 0, _a = this._list; _i < _a.length; _i++) {
                var item = _a[_i];
                this._status[item.gameIdentificationNumber] = {
                    stopped: this.app_facade.gamesRecoveryList[item.gameIdentificationNumber] == gpts.EMessage.FAILURE,
                    isActive: this.app_facade.hasProxy(item.gameIdentificationNumber),
                    inRecovery: this.app_facade.gamesRecoveryList[item.gameIdentificationNumber] != gpts.EMessage.NO_RECOVERY
                };
            }
        };
        NavigationProxy.prototype.getIcon = function (gameType) {
            var item = NavigationProxy._iconLoaderMap[gameType];
            if (!item.hasLoaded) {
                trace(gpts.ELogger.NAVIGATION_PROXY, 'start loading icon: ' + item.url);
                item.loader.load();
                return null;
            }
            return new GameIcon(gameType, [new gpts.Frame(item.loader.resources[gameType + '_idle'].texture, 'idle')]);
        };
        NavigationProxy.prototype.checkForIncorrectGameIdentificationNumber = function (gameIdentificationNumber) {
            if (parseFloat(gameIdentificationNumber) != -1 && this.app_facade.immediatelyClosePopup && !this._status.has(gameIdentificationNumber)) {
                var content = LoaderMax.getContent(gpts.Main.CONTENT);
                var that_4 = this;
                gpts.Alert.show(content.incorrectGIN[gpts.Router.getInstance().language], gpts.PopUpType.OK, {
                    okLabelCallback: function () {
                        that_4.app_facade.sendNotification(gpts.AppFacade.EXIT_PLATFORM);
                    }
                });
                return true;
            }
            return false;
        };
        NavigationProxy.prototype.availableGINForGameType = function (gameType) {
            var gamesList = this.app_facade.originalGamesList[gameType];
            var result = [];
            var length = gamesList.length;
            for (var i = 0; i < length; i++)
                result.push(String(gamesList[i].gameIdentificationNumber));
            return result;
        };
        NavigationProxy.getThumbPositions = function (rows, columns, thumbWidth, thumbHeight, slideWidth, slideHeight) {
            var positions = [];
            var paddingX = (slideWidth - thumbWidth * columns) / (columns + 1);
            var paddingY = (slideHeight - thumbHeight * rows) / (rows + 1);
            var length = rows * columns;
            for (var i = 0; i < length; i++) {
                var j = i % columns;
                var k = Math.floor(i / columns);
                positions[i] = [(j + 1) * paddingX + j * thumbWidth, (k + 1) * paddingY + k * thumbHeight];
            }
            return positions;
        };
        Object.defineProperty(NavigationProxy.prototype, "list", {
            get: function () {
                return this._list;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(NavigationProxy.prototype, "status", {
            get: function () {
                return this._status;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(NavigationProxy.prototype, "slides", {
            get: function () {
                return this._slides;
            },
            enumerable: true,
            configurable: true
        });
        NavigationProxy.NAME = 'navigationProxy';
        NavigationProxy.SLIDER_NAV_MAX_VISIBLE = 8;
        NavigationProxy.SLIDER_VISIBLE_WIDTH = 1080;
        NavigationProxy.SLIDER_VISIBLE_HEIGHT = 550;
        NavigationProxy.GAME_THUMB_WIDTH = 266;
        NavigationProxy.GAME_THUMB_HEIGHT = 160;
        NavigationProxy.POSITIONS = NavigationProxy.getThumbPositions(3, 4, NavigationProxy.GAME_THUMB_WIDTH, NavigationProxy.GAME_THUMB_HEIGHT, NavigationProxy.SLIDER_VISIBLE_WIDTH, NavigationProxy.SLIDER_VISIBLE_HEIGHT);
        NavigationProxy.NAVIGATION_POS_Y = 40;
        return NavigationProxy;
    }(Proxy));
    gpts.NavigationProxy = NavigationProxy;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Capabilities = gamy.Capabilities;
    var EVENT_TYPE = gamy.EVENT_TYPE;
    var SliderPrevNext = (function (_super) {
        __extends(SliderPrevNext, _super);
        function SliderPrevNext(rightArrowFrames) {
            var _this = _super.call(this) || this;
            _this.prev = new gpts.Button(rightArrowFrames ? new gpts.SpriteSheet(rightArrowFrames) : null, { label: false, enableEff: true });
            _this.next = new gpts.Button(rightArrowFrames ? new gpts.SpriteSheet(rightArrowFrames) : null, { label: false, enableEff: true });
            _this.prev.setState('idle');
            _this.next.setState('idle');
            _this.prev.scale.set(-1, 1);
            _this.prev.x = _this.prev.width;
            _this.prev.interactive = true;
            _this.prev.buttonMode = true;
            _this.next.interactive = true;
            _this.next.buttonMode = true;
            _this.addChildren(_this.prev, _this.next);
            return _this;
        }
        SliderPrevNext.prototype.dispose = function () {
            _super.prototype.dispose.call(this);
            this.prev.removeAllListeners(Capabilities.eventType(EVENT_TYPE.CLICK));
            this.next.removeAllListeners(Capabilities.eventType(EVENT_TYPE.CLICK));
            this.prev = null;
            this.next = null;
        };
        return SliderPrevNext;
    }(gpts.Holder));
    gpts.SliderPrevNext = SliderPrevNext;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var trace = gamy.trace;
    var Sprite = PIXI.Sprite;
    var log = gamy.log;
    var Hash = gamy.Hash;
    var LoaderMax = gamy.LoaderMax;
    var LoaderStatus = gamy.LoaderStatus;
    var Capabilities = gamy.Capabilities;
    var MessagesEvent = gpts.services.MessagesEvent;
    var setCondition = gamy.setCondition;
    var checkCondition = gamy.checkCondition;
    var clearCondition = gamy.clearCondition;
    var EVENT_TYPE = gamy.EVENT_TYPE;
    var Rectangle = PIXI.Rectangle;
    var isMobile = gamy.isMobile;
    var NavigationMediator = (function (_super) {
        __extends(NavigationMediator, _super);
        function NavigationMediator(groupId) {
            var _this = _super.call(this, NavigationMediator.NAME + groupId) || this;
            _this.group_id = groupId;
            return _this;
        }
        NavigationMediator.prototype.listNotificationInterests = function () {
            return _super.prototype.listNotificationInterests.call(this).concat([
                gpts.Router.ICON_HAS_LOADED
            ]);
        };
        NavigationMediator.prototype.onRegister = function () {
            _super.prototype.onRegister.call(this);
            this.click_condition_id = setCondition(300);
            this.nav_proxy = new gpts.NavigationProxy(this.group_id);
            this.facade().registerProxy(this.nav_proxy);
            var that = this;
            this.viewComponent = new gpts.Navigation(this.nav_proxy.slides, function (slide) {
                return that.drawSlide(slide);
            }, {
                sliderNav: new Hash(this.nav_proxy.slides >= gpts.NavigationProxy.SLIDER_NAV_MAX_VISIBLE ? {
                    maxVisible: gpts.NavigationProxy.SLIDER_NAV_MAX_VISIBLE,
                    cyclic: true
                } : {
                    cyclic: false
                }).merge({
                    rightArrowFrames: [
                        new gpts.Frame(this.portal_proxy.getTexture(gpts.PortalProxy.RIGHT_ARROW + '_idle'), 'idle'),
                        new gpts.Frame(this.portal_proxy.getTexture(gpts.PortalProxy.RIGHT_ARROW + '_down'), 'down'),
                        new gpts.Frame(this.portal_proxy.getTexture(gpts.PortalProxy.RIGHT_ARROW + '_over'), 'over')
                    ],
                    count: this.nav_proxy.slides,
                    itemFrames: [
                        new gpts.Frame(this.portal_proxy.getTexture(gpts.PortalProxy.SLIDER_NAV_ITEM + '_idle'), 'idle'),
                        new gpts.Frame(this.portal_proxy.getTexture(gpts.PortalProxy.SLIDER_NAV_ITEM + '_selected'), 'selected')
                    ]
                }),
                slider: isMobile() ? {
                    finite: false,
                    time: 1,
                    width: gpts.NavigationProxy.SLIDER_VISIBLE_WIDTH,
                    height: gpts.NavigationProxy.SLIDER_VISIBLE_HEIGHT,
                    maxSpeed: 10
                } : {
                    finite: false,
                    time: 1.3,
                    width: gpts.NavigationProxy.SLIDER_VISIBLE_WIDTH,
                    height: gpts.NavigationProxy.SLIDER_VISIBLE_HEIGHT
                },
                markerTexture: this.portal_proxy.getTexture(gpts.PortalProxy.MARKER)
            });
            var sliderNavigation = this.viewComponent.sliderNavigation;
            if (sliderNavigation) {
                sliderNavigation.x = (this.viewComponent.slider.options.width - sliderNavigation.width) / 2;
                sliderNavigation.y = gpts.NavigationProxy.SLIDER_VISIBLE_HEIGHT + 80;
                var length_2 = sliderNavigation.children.length;
                for (var i = 0; i < length_2; i++)
                    sliderNavigation.children[i].on(Capabilities.eventType(EVENT_TYPE.CLICK), this.onClickSliderNavigationItem, this);
                var prevNext = this.viewComponent.prevNext;
                var padding = 20;
                prevNext.next.x = sliderNavigation.width + prevNext.prev.width + padding;
                prevNext.y = sliderNavigation.y + (sliderNavigation.height - prevNext.height) / 2;
                prevNext.x = sliderNavigation.x - prevNext.prev.width - padding / 2;
                prevNext.prev.on(Capabilities.eventType(EVENT_TYPE.CLICK), this.onClickPrevNext, this);
                prevNext.next.on(Capabilities.eventType(EVENT_TYPE.CLICK), this.onClickPrevNext, this);
            }
            this._stage.view.stage.addChild(this.viewComponent);
            this.viewComponent.x = (gpts.PortalProxy.STAGE_WIDTH - gpts.NavigationProxy.SLIDER_VISIBLE_WIDTH) / 2;
            this.viewComponent.y = gpts.NavigationProxy.NAVIGATION_POS_Y;
            this.app_facade.addEventListener(gpts.GameEvent.DESTROY, this.onDisposeGameProxy, this);
            this.app_facade.addEventListener(gpts.GameEvent.BONUS_SPINS_CHANGED, this.onBonusSpinsChanged, this);
            this.messages_facade.addEventListener(MessagesEvent.MESSAGE, this.onGameCompleteRecovery, this);
            this.launchPreRequestedGame();
        };
        NavigationMediator.prototype.launchPreRequestedGame = function () {
            if (this.app_facade.gameIdentificationNumber != -1) {
                var selected = String(this.app_facade.gameIdentificationNumber);
                this.app_facade.gameIdentificationNumber = -1;
                this._stage.view.stage.visible = false;
                if (this.nav_proxy.checkForIncorrectGameIdentificationNumber(selected)) {
                    return;
                }
                if (this.nav_proxy.status.has(selected)) {
                    var thumbnail = this.getGameThumbnailBy(selected);
                    if (thumbnail == null) {
                        this._selected = selected;
                        this.nav_proxy.status[selected].isActive = true;
                    }
                    else
                        this.setSelected(thumbnail);
                    this.app_facade.sendNotification(gpts.AppFacade.LAUNCH_GAME, this.app_facade.gamesList[selected]);
                }
                else {
                    this._stage.view.stage.visible = true;
                }
            }
        };
        NavigationMediator.prototype.drawSlide = function (slide) {
            var startIndex = slide.id * gpts.NavigationProxy.POSITIONS.length;
            var endIndex = startIndex + gpts.NavigationProxy.POSITIONS.length;
            trace(gpts.ELogger.PORTAL, 'drawSlide()', startIndex, endIndex);
            for (var i = startIndex; i < endIndex; i++) {
                if (this.nav_proxy.list[i] == undefined)
                    break;
                var data = this.nav_proxy.list[i];
                var item = this.createNavigationItem(data);
                var row = i % gpts.NavigationProxy.POSITIONS.length;
                item.x = gpts.NavigationProxy.POSITIONS[row][0];
                item.y = gpts.NavigationProxy.POSITIONS[row][1];
                slide.addChild(item);
                if (item.getState() == 'selected') {
                    slide.addChildAt(this.viewComponent.marker, 0);
                    this.viewComponent.marker.x = item.x - 30;
                    this.viewComponent.marker.y = item.y - 20;
                }
            }
            return slide;
        };
        NavigationMediator.prototype.createNavigationItem = function (data) {
            var item = new gpts.NavigationItem();
            item.hitArea = new Rectangle(0, 0, gpts.NavigationProxy.GAME_THUMB_WIDTH, gpts.NavigationProxy.GAME_THUMB_HEIGHT);
            item.interactive = true;
            item.buttonMode = true;
            item.activeGameIcon = new Sprite(this.portal_proxy.getTexture(gpts.PortalProxy.ACTIVE_GAME_ICON));
            item.recoveryIcon = new Sprite(this.portal_proxy.getTexture(gpts.PortalProxy.RECOVERY_ICON));
            item.jackpotIcon = new Sprite(this.portal_proxy.getTexture(gpts.PortalProxy.JACKPOT_ICON));
            item.featuredIcon = new Sprite(this.portal_proxy.getTexture(gpts.PortalProxy.FEATURED_ICON));
            item.bonusIcon = new Sprite(this.portal_proxy.getTexture(gpts.PortalProxy.BONUS_ICON));
            item.overIcon = new Sprite(this.portal_proxy.getTexture(gpts.PortalProxy.NAVIGATION_ITEM_OVER));
            item.overIcon.x = item.overIcon.y = -2;
            item.overIcon.visible = false;
            item.addChildren(item.activeGameIcon, item.recoveryIcon, item.jackpotIcon, item.featuredIcon, item.bonusIcon);
            item.jackpotIcon.visible = data.mlmJackpot;
            item.bonusIcon.visible = data.bonusSpins != null && data.bonusSpins.remainingBonusSpins > 0;
            item.featuredIcon.visible = data.featured && !item.bonusIcon.visible;
            var icon = this.nav_proxy.getIcon(data.gameType);
            if (icon) {
                item.src = new gpts.SpriteSheet(icon.frames);
                item.addChildAt(item.src, 0);
                log(true, 'NavigationMediator.createNavigationItem', icon);
            }
            item.addChildAt(item.overIcon, 0);
            item.name = String(data.gameIdentificationNumber);
            item.setState(item.name == this._selected ? 'selected' : 'idle');
            item.label.text = data.gameName;
            item.label.x = (gpts.NavigationProxy.GAME_THUMB_WIDTH - item.label.width) / 2;
            item.label.y = gpts.NavigationProxy.GAME_THUMB_HEIGHT - item.label.height;
            item.jackpotIcon.x = (gpts.NavigationProxy.GAME_THUMB_WIDTH - item.jackpotIcon.width) / 2;
            item.featuredIcon.x = gpts.NavigationProxy.GAME_THUMB_WIDTH - item.featuredIcon.width;
            item.bonusIcon.x = gpts.NavigationProxy.GAME_THUMB_WIDTH - item.bonusIcon.width - gpts.NavigationItem.BONUS_ICON_MARGIN_LEFT;
            item.bonusIcon.y = gpts.NavigationItem.BONUS_ICON_MARGIN_TOP;
            if (this.nav_proxy.status[data.gameIdentificationNumber].stopped) {
                item.interactive = false;
                item.buttonMode = false;
                item.alpha = 0.5;
                item.activeGameIcon.visible = item.recoveryIcon.visible = false;
            }
            else {
                item.recoveryIcon.visible = this.nav_proxy.status[data.gameIdentificationNumber].inRecovery;
                item.activeGameIcon.visible = this.nav_proxy.status[data.gameIdentificationNumber].isActive;
            }
            item.on(Capabilities.eventType(EVENT_TYPE.CLICK), this.onClickGameThumb, this);
            item.on('mouseover', this.onGameThumbOver, this);
            return item;
        };
        NavigationMediator.prototype.onGameThumbOver = function (event) {
            if (this.viewComponent.slider && (this.viewComponent.slider.isSliding || this.viewComponent.slider.isDragging))
                return;
            this.app_facade.sendNotification(gpts.AppFacade.PLAY_SOUND, gpts.AppFacade.ROLLOVER_GAME_ICON);
        };
        NavigationMediator.prototype.onClickGameThumb = function (event) {
            if (!this.messages_facade.connected || !(event.target instanceof gpts.NavigationItem) ||
                (this.nav_proxy.status.has(event.target.name) && this.nav_proxy.status[event.target.name].stopped) ||
                this.messages_facade.pendingCommand(gpts.EMessage.SETTINGS) ||
                LoaderMax.getLoader(gpts.Main.GAME_INTERFACE).status == LoaderStatus.LOADING ||
                (this.viewComponent.slider &&
                    (this.viewComponent.slider.isSliding || !this.centeredSlideContainsGameThumbWith(event.target.name) ||
                        !this.viewComponent.slider.acceptClick))) {
                return;
            }
            this.setSelected(event.target);
            this.app_facade.sendNotification(gpts.AppFacade.LAUNCH_GAME, this.app_facade.gamesList[event.target.name]);
            this.playShowSoundOnAlreadyLoadedGame(event.target.name);
        };
        NavigationMediator.prototype.playShowSoundOnAlreadyLoadedGame = function (gameIdentificationNumber) {
            var interests = this.app_facade.interests[this.app_facade.gamesList[gameIdentificationNumber].gameType];
            if (LoaderMax.getContent(interests) && !LoaderMax.getLoader(interests).vars.integrated)
                this.app_facade.sendNotification(gpts.AppFacade.PLAY_SOUND, gpts.AppFacade.SHOW_GAME);
        };
        NavigationMediator.prototype.onClickSliderNavigationItem = function (event) {
            if (!this.viewComponent.slider.isSliding) {
                var slide = parseInt(event.target.name);
                this.viewComponent.slider.setSlide(slide, true);
                this.app_facade.sendNotification(gpts.AppFacade.PLAY_SOUND, gpts.AppFacade.SLIDER_NAVIGATION_ITEM);
            }
        };
        NavigationMediator.prototype.onClickPrevNext = function (event) {
            if (checkCondition(this.click_condition_id))
                return;
            var slider = this.viewComponent.slider;
            slider.setSlide(event.target == this.viewComponent.prevNext.prev ? slider.slide - 1 : slider.slide + 1, false);
            this.app_facade.sendNotification(gpts.AppFacade.PLAY_SOUND, gpts.AppFacade.ARROW);
        };
        NavigationMediator.prototype.onDisposeGameProxy = function (event) {
            var changed = this.getGameThumbnailBy(event.gameIdentificationNumber);
            if (changed) {
                changed.activeGameIcon.visible = false;
                if (event.state == gpts.EMessage.FAILURE) {
                    changed.recoveryIcon.visible = false;
                    changed.alpha = 0.5;
                }
            }
            this.nav_proxy.status[event.gameIdentificationNumber].isActive = false;
            if (event.state == gpts.EMessage.FAILURE) {
                this.nav_proxy.status[event.gameIdentificationNumber].inRecovery = false;
                this.nav_proxy.status[event.gameIdentificationNumber].stopped = true;
            }
        };
        NavigationMediator.prototype.onBonusSpinsChanged = function (event) {
            var _this = this;
            if (this.app_facade.gamesWithBonusesList[event.gameIdentificationNumber].bonusSpins.statusCode == gpts.EMessage.BONUS_ERROR) {
                this.app_facade.gamesWithBonusesList.forEach(function (key, value) {
                    _this.updateBonusIcon(_this.getGameThumbnailBy(key), value);
                });
            }
            else {
                this.updateBonusIcon(this.getGameThumbnailBy(event.gameIdentificationNumber), this.app_facade.gamesWithBonusesList[event.gameIdentificationNumber]);
            }
        };
        NavigationMediator.prototype.updateBonusIcon = function (item, data) {
            if (item) {
                item.bonusIcon.visible = data.bonusSpins != null && data.bonusSpins.remainingBonusSpins > 0;
                item.featuredIcon.visible = data.featured && !item.bonusIcon.visible;
            }
        };
        NavigationMediator.prototype.onGameCompleteRecovery = function (event) {
            var message = event.data;
            if (message.command == gpts.EMessage.RECOVERY) {
                var gameIdentificationNumber = String(message.gameIdentificationNumber);
                var changed = this.getGameThumbnailBy(gameIdentificationNumber);
                if (changed)
                    changed.recoveryIcon.visible = false;
                this.nav_proxy.status[gameIdentificationNumber].inRecovery = false;
            }
        };
        NavigationMediator.prototype.handleNotification = function (notification) {
            _super.prototype.handleNotification.call(this, notification);
            switch (notification.getName()) {
                case gpts.Router.CHANGE_PAGE:
                    this.viewComponent.visible = this._router.page != gpts.Router.GAME_PAGE;
                    break;
                case gpts.Router.ICON_HAS_LOADED:
                    var gameIcon_1 = notification.getBody();
                    var gins = this.nav_proxy.availableGINForGameType(gameIcon_1.gameType);
                    var length_3 = gins.length;
                    var drawIcon = function (item) {
                        item.src = new gpts.SpriteSheet(gameIcon_1.frames);
                        item.addChildAt(item.src, 0);
                        item.addChildAt(item.overIcon, 0);
                    };
                    for (var i = 0; i < length_3; i++) {
                        if (this.nav_proxy.slides == 2) {
                            var items = this.getGameThumbnailsBy(gins[i]);
                            var numItems = items.length;
                            for (var j = 0; j < numItems; j++)
                                drawIcon(items[j]);
                        }
                        else {
                            var item = this.getGameThumbnailBy(gins[i]);
                            if (item)
                                drawIcon(item);
                        }
                    }
                    log(true, 'NavigationMediator handle notification with name iconHasLoaded', gameIcon_1);
                    break;
            }
        };
        NavigationMediator.prototype.setSelected = function (target) {
            target.activeGameIcon.visible = true;
            this.nav_proxy.status[target.name].isActive = true;
            var lastSelected = this.getGameThumbnailBy(this._selected);
            if (lastSelected)
                lastSelected.setState('idle');
            target.setState('selected');
            this._selected = target.name;
            var slide = target.parent;
            slide.addChildAt(this.viewComponent.marker, 0);
            this.viewComponent.marker.x = target.x - 30;
            this.viewComponent.marker.y = target.y - 20;
        };
        NavigationMediator.prototype.onRemove = function () {
            _super.prototype.onRemove.call(this);
            this.facade().removeProxy(gpts.NavigationProxy.NAME);
            this.nav_proxy = null;
            this.app_facade.removeEventListener(gpts.GameEvent.DESTROY, this.onDisposeGameProxy, this);
            this.app_facade.removeEventListener(gpts.GameEvent.BONUS_SPINS_CHANGED, this.onBonusSpinsChanged, this);
            this.messages_facade.removeEventListener(MessagesEvent.MESSAGE, this.onGameCompleteRecovery, this);
            this._stage.view.stage.removeChild(this.viewComponent);
            this.viewComponent = null;
            clearCondition(this.click_condition_id);
        };
        NavigationMediator.prototype.getGameThumbnailBy = function (gameIdentificationNumber) {
            var length = this.viewComponent.holder.children.length;
            var thumb;
            for (var i = 0; i < length; i++) {
                thumb = this.viewComponent.holder.children[i].getChildByName(gameIdentificationNumber);
                if (thumb instanceof gpts.NavigationItem)
                    return thumb;
            }
            return null;
        };
        NavigationMediator.prototype.getGameThumbnailsBy = function (gameIdentificationNumber) {
            var length = this.viewComponent.holder.children.length;
            var thumbs = [];
            for (var i = 0; i < length; i++) {
                var thumb = this.viewComponent.holder.children[i].getChildByName(gameIdentificationNumber);
                if (thumb instanceof gpts.NavigationItem)
                    thumbs.push(thumb);
            }
            return thumbs;
        };
        NavigationMediator.prototype.centeredSlideContainsGameThumbWith = function (gameIdentificationNumber) {
            if (this.viewComponent.slider == null)
                return false;
            var length = this.viewComponent.holder.children.length;
            for (var i = 0; i < length; i++) {
                var child = this.viewComponent.holder.children[i];
                if (child instanceof gpts.Slide && child.id ==
                    this.viewComponent.slider.getSlideId(this.viewComponent.slider.slide)) {
                    return child.getChildByName(gameIdentificationNumber) != null;
                }
            }
            return false;
        };
        NavigationMediator.NAME = 'NavigationMediator';
        return NavigationMediator;
    }(gpts.BaseMediator));
    gpts.NavigationMediator = NavigationMediator;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Proxy = puremvc.Proxy;
    var Capabilities = gamy.Capabilities;
    var EventDispatcher = gamy.EventDispatcher;
    var VisualProperty;
    (function (VisualProperty) {
        VisualProperty[VisualProperty["stageWidth"] = 0] = "stageWidth";
        VisualProperty[VisualProperty["stageHeight"] = 1] = "stageHeight";
        VisualProperty[VisualProperty["visibleWidth"] = 2] = "visibleWidth";
        VisualProperty[VisualProperty["visibleHeight"] = 3] = "visibleHeight";
    })(VisualProperty || (VisualProperty = {}));
    var PortalProxy = (function (_super) {
        __extends(PortalProxy, _super);
        function PortalProxy(onLoadResources) {
            if (onLoadResources === void 0) { onLoadResources = null; }
            var _this = _super.call(this, PortalProxy.NAME) || this;
            _this.onLoadResources = onLoadResources;
            return _this;
        }
        PortalProxy.getDimensionFor = function (property) {
            switch (property) {
                case VisualProperty.stageWidth:
                    if (MINI) {
                        return 286;
                    }
                    else if (MOB) {
                        return 960;
                    }
                    else {
                        return 1280;
                    }
                    break;
                case VisualProperty.stageHeight:
                    if (MINI) {
                        return 355;
                    }
                    else if (MOB) {
                        return 540;
                    }
                    else {
                        return 720;
                    }
                    break;
                case VisualProperty.visibleWidth:
                    if (MINI) {
                        return 286;
                    }
                    else if (MOB) {
                        return 960;
                    }
                    else {
                        return 1152;
                    }
                    break;
                case VisualProperty.visibleHeight:
                    if (MINI) {
                        return 355;
                    }
                    else if (MOB) {
                        return 540;
                    }
                    else {
                        return 720;
                    }
                    break;
            }
            return 0;
        };
        PortalProxy.prototype.libraryPath = function () {
            return (gpts.AppFacade.getInstance().singleGameMode ? 'assets/library-single-game-v' : 'assets/library-v') + Capabilities.scaleFactor + '.json?build=' + BUILD;
        };
        PortalProxy.prototype.onRegister = function () {
            _super.prototype.onRegister.call(this);
            var that = this;
            var gptsInit = window['gptsInit'];
            var gptsOptions = window['gptsOptions'];
            var resourcesHasLoaded = false;
            var loader = new PIXI.loaders.Loader();
            var url = this.libraryPath();
            loader.add(url);
            loader.load(function () {
                that._atlas = loader.resources[url].textures;
                resourcesHasLoaded = true;
                if (that.onLoadResources != null && moduelsHasLoaded && resourcesHasLoaded)
                    that.onLoadResources.call(that);
            });
            var moduelsHasLoaded = false;
            gptsInit.loadQueues(gptsOptions.moduleQueues, function () {
                moduelsHasLoaded = true;
                if (that.onLoadResources != null && moduelsHasLoaded && resourcesHasLoaded)
                    that.onLoadResources.call(that);
            });
        };
        PortalProxy.prototype.preloadSound = function (url) {
            var options = { src: [url + '?build=' + BUILD] };
            return new Howl(options);
        };
        PortalProxy.prototype.getTexture = function (name, ext) {
            if (ext === void 0) { ext = 'png'; }
            if (this._atlas == null)
                return null;
            return this._atlas['@' + Capabilities.scaleFactor + 'x/' + name + (ext ? ('.' + ext) : '')];
        };
        PortalProxy.NAME = 'portalProxy';
        PortalProxy.PNG_EXT = 'png';
        PortalProxy.JPG_EXT = 'jpg';
        PortalProxy.STAGE_WIDTH = PortalProxy.getDimensionFor(VisualProperty.stageWidth);
        PortalProxy.STAGE_HEIGHT = PortalProxy.getDimensionFor(VisualProperty.stageHeight);
        PortalProxy.VISIBLE_WIDTH = PortalProxy.getDimensionFor(VisualProperty.visibleWidth);
        PortalProxy.VISIBLE_HEIGHT = PortalProxy.getDimensionFor(VisualProperty.visibleHeight);
        PortalProxy.SPECIAL_CURRENCY = 'EGT';
        PortalProxy.ICON = 'icon';
        PortalProxy.BUTTON = 'button';
        PortalProxy.ACTIVE_GAME_ICON = 'ActiveGameIcon';
        PortalProxy.RECOVERY_ICON = 'RecoveryIcon';
        PortalProxy.JACKPOT_ICON = 'JackpotIcon';
        PortalProxy.MARKER = 'Marker';
        PortalProxy.FEATURED_ICON = 'FeaturedIcon';
        PortalProxy.BONUS_ICON = 'bonusSpinLabel';
        PortalProxy.DIAMOND_ICON = 'Diamond';
        PortalProxy.HELP_ICON_IDLE = 'HelpIcon_idle';
        PortalProxy.HELP_ICON_DOWN = 'HelpIcon_down';
        PortalProxy.HELP_ICON_OVER = 'HelpIcon_over';
        PortalProxy.FULLSCR_ICON_ON = 'FullscrIcon_on';
        PortalProxy.FULLSCR_ICON_ON_DOWN = 'FullscrIcon_on_down';
        PortalProxy.FULLSCR_ICON_ON_OVER = 'FullscrIcon_on_over';
        PortalProxy.FULLSCR_ICON_OFF_DOWN = 'FullscrIcon_off_down';
        PortalProxy.FULLSCR_ICON_OFF_OVER = 'FullscrIcon_off_over';
        PortalProxy.FULLSCR_ICON_OFF = 'FullscrIcon_off';
        PortalProxy.MUTE_ICON_ON = 'MuteIcon_on';
        PortalProxy.MUTE_ICON_ON_DOWN = 'MuteIcon_on_down';
        PortalProxy.MUTE_ICON_ON_OVER = 'MuteIcon_on_over';
        PortalProxy.MUTE_ICON_OFF_DOWN = 'MuteIcon_off_down';
        PortalProxy.MUTE_ICON_OFF_OVER = 'MuteIcon_off_over';
        PortalProxy.MUTE_ICON_OFF = 'MuteIcon_off';
        PortalProxy.EXIT_BUTTON_IDLE = 'ExitButton_idle';
        PortalProxy.EXIT_BUTTON_DOWN = 'ExitButton_down';
        PortalProxy.EXIT_BUTTON_OVER = 'ExitButton_over';
        PortalProxy.LANG_BAR_BACKGROUND = 'LanguageBarBackground';
        PortalProxy.LANG_BAR_BACKGROUND_SMALL = 'LanguageBarBackgroundSmall';
        PortalProxy.STAR_ICON = 'StarIcon';
        PortalProxy.COMPANY_LOGO = 'EGTLogo';
        PortalProxy.FOOTER_BACKGROUND = 'FooterBackground';
        PortalProxy.HEADER_BACKGROUND = 'HeaderBackground';
        PortalProxy.RIGHT_ARROW = 'RightArrow';
        PortalProxy.NAVIGATION_ITEM_OVER = 'NavigationItem_over';
        PortalProxy.GAMES_FILTER_CENTER = 'GamesFilterCenter';
        PortalProxy.GAMES_FILTER_LEFT = 'GamesFilterLeft';
        PortalProxy.BALANCE_LABEL = 'balance_';
        PortalProxy.SELECT_GAME_LABEL = 'selectGame_';
        PortalProxy.NO_CONNECTION_LABEL = 'noConnection_';
        PortalProxy.SLIDER_NAV_ITEM = 'SliderNavItem';
        return PortalProxy;
    }(Proxy));
    gpts.PortalProxy = PortalProxy;
    gpts.muted = false;
    var Fullscreen = (function (_super) {
        __extends(Fullscreen, _super);
        function Fullscreen() {
            var _this = _super.call(this) || this;
            _this.change = function (fullscreen) {
            };
            var d = document;
            if (d.documentElement.requestFullScreen) {
                _this._requestFullscreen = d.documentElement.requestFullscreen;
            }
            else if (d.documentElement.mozRequestFullScreen) {
                _this._requestFullscreen = d.documentElement.mozRequestFullScreen;
            }
            else if (d.documentElement.webkitRequestFullScreen) {
                _this._requestFullscreen = d.documentElement.webkitRequestFullScreen;
            }
            if (d.cancelFullScreen) {
                _this._cancelFullscreen = d.cancelFullScreen;
            }
            else if (d.mozCancelFullScreen) {
                _this._cancelFullscreen = d.mozCancelFullScreen;
            }
            else if (d.webkitCancelFullScreen) {
                _this._cancelFullscreen = d.webkitCancelFullScreen;
            }
            var that = _this;
            d.addEventListener("fullscreenchange", function () {
                that.change(d.fullscreen);
                that.dispatchEvent({ type: Fullscreen.CHANGE, fullscreen: d.fullscreen });
            }, false);
            d.addEventListener("mozfullscreenchange", function () {
                that.change(d.mozFullScreen);
                that.dispatchEvent({ type: Fullscreen.CHANGE, fullscreen: d.mozFullScreen });
            }, false);
            d.addEventListener("webkitfullscreenchange", function () {
                that.change(d.webkitIsFullScreen);
                that.dispatchEvent({ type: Fullscreen.CHANGE, fullscreen: d.webkitIsFullScreen });
            }, false);
            d.addEventListener("msfullscreenchange", function () {
                that.change(d.msFullscreenElement);
                that.dispatchEvent({ type: Fullscreen.CHANGE, fullscreen: d.msFullscreenElement });
            }, false);
            console.log('fullscreen supported: ' + (_this.supported ? 'yes' : 'no'));
            return _this;
        }
        Fullscreen.prototype.request = function () {
            var d = document;
            if (d.documentElement.webkitRequestFullScreen)
                this._requestFullscreen.call(d.documentElement, Element.ALLOW_KEYBOARD_INPUT);
            else
                this._requestFullscreen.call(d.documentElement);
        };
        Fullscreen.prototype.cancel = function () {
            this._cancelFullscreen.call(document);
        };
        Object.defineProperty(Fullscreen.prototype, "supported", {
            get: function () {
                var d = document;
                return (d.fullScreenElement && d.fullScreenElement !== null) || (!d.mozFullScreen && !d.webkitIsFullScreen);
            },
            enumerable: true,
            configurable: true
        });
        Fullscreen.CHANGE = 'change';
        return Fullscreen;
    }(EventDispatcher));
    gpts.Fullscreen = Fullscreen;
    gpts.fullscreen = new Fullscreen();
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var StaticControlsItem = (function (_super) {
        __extends(StaticControlsItem, _super);
        function StaticControlsItem(src, options) {
            if (src === void 0) { src = null; }
            if (options === void 0) { options = null; }
            return _super.call(this, src, options) || this;
        }
        StaticControlsItem.prototype.onDown = function (event) {
            try {
                this.src.gotoAndStopToLabel(this._state + '_down');
            }
            catch (error) {
            }
        };
        StaticControlsItem.prototype.onOver = function (event) {
            try {
                this.src.gotoAndStopToLabel(this._state + '_over');
            }
            catch (error) {
            }
        };
        return StaticControlsItem;
    }(gpts.Button));
    gpts.StaticControlsItem = StaticControlsItem;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Rectangle = PIXI.Rectangle;
    var Sprite = PIXI.Sprite;
    var trace = gamy.trace;
    var LoaderMax = gamy.LoaderMax;
    var Text = PIXI.Text;
    var MessagesEvent = gpts.services.MessagesEvent;
    var Hash = gamy.Hash;
    var Point = PIXI.Point;
    var StringTools = gamy.StringTools;
    var TextStyle = PIXI.TextStyle;
    var Capabilities = gamy.Capabilities;
    var EVENT_TYPE = gamy.EVENT_TYPE;
    var StaticControlsMediator = (function (_super) {
        __extends(StaticControlsMediator, _super);
        function StaticControlsMediator() {
            return _super.call(this, StaticControlsMediator.NAME) || this;
        }
        StaticControlsMediator.prototype.onRegister = function () {
            _super.prototype.onRegister.call(this);
            this.viewComponent = new gpts.StaticControls();
            this.createCurrencyTextField();
            this.createUserNameTextField();
            this.createExitHelpMuteAndFullscreenButtons();
            this.createBalanceAndSelectGameTextFields();
            this.createLanguageBar();
            this.createClock();
            this.viewComponent.addChildren(this.viewComponent.currencyField, this.viewComponent.usernameField, this.viewComponent.help, this.viewComponent.fullscreen, this.viewComponent.mute, this.viewComponent.exit, this.viewComponent.balance, this.viewComponent.selectGame, this.viewComponent.noConnection, this.viewComponent.languageBar, this.viewComponent.clock);
            this._stage.view.stage.addChild(this.viewComponent);
            var that = this;
            gpts.fullscreen.change = function (fullscreen) {
                that.changeFullscreen(fullscreen);
            };
            this.viewComponent.help.on(Capabilities.eventType(EVENT_TYPE.CLICK), this.onClick, this);
            this.viewComponent.mute.on(Capabilities.eventType(EVENT_TYPE.CLICK), this.onClick, this);
            this.viewComponent.fullscreen.on(Capabilities.eventType(EVENT_TYPE.CLICK), this.onClick, this);
            this.viewComponent.exit.on(Capabilities.eventType(EVENT_TYPE.CLICK), this.onClick, this);
            this.app_facade.addEventListener(gpts.AppFacade.UPDATE_BALANCE, this.onUpdateBalance, this);
            this.messages_facade.addEventListener('error', this.onLooseConnection, this);
            this.messages_facade.addEventListener('close', this.onLooseConnection, this);
            this.messages_facade.addEventListener(MessagesEvent.LOOSE_CONNECTION, this.onLooseConnection, this);
            var length = this.viewComponent.languageBar.holder.children.length;
            for (var i = 0; i < length; i++)
                this.viewComponent.languageBar.holder.children[i].on(Capabilities.eventType(EVENT_TYPE.CLICK), this.onClickLanguageBar, this);
            if (length > 1)
                this.viewComponent.languageBar.current.on(Capabilities.eventType(EVENT_TYPE.CLICK), this.toggleLanguageBar, this);
            this.onUpdateBalance();
            this.translateContent();
            if (!this.messages_facade.connected)
                this.onLooseConnection();
        };
        StaticControlsMediator.prototype.createCurrencyTextField = function () {
            this.viewComponent.currencyField = new gpts.CurrencyTextField(gpts.PortalProxy.SPECIAL_CURRENCY);
            this.viewComponent.currencyField.rect = StaticControlsMediator.CURRENCY_FIELD;
            this.viewComponent.currencyField.moneyField = new gpts.TextField('', new TextStyle({ fontSize: 20, fill: '#a5a5a5' }));
            this.viewComponent.currencyField.currencyField = new gpts.TextField('', new TextStyle({ fontSize: 12, fill: '#a5a5a5' }));
            this.viewComponent.currencyField.specialCurrencyIcon = new Sprite(this.portal_proxy.getTexture(gpts.PortalProxy.DIAMOND_ICON));
            this.viewComponent.currencyField.setCurrency(this.app_facade.currency);
        };
        StaticControlsMediator.prototype.createUserNameTextField = function () {
            this.viewComponent.usernameField = new gpts.TextField(this.app_facade.playerName, new TextStyle({
                fontSize: 20,
                fill: '#a5a5a5'
            }));
            this.viewComponent.usernameField.constrain(StaticControlsMediator.USERNAME_FIELD.width, StaticControlsMediator.USERNAME_FIELD.height);
            this.viewComponent.usernameField.x = StaticControlsMediator.USERNAME_FIELD.x + (StaticControlsMediator.USERNAME_FIELD.width - this.viewComponent.usernameField.width) / 2;
            this.viewComponent.usernameField.y = StaticControlsMediator.USERNAME_FIELD.y + (StaticControlsMediator.USERNAME_FIELD.height - this.viewComponent.usernameField.height) / 2;
        };
        StaticControlsMediator.prototype.createExitHelpMuteAndFullscreenButtons = function () {
            this.viewComponent.exit = new gpts.Button(new gpts.SpriteSheet([
                new gpts.Frame(this.portal_proxy.getTexture(gpts.PortalProxy.EXIT_BUTTON_IDLE), 'idle'),
                new gpts.Frame(this.portal_proxy.getTexture(gpts.PortalProxy.EXIT_BUTTON_DOWN), 'down'),
                new gpts.Frame(this.portal_proxy.getTexture(gpts.PortalProxy.EXIT_BUTTON_OVER), 'over')
            ]), { label: false, enableEff: true });
            this.viewComponent.exit.setState('idle');
            var exitLabel = new gpts.TextField('', new TextStyle({
                fill: 0x001446,
                fontSize: 15,
                fontFamily: 'Arial',
                fontWeight: 'bold'
            }));
            this.viewComponent.exit.label = exitLabel;
            this.viewComponent.exit.addChild(exitLabel);
            this.viewComponent.exit.name = StaticControlsMediator.EXIT;
            this.viewComponent.exit.y = StaticControlsMediator.EXIT_BUTTON_Y;
            this.viewComponent.exit.x = StaticControlsMediator.USERNAME_FIELD.x + StaticControlsMediator.USERNAME_FIELD.width - this.viewComponent.exit.width;
            this.viewComponent.help = new gpts.Button(new gpts.SpriteSheet([
                new gpts.Frame(this.portal_proxy.getTexture(gpts.PortalProxy.HELP_ICON_IDLE), 'idle'),
                new gpts.Frame(this.portal_proxy.getTexture(gpts.PortalProxy.HELP_ICON_DOWN), 'down'),
                new gpts.Frame(this.portal_proxy.getTexture(gpts.PortalProxy.HELP_ICON_OVER), 'over')
            ]), { label: false, enableEff: true });
            this.viewComponent.help.setState('idle');
            this.viewComponent.help.name = StaticControlsMediator.HELP;
            this.viewComponent.help.x = StaticControlsMediator.USERNAME_FIELD.x;
            this.viewComponent.help.y = this.viewComponent.exit.y + (this.viewComponent.exit.height - this.viewComponent.help.height) / 2;
            this.viewComponent.fullscreen = new gpts.StaticControlsItem(new gpts.SpriteSheet([
                new gpts.Frame(this.portal_proxy.getTexture(gpts.PortalProxy.FULLSCR_ICON_ON), 'on'),
                new gpts.Frame(this.portal_proxy.getTexture(gpts.PortalProxy.FULLSCR_ICON_OFF), 'off'),
                new gpts.Frame(this.portal_proxy.getTexture(gpts.PortalProxy.FULLSCR_ICON_ON_DOWN), 'on_down'),
                new gpts.Frame(this.portal_proxy.getTexture(gpts.PortalProxy.FULLSCR_ICON_ON_OVER), 'on_over'),
                new gpts.Frame(this.portal_proxy.getTexture(gpts.PortalProxy.FULLSCR_ICON_OFF_DOWN), 'off_down'),
                new gpts.Frame(this.portal_proxy.getTexture(gpts.PortalProxy.FULLSCR_ICON_OFF_OVER), 'off_over')
            ]), {
                label: false,
                enableEff: true
            });
            this.viewComponent.fullscreen.setState('on');
            this.viewComponent.fullscreen.name = StaticControlsMediator.FULLSCREEN;
            this.viewComponent.fullscreen.x = this.viewComponent.help.x + this.viewComponent.help.width + StaticControlsMediator.HELP_FULLSCREEN_MUTE_PADDING;
            this.viewComponent.fullscreen.y = this.viewComponent.help.y;
            this.viewComponent.mute = new gpts.StaticControlsItem(new gpts.SpriteSheet([
                new gpts.Frame(this.portal_proxy.getTexture(gpts.PortalProxy.MUTE_ICON_ON), 'on'),
                new gpts.Frame(this.portal_proxy.getTexture(gpts.PortalProxy.MUTE_ICON_OFF), 'off'),
                new gpts.Frame(this.portal_proxy.getTexture(gpts.PortalProxy.MUTE_ICON_ON_DOWN), 'on_down'),
                new gpts.Frame(this.portal_proxy.getTexture(gpts.PortalProxy.MUTE_ICON_ON_OVER), 'on_over'),
                new gpts.Frame(this.portal_proxy.getTexture(gpts.PortalProxy.MUTE_ICON_OFF_DOWN), 'off_down'),
                new gpts.Frame(this.portal_proxy.getTexture(gpts.PortalProxy.MUTE_ICON_OFF_OVER), 'off_over')
            ]), { label: false, enableEff: true });
            this.viewComponent.mute.setState('on');
            this.viewComponent.mute.name = StaticControlsMediator.MUTE;
            this.viewComponent.mute.x = this.viewComponent.fullscreen.x + this.viewComponent.fullscreen.width + StaticControlsMediator.HELP_FULLSCREEN_MUTE_PADDING;
            this.viewComponent.mute.y = this.viewComponent.help.y;
            this.viewComponent.help.interactive = this.viewComponent.mute.interactive = this.viewComponent.exit.interactive = this.viewComponent.fullscreen.interactive = true;
            this.viewComponent.help.buttonMode = this.viewComponent.mute.buttonMode = this.viewComponent.exit.buttonMode = this.viewComponent.fullscreen.buttonMode = true;
        };
        StaticControlsMediator.prototype.createLanguageBar = function () {
            var that = this;
            this.viewComponent.languageBar = new gpts.LanguageBar(this.app_facade.languages, function (lang) {
                return new gpts.Button(new gpts.SpriteSheet([
                    new gpts.Frame(that.portal_proxy.getTexture(lang + 'Flag_idle'), 'idle'),
                    new gpts.Frame(that.portal_proxy.getTexture(lang + 'Flag_over'), 'over')
                ]), {
                    label: false,
                    enableEff: true
                });
            }, function (languages) {
                var length = languages.length;
                var frames = [];
                for (var i = 0; i < length; i++)
                    frames[i] = new gpts.Frame(that.portal_proxy.getTexture('small' + languages[i] + 'Flag'), languages[i]);
                var current = length > 0 ? new gpts.SpriteSheet(frames) : null;
                if (current) {
                    current.interactive = true;
                    current.buttonMode = true;
                }
                return current;
            }, { distance: 20 });
            var length = this.app_facade.languages.length;
            var background;
            function positionLangBarContainer() {
                background.x = -4;
                background.y = -5;
                that.viewComponent.languageBar.container.x = -20;
            }
            if (length > 2) {
                background = new Sprite(this.portal_proxy.getTexture(gpts.PortalProxy.LANG_BAR_BACKGROUND));
                this.viewComponent.languageBar.container.addChildAt(background, 0);
                positionLangBarContainer();
            }
            else if (length > 1) {
                background = new Sprite(this.portal_proxy.getTexture(gpts.PortalProxy.LANG_BAR_BACKGROUND_SMALL));
                this.viewComponent.languageBar.container.addChildAt(background, 0);
                positionLangBarContainer();
            }
            this.viewComponent.languageBar.container.visible = false;
            this.viewComponent.languageBar.x = StaticControlsMediator.LANG_BAR_POS.x;
            this.viewComponent.languageBar.y = StaticControlsMediator.LANG_BAR_POS.y;
        };
        StaticControlsMediator.prototype.createBalanceAndSelectGameTextFields = function () {
            var that = this;
            function createLabelFrames(labelName) {
                var languages = that.app_facade.languages;
                var length = languages.length;
                var frames = [];
                for (var i = 0; i < length; i++) {
                    frames[i] = new gpts.Frame(that.portal_proxy.getTexture(labelName + languages[i]), languages[i]);
                }
                return frames;
            }
            this.viewComponent.balance = new gpts.SpriteSheet(createLabelFrames(gpts.PortalProxy.BALANCE_LABEL));
            this.viewComponent.selectGame = new gpts.SpriteSheet(createLabelFrames(gpts.PortalProxy.SELECT_GAME_LABEL));
            this.viewComponent.noConnection = new gpts.SpriteSheet(createLabelFrames(gpts.PortalProxy.NO_CONNECTION_LABEL));
            this.viewComponent.noConnection.visible = false;
        };
        StaticControlsMediator.prototype.createClock = function () {
            var that = this;
            this.viewComponent.clock = new Text(this.getTime(), {
                fontSize: 25,
                fill: '#5A85D3'
            });
            this.viewComponent.clock.x = StaticControlsMediator.CLOCK_POS.x;
            this.viewComponent.clock.y = StaticControlsMediator.CLOCK_POS.y;
            setInterval(function () {
                that.viewComponent.clock.text = that.getTime();
            }, 500);
        };
        StaticControlsMediator.prototype.getTime = function () {
            var date = new Date();
            var hour = date.getHours();
            var minutes = date.getMinutes();
            return StringTools.prefix(0, hour, 2 - hour.toString().length) + ':' + StringTools.prefix(0, minutes, 2 - minutes.toString().length);
        };
        StaticControlsMediator.prototype.onLooseConnection = function (event) {
            this.messages_facade.removeEventListener(MessagesEvent.LOOSE_CONNECTION, this.onLooseConnection, this);
            this.messages_facade.removeEventListener('error', this.onLooseConnection, this);
            this.messages_facade.removeEventListener('close', this.onLooseConnection, this);
            var content = LoaderMax.getContent(gpts.Main.CONTENT);
            this.viewComponent.selectGame.visible = false;
            this.viewComponent.noConnection.visible = true;
            this.viewComponent.noConnection.gotoAndStopToLabel(this._router.language);
            this.viewComponent.noConnection.x = (gpts.PortalProxy.STAGE_WIDTH - this.viewComponent.noConnection.width) / 2;
            this.viewComponent.noConnection.y = StaticControlsMediator.SELECT_GAME_LABEL_Y;
        };
        StaticControlsMediator.prototype.onUpdateBalance = function (event) {
            this.viewComponent.currencyField.money(this.app_facade.formatCurrency(this.app_facade.balance));
        };
        StaticControlsMediator.prototype.changeFullscreen = function (fullscreen) {
            trace(gpts.ELogger.PORTAL, 'fullscreen: ' + fullscreen);
            this.viewComponent.fullscreen.setState(fullscreen ? 'off' : 'on');
            this.app_facade.sendNotification(gpts.AppFacade.PLAY_SOUND, (fullscreen ? gpts.AppFacade.FULLSCREEN_IN : gpts.AppFacade.FULLSCREEN_OUT));
        };
        StaticControlsMediator.prototype.onClickLanguageBar = function (event) {
            trace(gpts.ELogger.PORTAL, 'click flag', event.target.name);
            this.toggleLanguageBar();
            this._router.redirectTo(this._router.page, new Hash(this._router.parameters).merge({ language: event.target.name }));
        };
        StaticControlsMediator.prototype.toggleLanguageBar = function (event) {
            this.lang_bar_is_active = !this.lang_bar_is_active;
            this.viewComponent.languageBar.container.visible = this.lang_bar_is_active;
            if (this.app_facade.languages.length > 2) {
                if (this.lang_bar_is_active) {
                    this.viewComponent.languageBar.prepareHolderBeforeScrollStart();
                    this.viewComponent.languageBar.scroll.start();
                }
                else
                    this.viewComponent.languageBar.scroll.stop();
            }
            this.app_facade.sendNotification(gpts.AppFacade.PLAY_SOUND, (this.lang_bar_is_active ? gpts.AppFacade.LANGUAGE_BAR_IN : gpts.AppFacade.LANGUAGE_BAR_OUT));
        };
        StaticControlsMediator.prototype.onClick = function (event) {
            switch (event.target.name) {
                case StaticControlsMediator.EXIT:
                    this.app_facade.sendNotification(gpts.AppFacade.EXIT_PLATFORM);
                    break;
                case StaticControlsMediator.MUTE:
                    gpts.muted = !gpts.muted;
                    this.setMuteStatus();
                    break;
                case StaticControlsMediator.FULLSCREEN:
                    this.toggleFullScreen();
                    break;
                case StaticControlsMediator.HELP:
                    this.displayHelp();
                    break;
            }
        };
        StaticControlsMediator.prototype.toggleFullScreen = function () {
            if (gpts.fullscreen.supported)
                gpts.fullscreen.request();
            else
                gpts.fullscreen.cancel();
        };
        StaticControlsMediator.prototype.displayHelp = function () {
            var content = LoaderMax.getContent(gpts.Main.CONTENT);
            window.open(content.help[this._router.language], 'popUp', 'width=400,height=400,toolbar=no,scrollbars=yes,resizable=yes');
        };
        StaticControlsMediator.prototype.setMuteStatus = function () {
            $('audio,video').each(function () {
                $(this).data('muted', !gpts.muted);
            });
            this.viewComponent.mute.setState(gpts.muted ? 'off' : 'on');
        };
        StaticControlsMediator.prototype.handleNotification = function (notification) {
            _super.prototype.handleNotification.call(this, notification);
            switch (notification.getName()) {
                case gpts.Router.CHANGE_PAGE:
                    this.viewComponent.visible = this._router.page != gpts.Router.GAME_PAGE;
                    if (this._router.page == gpts.Router.HOME_PAGE) {
                        this.setMuteStatus();
                        this.sendFront();
                    }
                    break;
                case gpts.Router.CHANGE_LANG:
                    this.translateContent();
                    break;
            }
        };
        StaticControlsMediator.prototype.translateContent = function () {
            var content = LoaderMax.getContent(gpts.Main.CONTENT);
            this.viewComponent.balance.gotoAndStopToLabel(this._router.language);
            this.viewComponent.balance.x = StaticControlsMediator.CURRENCY_FIELD.x + (StaticControlsMediator.CURRENCY_FIELD.width - this.viewComponent.balance.width) / 2;
            this.viewComponent.balance.y = StaticControlsMediator.CURRENCY_FIELD.y - this.viewComponent.balance.height;
            if (this.messages_facade.connected) {
                this.viewComponent.selectGame.gotoAndStopToLabel(this._router.language);
                this.viewComponent.selectGame.x = (gpts.PortalProxy.STAGE_WIDTH - this.viewComponent.selectGame.width) / 2;
                this.viewComponent.selectGame.y = StaticControlsMediator.SELECT_GAME_LABEL_Y;
            }
            else {
                this.viewComponent.noConnection.gotoAndStopToLabel(this._router.language);
                this.viewComponent.noConnection.x = (gpts.PortalProxy.STAGE_WIDTH - this.viewComponent.noConnection.width) / 2;
                this.viewComponent.noConnection.y = StaticControlsMediator.SELECT_GAME_LABEL_Y;
            }
            this.viewComponent.exit.label.text = content.popup.exitLabel[this._router.language];
            var exitLabelMaxWidth = 52;
            var exitLabelMaxHeight = 33;
            if (this.viewComponent.exit.label.width > exitLabelMaxWidth || this.viewComponent.exit.label.height > exitLabelMaxHeight)
                this.viewComponent.exit.label.constrain(exitLabelMaxWidth, exitLabelMaxHeight);
            this.viewComponent.exit.label.x = (exitLabelMaxWidth - this.viewComponent.exit.label.width) / 2;
            this.viewComponent.exit.label.y = (exitLabelMaxHeight - this.viewComponent.exit.label.height) / 2;
            if (this.viewComponent.languageBar.holder.children.length > 1)
                this.viewComponent.languageBar.current.gotoAndStopToLabel(this._router.language);
        };
        StaticControlsMediator.prototype.listNotificationInterests = function () {
            return _super.prototype.listNotificationInterests.call(this).concat(gpts.Router.CHANGE_LANG);
        };
        StaticControlsMediator.NAME = 'StaticControlsMediator';
        StaticControlsMediator.CURRENCY_FIELD = new Rectangle(144, 649, 181, 46);
        StaticControlsMediator.USERNAME_FIELD = new Rectangle(957, 662, 180, 38);
        StaticControlsMediator.HELP_FULLSCREEN_MUTE_PADDING = 2;
        StaticControlsMediator.EXIT_BUTTON_Y = 620;
        StaticControlsMediator.SELECT_GAME_LABEL_Y = 605;
        StaticControlsMediator.CLOCK_POS = new Point(853, 670);
        StaticControlsMediator.LANG_BAR_POS = new Point(370, 670);
        StaticControlsMediator.EXIT = 'exit';
        StaticControlsMediator.FULLSCREEN = 'fullscreen';
        StaticControlsMediator.HELP = 'help';
        StaticControlsMediator.MUTE = 'mute';
        return StaticControlsMediator;
    }(gpts.BaseMediator));
    gpts.StaticControlsMediator = StaticControlsMediator;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Text = PIXI.Text;
    var Loading = (function (_super) {
        __extends(Loading, _super);
        function Loading() {
            var _this = _super.call(this) || this;
            _this.label = new Text('loading', {
                fontFamily: 'Arial',
                fontSize: 13,
                fill: '#ffffff'
            });
            _this.addChildren(_this.label);
            return _this;
        }
        Loading.prototype.dispose = function () {
            _super.prototype.dispose.call(this);
            this.companyLogo = null;
            this.label = null;
        };
        return Loading;
    }(gpts.Holder));
    gpts.Loading = Loading;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Sprite = PIXI.Sprite;
    var Mediator = puremvc.Mediator;
    var Texture = PIXI.Texture;
    var Rectangle = PIXI.Rectangle;
    var LoadingMediator = (function (_super) {
        __extends(LoadingMediator, _super);
        function LoadingMediator() {
            return _super.call(this, LoadingMediator.NAME) || this;
        }
        LoadingMediator.prototype.onRegister = function () {
            _super.prototype.onRegister.call(this);
            this._stage = gpts.Router.getInstance().retrieveMediator(gpts.StageMediator.NAME);
            this.viewComponent = new gpts.Loading();
            var egtLogoTexture = Texture.fromImage('assets/EGTLogo.png?build=' + BUILD);
            egtLogoTexture.once('update', function () {
                egtLogoTexture.frame = new Rectangle(0, 0, 209, 100);
            });
            this.viewComponent.companyLogo = new Sprite(egtLogoTexture);
            if (MINI) {
                var scaleFactor = 0.8;
                LoadingMediator.logoWidth *= scaleFactor;
                LoadingMediator.logoHeight *= scaleFactor;
                this.viewComponent.companyLogo.scale.set(scaleFactor, scaleFactor);
            }
            this.viewComponent.addChildren(this.viewComponent.companyLogo);
            this._stage.view.stage.addChild(this.viewComponent);
            this.onOrientationChange();
            var that = this;
            var step = 0;
            this._id = setInterval(function () {
                that.viewComponent.label.text = 'loading ' + that.getDots(step);
                step = (step + 1) % 4;
            }, 100);
            if (MOB) {
                this._orientationChangeHandler = function () {
                    that.onOrientationChange();
                };
                window.addEventListener('orientationchange', this._orientationChangeHandler);
            }
        };
        LoadingMediator.prototype.onOrientationChange = function () {
            this.viewComponent.companyLogo.x = (this._stage.view.stageWidth - LoadingMediator.logoWidth) / 2;
            this.viewComponent.companyLogo.y = (this._stage.view.stageHeight - LoadingMediator.logoHeight) / 2;
            this.viewComponent.label.x = this.viewComponent.companyLogo.x + (LoadingMediator.logoWidth - this.viewComponent.label.width) / 2;
            this.viewComponent.label.y = this.viewComponent.companyLogo.y + LoadingMediator.logoHeight + 10;
        };
        LoadingMediator.prototype.getDots = function (step) {
            var dots = '';
            for (var i = 0; i < step; i++)
                dots += '.';
            return dots;
        };
        LoadingMediator.prototype.onRemove = function () {
            _super.prototype.onRemove.call(this);
            this._stage.view.stage.removeChild(this.viewComponent);
            this.viewComponent = null;
            clearInterval(this._id);
            window.removeEventListener('orientationchange', this._orientationChangeHandler);
        };
        LoadingMediator.NAME = 'LoadingMediator';
        LoadingMediator.logoWidth = 209;
        LoadingMediator.logoHeight = 100;
        return LoadingMediator;
    }(Mediator));
    gpts.LoadingMediator = LoadingMediator;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Sprite = PIXI.Sprite;
    var BackgroundMediator = (function (_super) {
        __extends(BackgroundMediator, _super);
        function BackgroundMediator() {
            return _super.call(this, BackgroundMediator.NAME) || this;
        }
        BackgroundMediator.prototype.onRegister = function () {
            _super.prototype.onRegister.call(this);
            var header = new Sprite(this.portal_proxy.getTexture(gpts.PortalProxy.HEADER_BACKGROUND));
            var footer = new Sprite(this.portal_proxy.getTexture(gpts.PortalProxy.FOOTER_BACKGROUND));
            footer.y = gpts.PortalProxy.STAGE_HEIGHT - footer.height;
            this.viewComponent = new gpts.Holder();
            this.viewComponent.addChildren(header, footer);
            this._stage.view.stage.addChild(this.viewComponent);
        };
        BackgroundMediator.prototype.handleNotification = function (notification) {
            _super.prototype.handleNotification.call(this, notification);
            switch (notification.getName()) {
                case gpts.Router.CHANGE_PAGE:
                    this.viewComponent.visible = this._router.page != gpts.Router.GAME_PAGE;
                    break;
            }
        };
        BackgroundMediator.prototype.listNotificationInterests = function () {
            return [gpts.Router.CHANGE_PAGE];
        };
        BackgroundMediator.NAME = 'BackgroundMediator';
        return BackgroundMediator;
    }(gpts.BaseMediator));
    gpts.BackgroundMediator = BackgroundMediator;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var GamesFilter = (function (_super) {
        __extends(GamesFilter, _super);
        function GamesFilter(groups, createItem) {
            var _this = _super.call(this) || this;
            var length = groups.length;
            var item;
            for (var i = 0; i < length; i++) {
                var posX = 0;
                if (item)
                    posX = item.x + item.width + 5;
                item = createItem != null ? createItem(groups[i]) : new gpts.Button();
                item.x = posX;
                _this.addChild(item);
            }
            return _this;
        }
        return GamesFilter;
    }(gpts.Holder));
    gpts.GamesFilter = GamesFilter;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var LoaderMax = gamy.LoaderMax;
    var Capabilities = gamy.Capabilities;
    var EVENT_TYPE = gamy.EVENT_TYPE;
    var trace = gamy.trace;
    var GamesFilterMediator = (function (_super) {
        __extends(GamesFilterMediator, _super);
        function GamesFilterMediator() {
            var _this = _super.call(this, GamesFilterMediator.NAME) || this;
            _this.selected_name = null;
            return _this;
        }
        GamesFilterMediator.prototype.onRegister = function () {
            _super.prototype.onRegister.call(this);
            this.item_height = this.portal_proxy.getTexture(gpts.PortalProxy.GAMES_FILTER_LEFT + '_idle').height;
            this.item_left_texture_width = this.portal_proxy.getTexture(gpts.PortalProxy.GAMES_FILTER_LEFT + '_idle').width;
            this.selected_name = this._router.parameters.groupId;
            var that = this;
            this.viewComponent = new gpts.GamesFilter(this.app_facade.groups, function (groupID) {
                var src = new gpts.Scale3MovieClip([{
                        content: new gpts.Scale3Sprite(100, that.item_height, that.portal_proxy.getTexture(gpts.PortalProxy.GAMES_FILTER_LEFT + '_idle'), that.portal_proxy.getTexture(gpts.PortalProxy.GAMES_FILTER_CENTER + '_idle')),
                        label: 'idle'
                    }, {
                        content: new gpts.Scale3Sprite(100, that.item_height, that.portal_proxy.getTexture(gpts.PortalProxy.GAMES_FILTER_LEFT + '_selected'), that.portal_proxy.getTexture(gpts.PortalProxy.GAMES_FILTER_CENTER + '_selected')),
                        label: 'selected'
                    }]);
                var item = new gpts.Button(src, { supportedStates: { selected: 0xff0000 } });
                item.label.text = LoaderMax.getContent(gpts.Main.CONTENT).gamesFilter[groupID][that._router.language].toUpperCase();
                src.setWidth(item.label.width + 2 * that.item_left_texture_width);
                item.setState(that.selected_name == groupID ? 'selected' : 'idle');
                item.label.x = (item.width - item.label.width) / 2;
                item.label.y = (item.height - item.label.height) / 2;
                item.interactive = true;
                item.buttonMode = true;
                item.name = groupID;
                item.on(Capabilities.eventType(EVENT_TYPE.CLICK), that.onClickFilterItem, that);
                return item;
            });
            this._stage.view.stage.addChild(this.viewComponent);
            this.viewComponent.x = (gpts.PortalProxy.STAGE_WIDTH - this.viewComponent.width) / 2;
            this.viewComponent.y = (GamesFilterMediator.HEADER_HEIGHT - this.item_height) / 2;
        };
        GamesFilterMediator.prototype.onClickFilterItem = function (event) {
            trace(gpts.ELogger.PORTAL, 'games filter: ' + event.target.name);
            if (this.selected_name != event.target.name) {
                if (this.selected_name != null)
                    this.viewComponent.getChildByName(this.selected_name).setState('idle');
                this.selected_name = event.target.name;
                event.target.setState('selected');
                this._router.redirectTo(gpts.Router.HOME_PAGE, { groupId: event.target.name });
                this.app_facade.sendNotification(gpts.AppFacade.PLAY_SOUND, gpts.AppFacade.ARROW);
            }
        };
        GamesFilterMediator.prototype.handleNotification = function (notification) {
            _super.prototype.handleNotification.call(this, notification);
            switch (notification.getName()) {
                case gpts.Router.CHANGE_PAGE:
                    this.viewComponent.visible = this._router.page != gpts.Router.GAME_PAGE;
                    break;
                case gpts.Router.CHANGE_LANG:
                    this.translateContent();
                    break;
            }
        };
        GamesFilterMediator.prototype.translateContent = function () {
            var length = this.viewComponent.children.length;
            var item;
            for (var i = 0; i < length; i++) {
                var posX = 0;
                if (item instanceof gpts.Button)
                    posX = item.x + item.width + 5;
                item = this.viewComponent.getChildAt(i);
                if (item instanceof gpts.Button) {
                    item.label.text = LoaderMax.getContent(gpts.Main.CONTENT).gamesFilter[item.name][this._router.language].toUpperCase();
                    if (item.src instanceof gpts.Scale3MovieClip)
                        item.src.setWidth(item.label.width + 2 * this.item_left_texture_width);
                    item.x = posX;
                }
            }
            this.viewComponent.x = (gpts.PortalProxy.STAGE_WIDTH - this.viewComponent.width) / 2;
        };
        GamesFilterMediator.prototype.listNotificationInterests = function () {
            return _super.prototype.listNotificationInterests.call(this).concat(gpts.Router.CHANGE_LANG);
        };
        GamesFilterMediator.NAME = 'GamesFilterMediator';
        GamesFilterMediator.HEADER_HEIGHT = 40;
        return GamesFilterMediator;
    }(gpts.BaseMediator));
    gpts.GamesFilterMediator = GamesFilterMediator;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Capabilities = gamy.Capabilities;
    var DeviceOrientation = gamy.DeviceOrientation;
    var Browser = gamy.Browser;
    var FullscreenIOSMediator = (function (_super) {
        __extends(FullscreenIOSMediator, _super);
        function FullscreenIOSMediator() {
            var _this = _super.call(this, FullscreenIOSMediator.NAME) || this;
            _this._window = $(window);
            _this._isFullscreen = undefined;
            _this._fullscreenAnimation = undefined;
            return _this;
        }
        FullscreenIOSMediator.prototype.onRegister = function () {
            _super.prototype.onRegister.call(this);
            if (window.navigator.standalone)
                return;
            var svg = "\n            <svg class=\"full-screen-hand\" style=\"display: none\">\n                <g id=\"Artboard\" transform=\"translate(-43.000000, -44.000000)\" fill=\"#E8E8E8\" fill-rule=\"nonzero\">\n                    <path\n                        d=\"M54.0888672,44.2789912 C56.1064453,44.7343558 56.8219819,45.5691478 58.2626363,46.7136733 C60.3227722,48.3538407 61.3000161,50.7171184 62.5605887,52.8840548 C66.5968222,59.8278291 70.5826328,66.7907586 74.6020587,73.7393216 C74.7605307,74.0170726 74.8973929,74.5007424 75.3536001,74.3546837 C75.7425768,74.232569 75.5288797,73.8015761 75.5745004,73.5118532 C75.9346704,71.0048595 77.3955873,68.7879917 79.560311,67.4635863 C83.5965445,64.877629 90.2019451,66.2663839 92.8239362,71.3185782 C93.0376332,71.7328103 93.2057096,72.1877472 93.7699659,72.5157807 C94.4710844,68.0909204 96.6128573,64.8034025 101.282979,64.2071957 C106.930344,63.4888742 110.279866,66.728504 112.582512,71.5197083 C112.844231,69.7239046 113.26202,68.0669764 114.212852,66.6255446 C116.746003,62.7944968 121.437734,62.0043431 125.322699,63.6445105 C127.742999,64.664527 129.282098,66.5177964 130.561879,68.7517762 C136.999203,80.0054793 143.506159,91.2304495 149.984302,102.467392 C151.869158,105.73336 154.078162,108.836509 155.326729,112.432905 C158.304081,121.009663 157.353249,129.102752 152.111668,136.587662 C150.241219,139.257423 147.69126,141.189708 144.874781,142.813115 C138.631945,146.404722 132.389109,150.046612 126.146273,153.61667 C120.731814,156.703058 115.053234,156.461223 109.300221,154.761195 C104.349172,153.298214 99.8615331,150.769722 95.2034171,148.631519 C83.5341162,143.275235 71.6415138,138.440931 59.7993344,133.489302 C53.6429378,130.915317 51.2010285,123.523789 54.8218733,118.356663 C57.2373706,114.911114 61.960316,113.74025 65.8020612,115.483377 C70.8323463,117.767639 75.9178564,119.929787 80.9793556,122.147006 C81.1234211,122.20926 81.2578822,122.31222 81.4595738,122.147006 C77.5457959,115.385206 73.6304173,108.618618 69.713438,101.847241 C61.4568874,87.6021279 53.198736,73.3594094 44.9389839,59.1190852 C44.305096,58.0248422 43.9521356,56.8180621 43.3758739,55.7046638 C42.8747087,53.8242578 42.8747087,51.9551878 43.3758739,50.0974538 C44.1276216,47.3108529 45.7793094,46.1130144 47.180102,45.060318 C49.3335802,43.8236266 52.0712891,43.8236266 54.0888672,44.2789912 Z\"\n                        id=\"hand\"\n                    ></path>\n                </g>\n            </svg>\n            ";
            $("body").append(svg);
            document.documentElement.style.paddingBottom = "125px";
            this.viewComponent = $("<div id='iOSFullscreen'>");
            this._fullscreenAnimation = $("<div id='iOSFullscreenAnimation'>");
            $("body").prepend(this._fullscreenAnimation);
            $("body").prepend(this.viewComponent);
            var handSvg = document.getElementsByClassName("full-screen-hand")[0];
            handSvg.style.display = "inherit";
            this._fullscreenAnimation.append(handSvg);
            this.checkFullscreenIOS();
            var handleViewportInterval = -1;
            var handleViewportCountdown = 5;
            var that = this;
            this._window.on("resize", function () {
                that.checkFullscreenIOS();
                if (window.navigator.standalone || Capabilities.browser == Browser.criOS) {
                    clearInterval(handleViewportInterval);
                    handleViewportCountdown = 5;
                    handleViewportInterval = setInterval(function () {
                        that.checkFullscreenIOS();
                        if (--handleViewportCountdown == 0) {
                            clearInterval(handleViewportInterval);
                        }
                    }, 100);
                }
            });
            this._window.on("gesturestart", this.preventDefault);
            this._window.on("gesturechange", this.preventDefault);
            this._window.on("gestureend", this.preventDefault);
            this._window.on("touchstart", function (event) {
                if (that._isFullscreen) {
                    that.preventDefault(event);
                }
            });
            var scrollTimeout = -1;
            this._window.on("scroll", function () {
                clearTimeout(scrollTimeout);
                scrollTimeout = setTimeout(function () {
                    window.scrollTo(0, 0);
                }, 300);
            });
        };
        FullscreenIOSMediator.prototype.preventDefault = function (event) {
            event.preventDefault();
            event.stopPropagation();
        };
        FullscreenIOSMediator.prototype.checkFullscreenIOS = function () {
            var width, height;
            if (Capabilities.orientation == DeviceOrientation.portraitPrimary ||
                Capabilities.orientation == DeviceOrientation.portraitSecondary) {
                width = Math.min(window.screen.width, window.screen.height);
                height = Math.max(window.screen.width, window.screen.height);
            }
            else {
                width = Math.max(window.screen.width, window.screen.height);
                height = Math.min(window.screen.width, window.screen.height);
            }
            if (height === window.innerHeight || window.innerHeight / height >= 0.9) {
                if (this._isFullscreen === false || this._isFullscreen == undefined) {
                    this.viewComponent.css("visibility", "hidden");
                    this._fullscreenAnimation.css("visibility", "hidden");
                    this.viewComponent.css("height", "120vh");
                    this._isFullscreen = true;
                }
            }
            else {
                if (this._isFullscreen === true || this._isFullscreen == undefined) {
                    this.viewComponent.css("visibility", "visible");
                    this._fullscreenAnimation.css("visibility", "visible");
                    this.viewComponent.css("height", "155vh");
                    this._isFullscreen = false;
                }
            }
        };
        FullscreenIOSMediator.NAME = "FullscreenIOSMediator";
        return FullscreenIOSMediator;
    }(gpts.BaseMediator));
    gpts.FullscreenIOSMediator = FullscreenIOSMediator;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var IGame = gpts.abstract_games.IGame;
    var Capabilities = gamy.Capabilities;
    var DeviceOrientation = gamy.DeviceOrientation;
    var UnsupportedPortraitMediator = (function (_super) {
        __extends(UnsupportedPortraitMediator, _super);
        function UnsupportedPortraitMediator() {
            return _super.call(this, UnsupportedPortraitMediator.NAME) || this;
        }
        UnsupportedPortraitMediator.prototype.onRegister = function () {
            _super.prototype.onRegister.call(this);
            this.viewComponent = $('#unsupportPortrait');
            var that = this;
            window.addEventListener('orientationchange', function () {
                that.onOrientationChange();
            });
            this.onOrientationChange();
        };
        UnsupportedPortraitMediator.prototype.gameSupportPortrait = function () {
            var gameProxy = this.app_facade.retrieveProxy(this._router.parameters.gameIdentificationNumber);
            if (gameProxy instanceof IGame) {
                return gameProxy.supportPortrait();
            }
            return false;
        };
        UnsupportedPortraitMediator.prototype.onOrientationChange = function () {
            if (Capabilities.orientation == DeviceOrientation.portraitPrimary || Capabilities.orientation == DeviceOrientation.portraitSecondary) {
                if (!this.gameSupportPortrait()) {
                    this.viewComponent.css('visibility', 'visible');
                }
            }
            else {
                this.viewComponent.css('visibility', 'hidden');
            }
        };
        UnsupportedPortraitMediator.NAME = 'UnssuportedPortraitMediator';
        return UnsupportedPortraitMediator;
    }(gpts.BaseMediator));
    gpts.UnsupportedPortraitMediator = UnsupportedPortraitMediator;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Facade = puremvc.Facade;
    var Hash = gamy.Hash;
    var trace = gamy.trace;
    var ArrayTools = gamy.ArrayTools;
    var Capabilities = gamy.Capabilities;
    var Browser = gamy.Browser;
    var Router = (function (_super) {
        __extends(Router, _super);
        function Router() {
            var _this = _super.call(this, Router.NAME) || this;
            _this._parameters = new Hash();
            _this.old_parameters = new Hash();
            _this.language = 'en';
            _this.mediator_names = [];
            return _this;
        }
        Router.getInstance = function () {
            if (!Facade.hasCore(Router.NAME))
                Facade.instanceMap[Router.NAME] = new Router();
            return Facade.getInstance(Router.NAME);
        };
        Router.prototype.redirectTo = function (pageName, parameters) {
            parameters = new Hash({ language: this.language }).merge(parameters);
            this.processLanguageParam(parameters);
            if (this._page == null || this._page != pageName || !this._parameters.diff(parameters).isEmpty()) {
                this.old_parameters = this._parameters;
                this._page = pageName;
                this._parameters = new Hash(parameters);
                trace(gpts.ELogger.PORTAL, 'Page change: ' + this._page + ', ' + this.parameters);
                this.manageMediatorsOnPageChange(pageName);
                this.sendNotification(Router.CHANGE_PAGE);
            }
        };
        Router.prototype.manageMediatorsOnPageChange = function (pageName) {
            switch (pageName) {
                case Router.HOME_PAGE:
                    this.setMediators(new gpts.StageMediator(), new gpts.BackgroundMediator(), new gpts.NavigationMediator(this.parameters.groupId), new gpts.StaticControlsMediator(), new gpts.GameLoadingMediator(), new gpts.GamesFilterMediator());
                    break;
                case Router.GAME_PAGE:
                    this.setMediators(new gpts.StageMediator(), new gpts.BackgroundMediator(), new gpts.NavigationMediator(this.oldParameters.groupId), new gpts.StaticControlsMediator(), new gpts.GameInterfaceMediator(), new gpts.GameLoadingMediator(), new gpts.GamesFilterMediator());
                    break;
                case Router.SESSION_CLOSED_PAGE:
                    this.setMediators(new gpts.SessionClosedMediator());
                    break;
                case Router.LOADING_PAGE:
                    this.setMediators(new gpts.StageMediator(), new gpts.LoadingMediator());
                    break;
                case Router.SINGLE_GAME_PAGE:
                    if (MOB) {
                        if ((Capabilities.browser == Browser.safari || Capabilities.browser == Browser.criOS) && !Capabilities.isInIframe) {
                            this.setMediators(new gpts.StageMediator(), new gpts.GameLoadingMediator(), new gpts.GameInterfaceMediator(), new gpts.FullscreenIOSMediator(), new gpts.UnsupportedPortraitMediator());
                        }
                        else {
                            this.setMediators(new gpts.StageMediator(), new gpts.GameLoadingMediator(), new gpts.GameInterfaceMediator(), new gpts.UnsupportedPortraitMediator());
                        }
                    }
                    else {
                        this.setMediators(new gpts.StageMediator(), new gpts.GameLoadingMediator(), new gpts.GameInterfaceMediator());
                    }
                    break;
            }
        };
        Router.prototype.setMediators = function () {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                args[_i] = arguments[_i];
            }
            var length = args.length;
            var newMediatorNames = [];
            for (var i = 0; i < length; i++) {
                this.registerMediator(args[i]);
                newMediatorNames[i] = args[i].getMediatorName();
            }
            trace(gpts.ELogger.PORTAL, 'New mediators: ' + newMediatorNames);
            var rest = ArrayTools.diff(this.mediator_names, newMediatorNames);
            trace(gpts.ELogger.PORTAL, 'Removed mediators: ' + rest);
            length = rest.length;
            for (i = 0; i < length; i++)
                this.removeMediator(rest[i]);
        };
        Router.prototype.registerMediator = function (mediator) {
            if (!ArrayTools.has(this.mediator_names, mediator.getMediatorName()))
                this.mediator_names.push(mediator.getMediatorName());
            _super.prototype.registerMediator.call(this, mediator);
        };
        Router.prototype.removeMediator = function (mediatorName) {
            var index = this.mediator_names.indexOf(mediatorName);
            if (index > -1)
                this.mediator_names.splice(index, 1);
            return _super.prototype.removeMediator.call(this, mediatorName);
        };
        Router.prototype.processLanguageParam = function (parameters) {
            if (parameters.language != this.language) {
                this._parameters.language = this.language = parameters.language;
                this.sendNotification(Router.CHANGE_LANG, this.language);
            }
        };
        Object.defineProperty(Router.prototype, "parameters", {
            get: function () {
                return this._parameters;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Router.prototype, "page", {
            get: function () {
                return this._page;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Router.prototype, "oldParameters", {
            get: function () {
                return this.old_parameters;
            },
            enumerable: true,
            configurable: true
        });
        Router.NAME = 'router';
        Router.CHANGE_PAGE = 'onChangePage';
        Router.CHANGE_LANG = 'onChangeLang';
        Router.ICON_HAS_LOADED = 'iconHasLoaded';
        Router.HOME_PAGE = 'homepage';
        Router.GAME_PAGE = 'game';
        Router.SINGLE_GAME_PAGE = 'singleGame';
        Router.SESSION_CLOSED_PAGE = 'sessionClosed';
        Router.LOADING_PAGE = 'loading';
        return Router;
    }(Facade));
    gpts.Router = Router;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var SimpleCommand = puremvc.SimpleCommand;
    var getDefinitionByName = gamy.getDefinitionByName;
    var StringTools = gamy.StringTools;
    var trace = gamy.trace;
    var LaunchGameCommand = (function (_super) {
        __extends(LaunchGameCommand, _super);
        function LaunchGameCommand() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        LaunchGameCommand.prototype.execute = function (notification) {
            _super.prototype.execute.call(this, notification);
            var facade = this.facade();
            var iData = notification.getBody() || {};
            var gameType = iData.gameType;
            var gameIdentificationNumber = String(iData.gameIdentificationNumber);
            if (!facade.hasProxy(gameIdentificationNumber)) {
                try {
                    var definition = getDefinitionByName('gpts.abstract_games.' + StringTools.toPackageNameConvention(gameType) + '.' + gameType + 'Proxy');
                    facade.registerProxy(new definition(iData));
                }
                catch (error) {
                    trace(gpts.ELogger.RUNTIME_ERRORS, error.message, '.Try to launch: ' + gameType, error.stack);
                }
            }
            else {
                var gameProxy = facade.retrieveProxy(gameIdentificationNumber);
                if (!gameProxy.hasSettings) {
                    gameProxy.getSettings();
                }
                else
                    gpts.Router.getInstance().redirectTo(gpts.Router.GAME_PAGE, {
                        gameType: gameType,
                        gameIdentificationNumber: parseInt(gameIdentificationNumber)
                    });
            }
        };
        return LaunchGameCommand;
    }(SimpleCommand));
    gpts.LaunchGameCommand = LaunchGameCommand;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var SimpleCommand = puremvc.SimpleCommand;
    var RecoveryUpdateBalanceCommand = (function (_super) {
        __extends(RecoveryUpdateBalanceCommand, _super);
        function RecoveryUpdateBalanceCommand() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        RecoveryUpdateBalanceCommand.prototype.execute = function (notification) {
            _super.prototype.execute.call(this, notification);
            var facade = this.facade();
            var message = notification.getBody();
            if (facade.gamesRecoveryList[message.gameIdentificationNumber] != gpts.EMessage.FAILURE) {
                if (message.gameRecoveryType != gpts.EMessage.COMPLETE_RECOVERY)
                    facade.gamesRecoveryList[message.gameIdentificationNumber] = gpts.EMessage.FAILURE;
                else if (message.winAmount > 0)
                    facade.balance += message.winAmount;
            }
        };
        return RecoveryUpdateBalanceCommand;
    }(SimpleCommand));
    gpts.RecoveryUpdateBalanceCommand = RecoveryUpdateBalanceCommand;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var GameEvent = (function () {
        function GameEvent(type, gameIdentificationNumber, gameType, amount, state) {
            if (gameIdentificationNumber === void 0) { gameIdentificationNumber = null; }
            if (gameType === void 0) { gameType = null; }
            if (amount === void 0) { amount = 0; }
            if (state === void 0) { state = null; }
            this.type = type;
            this.gameIdentificationNumber = gameIdentificationNumber;
            this.gameType = gameType;
            this.amount = amount;
            this.state = state;
        }
        GameEvent.DESTROY = 'onDestroyGame';
        GameEvent.BONUS_SPINS_CHANGED = 'bonusSpinsChanged';
        GameEvent.HIDE = 'HideGame';
        GameEvent.INTEGRATED_PROGRESS = 'IntegratedProgress';
        GameEvent.COMPLETE_INTEGRATION = 'CompleteIntegration';
        GameEvent.FAIL_INTEGRATION = 'FailIntegration';
        return GameEvent;
    }());
    gpts.GameEvent = GameEvent;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var SimpleCommand = puremvc.SimpleCommand;
    var MessagesFacade = gpts.services.MessagesFacade;
    var trace = gamy.trace;
    var ExitPlatformCommand = (function (_super) {
        __extends(ExitPlatformCommand, _super);
        function ExitPlatformCommand() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ExitPlatformCommand.prototype.execute = function (notification) {
            _super.prototype.execute.call(this, notification);
            try {
                var messagesFacade = MessagesFacade.getInstance();
                messagesFacade.close();
                messagesFacade.ping.stop();
                window['closePopup'].call();
            }
            catch (error) {
                trace(gpts.ELogger.RUNTIME_ERRORS, '[Exit Platform]', error.message, error.stack);
            }
        };
        return ExitPlatformCommand;
    }(SimpleCommand));
    gpts.ExitPlatformCommand = ExitPlatformCommand;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var SimpleCommand = puremvc.SimpleCommand;
    var LoaderMax = gamy.LoaderMax;
    var GameResponse = gpts.services.messages.response.GameResponse;
    var StringTools = gamy.StringTools;
    var Hash = gamy.Hash;
    var IGame = gpts.abstract_games.IGame;
    var GameData = gpts.abstract_games.GameData;
    var DataHandler = gpts.abstract_games.DataHandler;
    var PopUpOnEventCommand = (function (_super) {
        __extends(PopUpOnEventCommand, _super);
        function PopUpOnEventCommand() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        PopUpOnEventCommand.prototype.execute = function (notification) {
            _super.prototype.execute.call(this, notification);
            var message = notification.getBody();
            var content = LoaderMax.getContent(gpts.Main.CONTENT);
            var router = gpts.Router.getInstance();
            var that = this;
            if (message instanceof GameResponse) {
                var complex = {
                    totalWin: message.totalWin,
                    totalBet: message.totalBet,
                    result: message.balance,
                    timePassed: message.playTime
                };
            }
            var popupType = message instanceof GameResponse ? message.msg : message.reason;
            switch (popupType) {
                case gpts.EMessage.SESSION_SHUTDOWN:
                    gpts.Alert.show(content.shutdownNotification[router.language]);
                    break;
                case gpts.EMessage.REALITY_CHECK:
                    var popupOptions = {
                        exitLabelCallback: function () {
                            that.exitPlatform();
                        },
                        okLabelCallback: function () {
                            that.notifyGameForResponibleGamingCompletion();
                        }
                    };
                    var isRealityCheckTimePassedOnly = complex.totalWin == -1 || complex.totalBet == -1;
                    if (!isRealityCheckTimePassedOnly) {
                        var renderTemplateValues = new Hash(complex).mapValues(function (k, v) {
                            switch (k) {
                                case 'totalWin':
                                    return that.formatCurrency(v);
                                case 'totalBet':
                                    return that.formatCurrency(v);
                                case 'result':
                                    return that.formatCurrency(v);
                            }
                            return v;
                        });
                        gpts.Alert.show(StringTools.renderTemplate(content.realityCheck[router.language], renderTemplateValues), gpts.PopUpType.OK_EXIT, popupOptions);
                    }
                    else {
                        var renderTemplateValues = {
                            timePassed: complex.timePassed,
                        };
                        gpts.Alert.show(StringTools.renderTemplate(content.realityCheckTimePassedOnly[router.language], renderTemplateValues), gpts.PopUpType.OK_EXIT, popupOptions);
                    }
                    this.notifyGameForResponibleGaming(message);
                    break;
                case gpts.EMessage.LOSS_LIMIT:
                    gpts.Alert.show(content.lossLimit[router.language], gpts.PopUpType.OK, {
                        okLabelCallback: function () {
                            that.exitPlatform();
                        }
                    });
                    this.notifyGameForResponibleGaming(message);
                    break;
                case gpts.EMessage.BET_LIMIT:
                    gpts.Alert.show(content.betLimit[router.language], gpts.PopUpType.OK, {
                        okLabelCallback: function () {
                            that.exitPlatform();
                        }
                    });
                    this.notifyGameForResponibleGaming(message);
                    break;
                case gpts.EMessage.TIME_LIMIT:
                    gpts.Alert.show(content.timeLimit[router.language], gpts.PopUpType.OK, {
                        okLabelCallback: function () {
                            that.exitPlatform();
                        }
                    });
                    this.notifyGameForResponibleGaming(message);
                    break;
                case gpts.EMessage.TIME_PROXIM_ALERT:
                    gpts.Alert.show(content.timeProximityAlert[router.language], gpts.PopUpType.OK, {
                        okLabelCallback: function () {
                            that.notifyGameForResponibleGamingCompletion();
                        }
                    });
                    this.notifyGameForResponibleGaming(message);
                    break;
                case gpts.EMessage.CREDIT_LEFT_ALERT:
                    gpts.Alert.show(content.creditLeftAlert[router.language], gpts.PopUpType.OK, {
                        okLabelCallback: function () {
                            that.notifyGameForResponibleGamingCompletion();
                        }
                    });
                    this.notifyGameForResponibleGaming(message);
                    break;
            }
        };
        PopUpOnEventCommand.prototype.formatCurrency = function (value) {
            var facade = gpts.AppFacade.getInstance();
            return facade.formatCurrency(value) + (facade.isEGTCurrency ? (value > 100 ? ' DIAMONDS' : ' DIAMOND') : (' ' + facade.currency));
        };
        PopUpOnEventCommand.prototype.exitPlatform = function () {
            this.sendNotification(gpts.AppFacade.EXIT_PLATFORM);
        };
        PopUpOnEventCommand.prototype.notifyGameForResponibleGaming = function (message) {
            if (gpts.Router.getInstance().parameters.has('gameIdentificationNumber')) {
                var gameProxy = this.facade().retrieveProxy(gpts.Router.getInstance().parameters.gameIdentificationNumber);
                if (gameProxy instanceof IGame) {
                    var data = new GameData().merge(message);
                    data.command = gpts.EMessage.RESPONSIBLE_GAMING;
                    DataHandler.set(LoaderMax.getLoader(gameProxy.interests()).content, data);
                }
            }
        };
        PopUpOnEventCommand.prototype.notifyGameForResponibleGamingCompletion = function () {
            if (gpts.Router.getInstance().parameters.has('gameIdentificationNumber')) {
                var gameProxy = this.facade().retrieveProxy(gpts.Router.getInstance().parameters.gameIdentificationNumber);
                if (gameProxy instanceof IGame) {
                    var data = new GameData();
                    data.command = gpts.EMessage.RESPONSIBLE_GAMING_COMPLETE;
                    DataHandler.set(LoaderMax.getLoader(gameProxy.interests()).content, data);
                }
            }
        };
        return PopUpOnEventCommand;
    }(SimpleCommand));
    gpts.PopUpOnEventCommand = PopUpOnEventCommand;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var SimpleCommand = puremvc.SimpleCommand;
    var SoundCommand = (function (_super) {
        __extends(SoundCommand, _super);
        function SoundCommand() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        SoundCommand.prototype.execute = function (notification) {
            _super.prototype.execute.call(this, notification);
            try {
                if (!gpts.muted) {
                    var options = {
                        src: [notification.getBody() + '?build=' + BUILD]
                    };
                    var sound = new Howl(options);
                    sound.play();
                }
            }
            catch (error) {
            }
        };
        return SoundCommand;
    }(SimpleCommand));
    gpts.SoundCommand = SoundCommand;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Facade = puremvc.Facade;
    var Hash = gamy.Hash;
    var IGame = gpts.abstract_games.IGame;
    var trace = gamy.trace;
    var EventDispatcher = gamy.EventDispatcher;
    var LoaderMax = gamy.LoaderMax;
    var NumberTools = gamy.NumberTools;
    var AppFacade = (function (_super) {
        __extends(AppFacade, _super);
        function AppFacade() {
            var _this = _super.call(this, AppFacade.NAME) || this;
            _this.originalGamesList = {};
            _this.gamesList = new Hash();
            _this.gamesRecoveryList = new Hash();
            _this.gamesWithBonusesList = new Hash();
            _this.subscribeMessagesIds = [];
            _this.interests = new Hash();
            _this.gamesEnum = new Hash();
            _this.recoveryMessagesIds = [];
            _this._balance = 0;
            _this._totalBet = 0;
            _this._totalWin = 0;
            _this.languages = [];
            _this.groups = [];
            return _this;
        }
        AppFacade.getInstance = function () {
            if (!Facade.hasCore(AppFacade.NAME))
                Facade.instanceMap[AppFacade.NAME] = new AppFacade();
            return Facade.getInstance(AppFacade.NAME);
        };
        AppFacade.prototype.initializeFacade = function () {
            this._dispatcher = new EventDispatcher(this);
            _super.prototype.initializeFacade.call(this);
        };
        AppFacade.prototype.initializeController = function () {
            _super.prototype.initializeController.call(this);
            this.registerCommand(AppFacade.LOGIN, gpts.LoginCommand);
            this.registerCommand(AppFacade.UPDATE_BALANCE, gpts.UpdateBalanceCommand);
            this.registerCommand(AppFacade.DISPOSE_CHECK, gpts.DisposeCheckCommand);
            this.registerCommand(AppFacade.LAUNCH_GAME, gpts.LaunchGameCommand);
            this.registerCommand(AppFacade.RECOVERY_UPDATE_BALANCE, gpts.RecoveryUpdateBalanceCommand);
            this.registerCommand(AppFacade.EXIT_PLATFORM, gpts.ExitPlatformCommand);
            this.registerCommand(AppFacade.POPUP_ON_EVENT, gpts.PopUpOnEventCommand);
            this.registerCommand(AppFacade.PLAY_SOUND, gpts.SoundCommand);
        };
        AppFacade.prototype.registerProxy = function (proxy) {
            _super.prototype.registerProxy.call(this, proxy);
            var gameProxy = proxy;
            if (gameProxy instanceof IGame) {
                if (this.gamesEnum.has(gameProxy.gameType()))
                    this.gamesEnum[gameProxy.gameType()]++;
                else
                    this.gamesEnum[gameProxy.gameType()] = 1;
                trace('[GAMES] ' + this.gamesEnum);
            }
        };
        AppFacade.prototype.removeProxy = function (proxyName) {
            var gameProxy = this.retrieveProxy(proxyName);
            var gameType, amount, state;
            if (gameProxy instanceof IGame) {
                this.gamesEnum[gameProxy.gameType()]--;
                gameType = gameProxy.gameType();
                amount = this.gamesEnum[gameType];
                state = (gameProxy.canContinueAfterFailure && gameProxy.currentState == gpts.EMessage.FAILURE) ? gpts.EMessage.NO_RECOVERY : gameProxy.currentState;
            }
            var proxy = _super.prototype.removeProxy.call(this, proxyName);
            if (gameProxy instanceof IGame) {
                if (amount == 0 && this.gameIsDisposable(gameProxy.interests()))
                    this.sendNotification(AppFacade.DISPOSE_CHECK, gameProxy.interests(), gameType);
                trace('[GAMES] ' + this.gamesEnum);
                this.dispatchEvent(new gpts.GameEvent(gpts.GameEvent.DESTROY, proxyName, gameType, amount, state));
            }
            return proxy;
        };
        AppFacade.prototype.gameIsDisposable = function (gameLoaderName) {
            var loaders = LoaderMax.getContent(gpts.Main.CONTENT).loaders;
            var length = loaders.length;
            for (var i = 0; i < length; i++) {
                if (loaders[i].vars.name == gpts.Main.GAME_INTERFACE) {
                    loaders = loaders[i].children;
                    length = loaders.length;
                    break;
                }
            }
            for (i = 0; i < length; i++) {
                var loaderOptions = loaders[i].vars;
                if (loaderOptions.name == gameLoaderName) {
                    return loaderOptions.dispose == true;
                }
            }
            return true;
        };
        AppFacade.prototype.addEventListener = function (type, callback, context) {
            this._dispatcher.addEventListener(type, callback, context);
        };
        AppFacade.prototype.dispatchEvent = function (event) {
            this._dispatcher.dispatchEvent(event);
        };
        AppFacade.prototype.removeEventListener = function (type, callback, context) {
            this._dispatcher.removeEventListener(type, callback, context);
        };
        AppFacade.prototype.hasEventListener = function (type) {
            return this._dispatcher.hasEventListener(type);
        };
        Object.defineProperty(AppFacade.prototype, "balance", {
            get: function () {
                return this._balance;
            },
            set: function (value) {
                if (value == this._balance || isNaN(value))
                    return;
                this._balance = value;
                this.dispatchEvent({ type: AppFacade.UPDATE_BALANCE });
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(AppFacade.prototype, "totalBet", {
            get: function () {
                return this._totalBet;
            },
            set: function (value) {
                if (value == this._totalBet || isNaN(value))
                    return;
                this._totalBet = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(AppFacade.prototype, "totalWin", {
            get: function () {
                return this._totalWin;
            },
            set: function (value) {
                if (value == this._totalWin || isNaN(value))
                    return;
                this._totalWin = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(AppFacade.prototype, "activeGames", {
            get: function () {
                var amount = 0;
                var keys = Object.keys(this.gamesEnum);
                for (var _i = 0, keys_14 = keys; _i < keys_14.length; _i++) {
                    var name = keys_14[_i];
                    amount += this.gamesEnum[name];
                }
                return amount;
            },
            enumerable: true,
            configurable: true
        });
        AppFacade.prototype.formatCurrency = function (value) {
            var currencyInfo = LoaderMax.getContent(gpts.Main.CONTENT).currency[this.currency];
            var hideCents = currencyInfo && currencyInfo.displayType && currencyInfo.displayType == "hideCents";
            return this.isEGTCurrency ? String(value / 100) : (hideCents ? NumberTools.formatCurrency(value).split('.')[0] : NumberTools.formatCurrency(value));
        };
        AppFacade.NAME = 'appFacade';
        AppFacade.UPDATE_BALANCE = 'onUpdateBalance';
        AppFacade.LOGIN = 'loginCommand';
        AppFacade.DISPOSE_CHECK = 'disposeCheck';
        AppFacade.LAUNCH_GAME = 'launchGame';
        AppFacade.RECOVERY_UPDATE_BALANCE = 'recoveryUpdateBalance';
        AppFacade.PLAY_SOUND = 'playSound';
        AppFacade.EXIT_PLATFORM = 'exitPlatform';
        AppFacade.POPUP_ON_EVENT = 'popupOnEvent';
        AppFacade.HIDE_GAME = 'assets/sounds/HideGame.mp3';
        AppFacade.ROLLOVER_GAME_ICON = 'assets/sounds/OverGameIcon.mp3';
        AppFacade.SHOW_GAME = 'assets/sounds/lobby_enter_game.mp3';
        AppFacade.FULLSCREEN_IN = 'assets/sounds/enter_fullscreen.mp3';
        AppFacade.FULLSCREEN_OUT = 'assets/sounds/exit_fullscreen.mp3';
        AppFacade.ARROW = 'assets/sounds/button_touch.mp3';
        AppFacade.SLIDER_NAVIGATION_ITEM = 'assets/sounds/page_button.mp3';
        AppFacade.LANGUAGE_BAR_IN = 'assets/sounds/show_languages_INTRO.mp3';
        AppFacade.LANGUAGE_BAR_OUT = 'assets/sounds/show_languages_OUTRO.mp3';
        return AppFacade;
    }(Facade));
    gpts.AppFacade = AppFacade;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var EMessage = (function () {
        function EMessage() {
        }
        EMessage.PLATFORM_PACKAGE = 'jServer.gameManager.';
        EMessage.GAME_PACKAGE = 'jServer.';
        EMessage.LOGIN = 'login';
        EMessage.PING = 'ping';
        EMessage.EVENT = 'event';
        EMessage.CONFIG = 'config';
        EMessage.SESSION_TIMEOUT = 'sessionTimeout';
        EMessage.SESSION_OVERRIDE = 'override';
        EMessage.CONNECTION_CLOSED = 'connectionClosed';
        EMessage.USE_MOBILE_DEVICES = 'mobileGamesOnDesktopBrowser';
        EMessage.SESSION_SHUTDOWN = 'shutdown';
        EMessage.REALITY_CHECK = 'doRealityCheck';
        EMessage.BET_LIMIT = 'betLimitReached';
        EMessage.LOSS_LIMIT = 'lossLimitReached';
        EMessage.TIME_LIMIT = 'sessionTimeLimitReached';
        EMessage.RECOVERY = 'recover';
        EMessage.NO_RECOVERY = 'norecovery';
        EMessage.COMPLETE_RECOVERY = 'completed';
        EMessage.PROGRESS_RECOVERY = 'progress';
        EMessage.SUBSCRIBE = 'subscribe';
        EMessage.UNSUBSCRIBE = 'unsubscribe';
        EMessage.SETTINGS = 'settings';
        EMessage.BET = 'bet';
        EMessage.ACKNOWLEDGE_WIN = 'acknowledgeWin';
        EMessage.FAILURE = 'failure';
        EMessage.CLIENT_FAILURE = 'clientFailure';
        EMessage.CONNECTION_FAILURE = 'connectionFailure';
        EMessage.HARDWARE_FAILURE = 'hardwareFailure';
        EMessage.BALANCE = 'balance';
        EMessage.RESPONSIBLE_GAMING = 'responsibleGaming';
        EMessage.RESPONSIBLE_GAMING_COMPLETE = 'responsibleGamingComplete';
        EMessage.REQUEST_TIMEOUT = 'Timeouted request';
        EMessage.TIME_PROXIM_ALERT = 'timeProximityAlert';
        EMessage.CREDIT_LEFT_ALERT = 'creditLeftAlert';
        EMessage.SUCCESS = 'success';
        EMessage.IP_BLOCKED = 'ipBlocked';
        EMessage.GAME_FILTER = 'gameFiltered';
        EMessage.MAINTENANCE = 'maintenance';
        EMessage.BONUS_ERROR = 'bonusError';
        EMessage.HISTORY = 'history';
        EMessage.STATISTICS = 'statistics';
        return EMessage;
    }());
    gpts.EMessage = EMessage;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var services;
    (function (services) {
        var messages;
        (function (messages) {
            var request;
            (function (request) {
                var LoginRequest = (function (_super) {
                    __extends(LoginRequest, _super);
                    function LoginRequest(command, sessionKey, qName) {
                        if (command === void 0) { command = null; }
                        if (sessionKey === void 0) { sessionKey = null; }
                        if (qName === void 0) { qName = null; }
                        var _this = _super.call(this, command, sessionKey, qName) || this;
                        _this.platformType = MOB ? 'mobile' : 'desktop';
                        _this.mobileType = "redesign";
                        return _this;
                    }
                    LoginRequest.prototype.toString = function () {
                        var result = _super.prototype.toString.call(this);
                        return result.substr(0, result.length - 1).concat(', platformType: ' + this.platformType + ', mobileType: ' + this.mobileType + '}');
                    };
                    return LoginRequest;
                }(request.BaseRequest));
                request.LoginRequest = LoginRequest;
            })(request = messages.request || (messages.request = {}));
        })(messages = services.messages || (services.messages = {}));
    })(services = gpts.services || (gpts.services = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var services;
    (function (services) {
        var messages;
        (function (messages) {
            var request;
            (function (request) {
                var ConfigRequest = (function (_super) {
                    __extends(ConfigRequest, _super);
                    function ConfigRequest(command, sessionKey, qName, login, scenario) {
                        if (command === void 0) { command = null; }
                        if (sessionKey === void 0) { sessionKey = null; }
                        if (qName === void 0) { qName = null; }
                        var _this = _super.call(this, command, qName) || this;
                        _this.login = login;
                        _this.scenario = scenario;
                        _this.sessionKey = sessionKey;
                        return _this;
                    }
                    ConfigRequest.prototype.toString = function () {
                        var result = _super.prototype.toString.call(this);
                        return result.substr(0, result.length - 1).concat(', login: ' + this.login + ', scenario: ' + this.scenario + ", sessionKey: " + this.sessionKey + '}');
                    };
                    return ConfigRequest;
                }(services.Message));
                request.ConfigRequest = ConfigRequest;
            })(request = messages.request || (messages.request = {}));
        })(messages = services.messages || (services.messages = {}));
    })(services = gpts.services || (gpts.services = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Proxy = puremvc.Proxy;
    var MessagesFacade = gpts.services.MessagesFacade;
    var MessagesEvent = gpts.services.MessagesEvent;
    var BaseRequest = gpts.services.messages.request.BaseRequest;
    var trace = gamy.trace;
    var GameResponse = gpts.services.messages.response.GameResponse;
    var LoaderMax = gamy.LoaderMax;
    var GameRequest = gpts.services.messages.request.GameRequest;
    var GameMediator = gpts.abstract_games.GameMediator;
    var ArrayTools = gamy.ArrayTools;
    var IGame = gpts.abstract_games.IGame;
    var LoginRequest = gpts.services.messages.request.LoginRequest;
    var ConfigRequest = gpts.services.messages.request.ConfigRequest;
    var SocketProxy = (function (_super) {
        __extends(SocketProxy, _super);
        function SocketProxy(testServer, login, scenario) {
            var _this = _super.call(this, SocketProxy.NAME) || this;
            _this.testServerSettings = { testServer: testServer, login: login, scenario: scenario };
            return _this;
        }
        SocketProxy.prototype.onRegister = function () {
            _super.prototype.onRegister.call(this);
            this.messages_facade = MessagesFacade.getInstance();
            this.messages_facade.addEventListener('open', this.onOpenConnection, this);
            this.messages_facade.addEventListener(MessagesEvent.MESSAGE, this.onComingMessage, this);
            this.messages_facade.addEventListener(MessagesEvent.TIME_OUT, this.onMessageTimeout, this);
            this.messages_facade.addEventListener('error', this.onError, this);
            this.messages_facade.addEventListener('close', this.onLooseConnection, this);
            this.messages_facade.addEventListener(MessagesEvent.LOOSE_CONNECTION, this.onLooseConnection, this);
            this.messages_facade.pingMessage = new BaseRequest(gpts.EMessage.PING, gpts.AppFacade.getInstance().sessionKey, gpts.EMessage.PLATFORM_PACKAGE + gpts.EMessage.PING);
            this.messages_facade.getModuleName = function (response) {
                if (response.messageId.substr(0, 4) != MessagesFacade.REQUEST_RESPONSE_IDENTIFICATOR)
                    throw new Error('This is not a response of a request!');
                if (response.hasOwnProperty('gameIdentificationNumber'))
                    return gpts.AppFacade.getInstance().gamesList[response.gameIdentificationNumber].gameType;
                return gpts.Main.PLATFORM;
            };
            this.messages_facade.services = LoaderMax.getContent(gpts.Main.CONTENT).services;
        };
        SocketProxy.prototype.onOpenConnection = function (event) {
            if (this.testServerSettings.testServer) {
                this.messages_facade.send(new ConfigRequest(gpts.EMessage.CONFIG, gpts.AppFacade.getInstance().sessionKey, gpts.EMessage.PLATFORM_PACKAGE + gpts.EMessage.CONFIG, this.testServerSettings.login, this.testServerSettings.scenario));
            }
            else {
                this.messages_facade.send(new LoginRequest(gpts.EMessage.LOGIN, gpts.AppFacade.getInstance().sessionKey, gpts.EMessage.PLATFORM_PACKAGE + gpts.EMessage.LOGIN));
            }
        };
        SocketProxy.prototype.onComingMessage = function (event) {
            var message = event.data;
            if (message instanceof GameResponse) {
                this._facade.totalWin = message.totalWin;
                this._facade.totalBet = message.totalBet;
                var gameProxy = this._facade.retrieveProxy(String(message.gameIdentificationNumber));
                if (gameProxy instanceof IGame) {
                    this.sendNotification(gpts.AppFacade.POPUP_ON_EVENT, message);
                    gameProxy.setData(message);
                }
                if (ArrayTools.has(this._facade.subscribeMessagesIds, message.messageId))
                    this.onSubscribeOfProgressGame(message);
            }
            else {
                switch (message.command) {
                    case gpts.EMessage.CONFIG:
                        if (message["status"]) {
                            this.messages_facade.send(new LoginRequest(gpts.EMessage.LOGIN, gpts.AppFacade.getInstance().sessionKey, gpts.EMessage.PLATFORM_PACKAGE + gpts.EMessage.LOGIN));
                        }
                        else {
                            throw Error("scenario" + message["scenario"] + " failed to load");
                        }
                        break;
                    case gpts.EMessage.LOGIN:
                        var loginResponse = message;
                        if (loginResponse.msg != gpts.EMessage.SUCCESS) {
                            if (loginResponse.msg == gpts.EMessage.IP_BLOCKED)
                                gpts.Router.getInstance().redirectTo(gpts.Router.SESSION_CLOSED_PAGE, { reason: gpts.EMessage.IP_BLOCKED });
                            return;
                        }
                        this.sendNotification(gpts.AppFacade.LOGIN, message);
                        this.messages_facade.ping.start();
                        var that_5 = this;
                        gpts.Router.getInstance().registerProxy(new gpts.PortalProxy(function () {
                            that_5.checkForProgressGames();
                            this.preloadSound(gpts.AppFacade.SHOW_GAME);
                            this.preloadSound(gpts.AppFacade.HIDE_GAME);
                        }));
                        break;
                    case gpts.EMessage.EVENT:
                        var reason = message.reason;
                        if (reason == gpts.EMessage.SESSION_TIMEOUT || reason == gpts.EMessage.SESSION_OVERRIDE || reason == gpts.EMessage.CONNECTION_CLOSED || reason == gpts.EMessage.MAINTENANCE) {
                            try {
                                gpts.Router.getInstance().redirectTo(gpts.Router.SESSION_CLOSED_PAGE, { reason: reason });
                                this.messages_facade.close();
                                this.messages_facade.ping.stop();
                            }
                            catch (error) {
                                trace(gpts.ELogger.RUNTIME_ERRORS, '[SocketProxy]', error.message, error.stack);
                            }
                        }
                        else
                            this.sendNotification(gpts.AppFacade.POPUP_ON_EVENT, message);
                        break;
                }
            }
            if (message.command == gpts.EMessage.RECOVERY && ArrayTools.has(this._facade.recoveryMessagesIds, message.messageId)) {
                this.sendNotification(gpts.AppFacade.RECOVERY_UPDATE_BALANCE, message);
                this.onRecoveryOfProgressGame(message);
            }
        };
        SocketProxy.prototype.onMessageTimeout = function (event) {
            if (ArrayTools.has(this._facade.recoveryMessagesIds, event.messageId)) {
                this._facade.gamesRecoveryList[event.data.gameIdentificationNumber] = gpts.EMessage.FAILURE;
                this.onRecoveryOfProgressGame(event.data);
            }
            else if (event.data instanceof GameRequest) {
                var gameProxy = this._facade.retrieveProxy(String(event.data.gameIdentificationNumber));
                if (gameProxy instanceof IGame)
                    gameProxy.handleTimeoutMessage(event.data);
                if (ArrayTools.has(this._facade.subscribeMessagesIds, event.messageId)) {
                    this.onSubscribeOfProgressGame(event.data);
                }
            }
            else if (event.data instanceof BaseRequest) {
                if (event.data.command == gpts.EMessage.LOGIN) {
                    this.messages_facade.close();
                    this.messages_facade.ping.stop();
                }
            }
            this.messages_facade.removeProxy(event.messageId);
        };
        SocketProxy.prototype.onError = function (event) {
            trace('[socket error]' + event.toString());
        };
        SocketProxy.prototype.onLooseConnection = function (event) {
            this.messages_facade.ping.stop();
            if (gpts.Router.getInstance().parameters.has('gameIdentificationNumber')) {
                var gameType = this._facade.gamesList[gpts.Router.getInstance().parameters.gameIdentificationNumber].gameType;
                this.sendNotification(GameMediator.LOOSE_CONNECTION + gameType);
            }
        };
        SocketProxy.prototype.onRecoveryOfProgressGame = function (recovery) {
            this._facade.recoveryMessagesIds = ArrayTools.remove(this._facade.recoveryMessagesIds, recovery.messageId);
            if (this._facade.subscribeMessagesIds.length == 0 && this._facade.recoveryMessagesIds.length == 0) {
                this.goToPrimaryPage();
            }
        };
        SocketProxy.prototype.onSubscribeOfProgressGame = function (subscribe) {
            this._facade.subscribeMessagesIds = ArrayTools.remove(this._facade.subscribeMessagesIds, subscribe.messageId);
            if (this._facade.subscribeMessagesIds.length == 0 && this._facade.recoveryMessagesIds.length == 0)
                this.goToPrimaryPage();
        };
        SocketProxy.prototype.checkForProgressGames = function () {
            var keys = Object.keys(this._facade.gamesRecoveryList);
            var hasGameInProgress;
            for (var _i = 0, keys_15 = keys; _i < keys_15.length; _i++) {
                var gameIdentificationNumber = keys_15[_i];
                if (this._facade.gamesRecoveryList[gameIdentificationNumber] == gpts.EMessage.PROGRESS_RECOVERY) {
                    hasGameInProgress = true;
                    this.sendNotification(gpts.AppFacade.LAUNCH_GAME, this._facade.gamesList[gameIdentificationNumber]);
                }
            }
            if (!hasGameInProgress)
                this.goToPrimaryPage();
        };
        SocketProxy.prototype.goToPrimaryPage = function () {
            if (this._facade.singleGameMode) {
                if (this._facade.gamesRecoveryList.values[0] != gpts.EMessage.FAILURE)
                    this.sendNotification(gpts.AppFacade.LAUNCH_GAME, this._facade.gamesList.values[0]);
            }
            else
                gpts.Router.getInstance().redirectTo(gpts.Router.HOME_PAGE, { groupId: 'all' });
        };
        Object.defineProperty(SocketProxy.prototype, "_facade", {
            get: function () {
                return this.facade();
            },
            enumerable: true,
            configurable: true
        });
        SocketProxy.NAME = 'socketProxy';
        return SocketProxy;
    }(Proxy));
    gpts.SocketProxy = SocketProxy;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var services;
    (function (services) {
        var messages;
        (function (messages) {
            var response;
            (function (response) {
                var GameEventResponse = (function (_super) {
                    __extends(GameEventResponse, _super);
                    function GameEventResponse(command, eventTimestamp, msg, complex, reason, gameIdentificationNumber, gameNumber, state, winAmount, qName) {
                        if (command === void 0) { command = null; }
                        if (eventTimestamp === void 0) { eventTimestamp = -1; }
                        if (msg === void 0) { msg = null; }
                        if (complex === void 0) { complex = null; }
                        if (reason === void 0) { reason = null; }
                        if (gameIdentificationNumber === void 0) { gameIdentificationNumber = NaN; }
                        if (gameNumber === void 0) { gameNumber = -1; }
                        if (state === void 0) { state = null; }
                        if (winAmount === void 0) { winAmount = -1; }
                        if (qName === void 0) { qName = null; }
                        var _this = _super.call(this, command, eventTimestamp, msg, complex, reason, gameIdentificationNumber, gameNumber, qName) || this;
                        _this.state = state;
                        _this.winAmount = winAmount;
                        return _this;
                    }
                    GameEventResponse.prototype.toString = function () {
                        var result = _super.prototype.toString.call(this);
                        return result.substr(0, result.length - 1).concat(', state: ' + this.state + ', winAmount: ' + this.winAmount + '}');
                    };
                    GameEventResponse.className = 'gpts.services.messages.response.GameEventResponse';
                    return GameEventResponse;
                }(response.GameResponse));
                response.GameEventResponse = GameEventResponse;
            })(response = messages.response || (messages.response = {}));
        })(messages = services.messages || (services.messages = {}));
    })(services = gpts.services || (gpts.services = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var services;
    (function (services) {
        var messages;
        (function (messages) {
            var response;
            (function (response) {
                var RecoverResponse = (function (_super) {
                    __extends(RecoverResponse, _super);
                    function RecoverResponse(command, eventTimestamp, msg, complex, reason, gameIdentificationNumber, gameNumber, gameRecoveryType, winAmount, credit, qName) {
                        if (command === void 0) { command = null; }
                        if (eventTimestamp === void 0) { eventTimestamp = -1; }
                        if (msg === void 0) { msg = null; }
                        if (complex === void 0) { complex = null; }
                        if (reason === void 0) { reason = null; }
                        if (gameIdentificationNumber === void 0) { gameIdentificationNumber = NaN; }
                        if (gameNumber === void 0) { gameNumber = -1; }
                        if (gameRecoveryType === void 0) { gameRecoveryType = null; }
                        if (winAmount === void 0) { winAmount = -1; }
                        if (credit === void 0) { credit = -1; }
                        if (qName === void 0) { qName = null; }
                        var _this = _super.call(this, command, eventTimestamp, msg, complex, reason, gameIdentificationNumber, gameNumber, qName) || this;
                        _this.gameRecoveryType = gameRecoveryType;
                        _this.winAmount = winAmount;
                        _this.credit = credit;
                        return _this;
                    }
                    RecoverResponse.prototype.toString = function () {
                        var result = _super.prototype.toString.call(this);
                        return result.substr(0, result.length - 1).concat(', gameRecoveryType: ' + this.gameRecoveryType + ', winAmount: ' + this.winAmount + ', credit: ' + this.credit + '}');
                    };
                    RecoverResponse.className = 'gpts.services.messages.response.RecoverResponse';
                    return RecoverResponse;
                }(response.GameResponse));
                response.RecoverResponse = RecoverResponse;
            })(response = messages.response || (messages.response = {}));
        })(messages = services.messages || (services.messages = {}));
    })(services = gpts.services || (gpts.services = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var services;
    (function (services) {
        var messages;
        (function (messages) {
            var response;
            (function (response) {
                var ConfigResponse = (function (_super) {
                    __extends(ConfigResponse, _super);
                    function ConfigResponse(command, qName) {
                        if (command === void 0) { command = null; }
                        if (qName === void 0) { qName = null; }
                        return _super.call(this, command, qName) || this;
                    }
                    ConfigResponse.prototype.toString = function () {
                        var result = _super.prototype.toString.call(this);
                        return result.substr(0, result.length - 1).concat();
                    };
                    ConfigResponse.className = 'gpts.services.messages.response.ConfigResponse';
                    return ConfigResponse;
                }(services.Message));
                response.ConfigResponse = ConfigResponse;
            })(response = messages.response || (messages.response = {}));
        })(messages = services.messages || (services.messages = {}));
    })(services = gpts.services || (gpts.services = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Container = PIXI.Container;
    var TestHolder = (function (_super) {
        __extends(TestHolder, _super);
        function TestHolder() {
            return _super.call(this) || this;
        }
        return TestHolder;
    }(Container));
    gpts.TestHolder = TestHolder;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Text = PIXI.Text;
    var TextMetrics = PIXI.TextMetrics;
    var Position;
    (function (Position) {
        Position[Position["TOP"] = 0] = "TOP";
        Position[Position["BOTTOM"] = 1] = "BOTTOM";
        Position[Position["LEFT"] = 2] = "LEFT";
        Position[Position["RIGHT"] = 3] = "RIGHT";
    })(Position = gpts.Position || (gpts.Position = {}));
    var TextField = (function (_super) {
        __extends(TextField, _super);
        function TextField(text, style, resolution) {
            var _this = _super.call(this, text, style) || this;
            if (resolution) {
                _this.resolution = resolution;
            }
            return _this;
        }
        TextField.prototype.stretchBy = function (prop, max) {
            if (max <= 0)
                return;
            while (this[prop] < max) {
                var style = this.style;
                style.fontSize = Number(style.fontSize) + 1;
                this.style = style;
            }
            while (this[prop] > max) {
                if (Number(this.style.fontSize) < TextField.MIN_FONT_SIZE)
                    break;
                style = this.style;
                style.fontSize = Number(style.fontSize) - 1;
                this.style = style;
            }
        };
        TextField.prototype.constrain = function (w, h) {
            var ratio = this.width / this.height;
            if ((w / h) < ratio)
                this.stretchBy('width', w);
            else
                this.stretchBy('height', h);
        };
        TextField.prototype.alignTo = function (field, position) {
            var thisProps = TextMetrics.measureText(this.text, this.style);
            var fieldProps = TextMetrics.measureText(field.text, field.style);
            switch (position) {
                case Position.BOTTOM:
                    this.y = field.y + fieldProps.fontProperties.ascent - thisProps.fontProperties.ascent;
                    break;
            }
        };
        TextField.MIN_FONT_SIZE = 4;
        return TextField;
    }(Text));
    gpts.TextField = TextField;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Aspect = gamy.Aspect;
    var CurrencyTextField = (function (_super) {
        __extends(CurrencyTextField, _super);
        function CurrencyTextField(specialCurrency) {
            var _this = _super.call(this) || this;
            _this.specialCurrencyPaddingX = 4;
            _this._useCredits = false;
            _this.special_currency = specialCurrency;
            return _this;
        }
        CurrencyTextField.prototype.useCredits = function (flag) {
            this._useCredits = flag;
            this.moneyField.visible = this.currencyField.visible = !flag;
            this.creditField.visible = flag;
        };
        CurrencyTextField.prototype.setCurrency = function (value) {
            this._currency = value;
            if (this._currency == this.special_currency) {
                this.addChildren(this.moneyField, this.specialCurrencyIcon);
                this.special_currency_icon_width = this.specialCurrencyIcon.width;
                this.special_currency_icon_height = this.specialCurrencyIcon.height;
            }
            else {
                this.addChildren(this.moneyField, this.currencyField);
                this.currencyField.text = this._currency;
                if (this.creditField != undefined) {
                    this.addChild(this.creditField);
                    this.creditField.visible = false;
                }
            }
        };
        CurrencyTextField.prototype.money = function (value) {
            if (this._currency == this.special_currency) {
                this.moneyField.text = value;
                var aspect = new Aspect(this.moneyField.width + this.specialCurrencyIcon.width, Math.max(this.moneyField.height, this.specialCurrencyIcon.height));
                aspect.constrain(this.rect.width, this.rect.height);
                this.moneyField.constrain(aspect.width, aspect.height);
                var iconAspect = new Aspect(this.specialCurrencyIcon.width, this.specialCurrencyIcon.height);
                iconAspect.constrain(Math.max(this.rect.width - this.moneyField.width, this.special_currency_icon_width), Math.min(aspect.height, this.special_currency_icon_height));
                this.specialCurrencyIcon.width = iconAspect.width;
                this.specialCurrencyIcon.height = iconAspect.height;
                var totalWidth = this.moneyField.width + this.specialCurrencyIcon.width;
                this.specialCurrencyIcon.x = this.rect.x + (this.rect.width - totalWidth) / 2;
                this.specialCurrencyIcon.y = this.rect.y + (this.rect.height - this.specialCurrencyIcon.height) / 2;
                this.moneyField.x = this.specialCurrencyIcon.x + this.specialCurrencyIcon.width + this.specialCurrencyPaddingX;
                this.moneyField.y = this.rect.y + (this.rect.height - this.moneyField.height) / 2;
            }
            else {
                if (this._useCredits) {
                    this.creditField.text = value;
                    this.creditField.constrain(this.rect.width, this.rect.height);
                    this.creditField.x = this.rect.x + (this.rect.width - this.creditField.width) / 2;
                    this.creditField.y = this.rect.y + (this.rect.height - this.creditField.height) / 2;
                }
                else {
                    this.moneyField.text = value;
                    aspect = new Aspect(this.moneyField.width + this.currencyField.width, Math.max(this.moneyField.height, this.currencyField.height));
                    aspect.constrain(this.rect.width, this.rect.height);
                    this.moneyField.constrain(aspect.width, aspect.height);
                    this.currencyField.constrain(aspect.width - this.moneyField.width, aspect.height);
                    totalWidth = this.moneyField.width + this.currencyField.width;
                    var totalHeight = Math.max(this.moneyField.height, this.currencyField.height);
                    this.moneyField.x = this.rect.x + (this.rect.width - totalWidth) / 2;
                    this.moneyField.y = this.rect.y + (this.rect.height - totalHeight) / 2;
                    this.currencyField.x = this.moneyField.x + this.moneyField.width;
                    this.currencyField.alignTo(this.moneyField, gpts.Position.BOTTOM);
                }
            }
        };
        CurrencyTextField.prototype.dispose = function () {
            _super.prototype.dispose.call(this);
            this.removeChildren();
            this.moneyField = null;
            this.currencyField = null;
            this.specialCurrencyIcon = null;
            this.creditField = null;
        };
        return CurrencyTextField;
    }(gpts.Holder));
    gpts.CurrencyTextField = CurrencyTextField;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Sprite = PIXI.Sprite;
    var Container = PIXI.Container;
    var TilingSprite = PIXI.extras.TilingSprite;
    var Scale3Sprite = (function (_super) {
        __extends(Scale3Sprite, _super);
        function Scale3Sprite(width, height, left, center, right) {
            var _this = _super.call(this) || this;
            _this._width = width;
            _this._height = height;
            _this._left = new Sprite(left);
            _this._right = new Sprite(right || left);
            _this._centerSprite = new Sprite(center);
            _this.has_right = right != null;
            if (!_this.has_right)
                _this._right.scale.set(-1, 1);
            _this.addChild(_this._left);
            _this.addChild(_this._right);
            _this.setWidth(width);
            return _this;
        }
        Scale3Sprite.prototype.setWidth = function (value) {
            if (this._center) {
                this.removeChild(this._center);
                this._center.destroy(false);
                this._center = null;
            }
            this._center = new TilingSprite(this._centerSprite.texture, value - this._left.width - this._right.width, this._height);
            this._center.x = this._left.width;
            this._center.y = -0.5;
            this._right.x = this._center.x + this._center.width + (this.has_right ? 0 : this._left.width);
            this.addChild(this._center);
            this._width = value;
        };
        return Scale3Sprite;
    }(Container));
    gpts.Scale3Sprite = Scale3Sprite;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Container = PIXI.Container;
    var Scale3MovieClip = (function (_super) {
        __extends(Scale3MovieClip, _super);
        function Scale3MovieClip(frames) {
            var _this = _super.call(this) || this;
            var length = frames.length;
            for (var i = 0; i < length; i++) {
                var element = frames[i];
                _this.addChild(element.content);
                element.content.name = element.label;
                element.content.visible = i == 0;
            }
            _this.last_visible_label = frames[0].label;
            return _this;
        }
        Scale3MovieClip.prototype.gotoAndStopToLabel = function (label) {
            if (this.last_visible_label != label) {
                var lastVisible = this.getChildByName(this.last_visible_label);
                lastVisible.visible = false;
                this.last_visible_label = label;
                this.getChildByName(this.last_visible_label).visible = true;
            }
        };
        Scale3MovieClip.prototype.setWidth = function (value) {
            var length = this.children.length;
            for (var i = 0; i < length; i++) {
                var child = this.getChildAt(i);
                if (child instanceof gpts.Scale3Sprite)
                    child.setWidth(value);
            }
        };
        return Scale3MovieClip;
    }(Container));
    gpts.Scale3MovieClip = Scale3MovieClip;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var Hash = gamy.Hash;
    var Aspect = gamy.Aspect;
    var PStage = PIXI.display.Stage;
    var LayerManager = egtLibrary.LayerManager;
    var Stage = (function () {
        function Stage(options) {
            this._window = $(window);
            this._options = new Hash({
                stageWidth: 1280,
                stageHeight: 720,
                visibleWidth: 1152,
                visibleHeight: 720,
                canvasID: 'gpts'
            }).merge(options);
            this.stage_aspect = new Aspect(this._options.stageWidth, this._options.stageHeight);
            this.visible_aspect = new Aspect(this._options.visibleWidth, this._options.visibleHeight);
            PIXI.settings.PRECISION_FRAGMENT = PIXI.PRECISION.HIGH;
            this._renderer = PIXI.autoDetectRenderer(this._options.stageWidth, this._options.stageHeight, {
                antialias: MOB ? true : false,
                roundPixels: true
            });
            $('#' + this._options.canvasID).append(this._renderer.view);
            this._renderer.backgroundColor = 0x000000;
            LayerManager.stage = this._stage = new PStage();
            PIXI.renderer = this._renderer;
            this.animate();
            if (MOB) {
                var disableZoom = $("<div id='disableZoom'>");
                $("body").prepend(disableZoom);
                disableZoom.on("touchstart", this.preventDefault);
                disableZoom.on("gesturestart", this.preventDefault);
                disableZoom.on("gesturechange", this.preventDefault);
                disableZoom.on("gestureend", this.preventDefault);
            }
            this._content = $('#content');
            this._content.css({
                "width": this._options.stageWidth + 'px',
                "height": this._options.stageHeight + 'px'
            });
            var handleViewportInterval = -1;
            var handleViewportCountdown = 5;
            var that = this;
            this._window.on("resize", function (event) {
                that.onResize(event);
                if (MOB) {
                    clearInterval(handleViewportInterval);
                    handleViewportCountdown = 5;
                    handleViewportInterval = setInterval(function () {
                        that.onResize(event);
                        if (--handleViewportCountdown == 0) {
                            clearInterval(handleViewportInterval);
                        }
                    }, 100);
                }
            });
            this.onResize();
        }
        Stage.prototype.onResize = function (event) {
            this.getWindowSize();
            this.visible_aspect.constrain(this._windowWidth, this._windowHeight);
            this.stage_aspect.crop(this.visible_aspect.width, this.visible_aspect.height);
            egtLibrary.Device.scale = this.stage_aspect.width / this._options.stageWidth;
            this._content.css('transform', 'scale(' + egtLibrary.Device.scale + ')');
            var marginTop = MOB ? 0 : (-this.stage_aspect.height + this._windowHeight) / 2;
            this._content.css('margin-top', marginTop);
            this._content.css('margin-left', (-this.stage_aspect.width + this._windowWidth) / 2);
        };
        Stage.prototype.getWindowSize = function () {
            if (window.navigator.standalone) {
                this._windowWidth = this._window.width();
                this._windowHeight = this._window.height();
            }
            else {
                this._windowWidth = window.innerWidth;
                this._windowHeight = window.innerHeight;
            }
        };
        Stage.prototype.overrideAspect = function (stageWidth, stageHeight, visibleWidth, visibleHeight) {
            this.stage_aspect = new Aspect(stageWidth, stageHeight);
            this.visible_aspect = new Aspect(isNaN(visibleWidth) ? stageWidth : stageHeight, isNaN(visibleHeight) ? stageHeight : visibleHeight);
            this._options.stageWidth = stageWidth;
            this._options.stageHeight = stageHeight;
            this._renderer.resize(stageWidth, stageHeight);
            this._content.css({
                "width": stageWidth + 'px',
                "height": stageHeight + 'px'
            });
            this.onResize();
        };
        Stage.prototype.preventDefault = function (event) {
            event.preventDefault();
            event.stopPropagation();
        };
        Stage.prototype.animate = function () {
            this._renderer.render(this._stage);
            var that = this;
            requestAnimationFrame(function () {
                that.animate();
            });
        };
        Object.defineProperty(Stage.prototype, "stage", {
            get: function () {
                return this._stage;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Stage.prototype, "stageWidth", {
            get: function () {
                return this._options.stageWidth;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Stage.prototype, "stageHeight", {
            get: function () {
                return this._options.stageHeight;
            },
            enumerable: true,
            configurable: true
        });
        return Stage;
    }());
    gpts.Stage = Stage;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var Hash = gamy.Hash;
        var LoaderMax = gamy.LoaderMax;
        var trace = gamy.trace;
        var getDefinitionByName = gamy.getDefinitionByName;
        var StringTools = gamy.StringTools;
        var ArrayTools = gamy.ArrayTools;
        var GameRequest = gpts.services.messages.request.GameRequest;
        var MessagesFacade = gpts.services.MessagesFacade;
        var LoaderEvent = gamy.LoaderEvent;
        var GameProxy = (function (_super) {
            __extends(GameProxy, _super);
            function GameProxy(iData) {
                var _this = _super.call(this, String(iData.gameIdentificationNumber)) || this;
                _this.messages_facade = MessagesFacade.getInstance();
                _this._iData = new Hash(iData);
                _this._loader = LoaderMax.getLoader(_this.interests());
                return _this;
            }
            GameProxy.prototype.onRegister = function () {
                trace('Register game ' + this.proxyName);
                _super.prototype.onRegister.call(this);
                var definition = getDefinitionByName('gpts.abstract_games.' + StringTools.toPackageNameConvention(this.gameType()) + '.' + this.gameType() + 'Mediator');
                this._facade.registerMediator(new definition(this.gameType()));
                if (this._loader.content != undefined) {
                    var mediator = this._facade.retrieveMediator(this.gameType());
                    mediator.setViewComponent(this._loader.content);
                    if (ArrayTools.isEmpty(mediator.events))
                        this.sendNotification(abstract_games.GameMediator.EVENTS + this.gameType(), this._loader.content.events);
                }
                if (this._facade.gamesRecoveryList[this.proxyName] == gpts.EMessage.PROGRESS_RECOVERY) {
                    var subscribeRequest = new GameRequest(gpts.EMessage.SUBSCRIBE, this._facade.sessionKey, parseInt(this.proxyName), -1, gpts.EMessage.GAME_PACKAGE + this.gameType() + '.' + gpts.EMessage.SUBSCRIBE);
                    MessagesFacade.getInstance().send(subscribeRequest);
                    this._facade.subscribeMessagesIds.push(subscribeRequest.messageId);
                }
                else
                    this.getSettings();
            };
            GameProxy.prototype.getSettings = function () {
                if (!this._loader.content)
                    this.configureListeners();
                MessagesFacade.getInstance().send(new GameRequest(gpts.EMessage.SETTINGS, this._facade.sessionKey, parseInt(this.proxyName), -1, gpts.EMessage.GAME_PACKAGE + this.gameType() + '.' + gpts.EMessage.SETTINGS));
            };
            GameProxy.prototype.configureListeners = function (add) {
                if (add === void 0) { add = true; }
                if (add) {
                    this._loader.addEventListener(LoaderEvent.COMPLETE, this.onLoadGameInterface, this);
                    this._loader.addEventListener(LoaderEvent.FAIL, this.onErrorLoadingGameInterface, this);
                }
                else {
                    this._loader.removeEventListener(LoaderEvent.COMPLETE, this.onLoadGameInterface, this);
                    this._loader.removeEventListener(LoaderEvent.FAIL, this.onErrorLoadingGameInterface, this);
                }
            };
            GameProxy.prototype.onErrorLoadingGameInterface = function (event) {
                this._facade.removeProxy(this.proxyName);
            };
            GameProxy.prototype.onLoadGameInterface = function (event) {
                this.configureListeners(false);
                if (this._loader.content == null) {
                    this._facade.removeProxy(this.proxyName);
                    return;
                }
                this._facade.retrieveMediator(this.gameType()).setViewComponent(this._loader.content);
                try {
                    this.sendNotification(abstract_games.GameMediator.EVENTS + this.gameType(), this._loader.content.events);
                }
                catch (error) {
                    trace(gpts.ELogger.RUNTIME_ERRORS, '[GameProxy]', error.message, error.stack);
                    this._facade.removeProxy(this.proxyName);
                    return;
                }
                this.launchGame();
                window.addEventListener("orientationchange", function () { });
            };
            GameProxy.prototype.launchGame = function () {
                if (!this._subscribed) {
                    if (this._facade.gamesRecoveryList[this.proxyName] == gpts.EMessage.NO_RECOVERY)
                        MessagesFacade.getInstance().send(new GameRequest(gpts.EMessage.SUBSCRIBE, this._facade.sessionKey, parseInt(this.proxyName), -1, gpts.EMessage.GAME_PACKAGE + this.gameType() + '.' + gpts.EMessage.SUBSCRIBE));
                    else
                        MessagesFacade.getInstance().send(new GameRequest(gpts.EMessage.RECOVERY, this._facade.sessionKey, parseInt(this.proxyName), this._iData.gameNumber, gpts.EMessage.GAME_PACKAGE + this.gameType() + '.' + gpts.EMessage.RECOVERY));
                }
                else if (this._facade.retrieveMediator(this.gameType()).getViewComponent() == undefined) {
                    this._facade.retrieveMediator(this.gameType()).setViewComponent(this._loader.content);
                    this.sendNotification(abstract_games.GameMediator.EVENTS + this.gameType(), this._loader.content.events);
                }
                gpts.Router.getInstance().redirectTo((this._facade.singleGameMode ? gpts.Router.SINGLE_GAME_PAGE : gpts.Router.GAME_PAGE), {
                    gameType: this.gameType(),
                    gameIdentificationNumber: this.proxyName
                });
            };
            GameProxy.prototype.onRemove = function () {
                trace('Remove game ' + this.proxyName);
                if (this.canContinueAfterFailure && this.currentState == gpts.EMessage.FAILURE)
                    this._facade.gamesRecoveryList[this.proxyName] = gpts.EMessage.NO_RECOVERY;
                _super.prototype.onRemove.call(this);
                this.configureListeners(false);
                this._loader = null;
                MessagesFacade.getInstance().send(new GameRequest(gpts.EMessage.UNSUBSCRIBE, this._facade.sessionKey, parseInt(this.proxyName), -1, gpts.EMessage.GAME_PACKAGE + this.gameType() + '.' + gpts.EMessage.UNSUBSCRIBE));
            };
            GameProxy.prototype.interests = function () {
                return gpts.AppFacade.getInstance().interests[this.gameType()];
            };
            GameProxy.prototype.gameType = function () {
                return this._iData.gameType;
            };
            GameProxy.prototype.isVisible = function () {
                return gpts.Router.getInstance().parameters.gameType == this.gameType() && gpts.Router.getInstance().parameters.gameIdentificationNumber == this.proxyName;
            };
            GameProxy.prototype.handleTimeoutMessage = function (message) {
                if (ArrayTools.has(this._facade.subscribeMessagesIds, message.messageId)) {
                    this._facade.removeProxy(this.proxyName);
                    this._facade.gamesRecoveryList[this.proxyName] = this.canContinueAfterFailure ? gpts.EMessage.NO_RECOVERY : gpts.EMessage.FAILURE;
                }
                switch (message.command) {
                    case gpts.EMessage.SETTINGS:
                        this._facade.removeProxy(this.proxyName);
                        break;
                }
            };
            GameProxy.prototype.eventHandler = function (event) {
                throw new Error('Implement in concrete game proxy');
            };
            GameProxy.prototype.setData = function (value) {
                _super.prototype.setData.call(this, value);
                var message = this.getData();
                switch (message.command) {
                    case gpts.EMessage.SUBSCRIBE:
                        this._subscribed = message.msg == abstract_games.GameMediator.SUCCESS;
                        this._filtered = message.msg == gpts.EMessage.GAME_FILTER;
                        if (this._filtered) {
                            if (ArrayTools.has(this._facade.subscribeMessagesIds, message.messageId)) {
                                this._facade.removeProxy(this.proxyName);
                                this._facade.gamesRecoveryList[this.proxyName] = this.canContinueAfterFailure ? gpts.EMessage.NO_RECOVERY : gpts.EMessage.FAILURE;
                            }
                            else {
                                if (!this._facade.singleGameMode) {
                                    var router = gpts.Router.getInstance();
                                    router.redirectTo('homepage', { groupId: router.oldParameters.groupId });
                                }
                                this._facade.removeProxy(this.proxyName);
                            }
                            var content = LoaderMax.getContent(gpts.Main.CONTENT);
                            gpts.Alert.show(content.incorrectGIN[gpts.Router.getInstance().language]);
                        }
                        break;
                    case gpts.EMessage.SETTINGS:
                        if (message.msg != gpts.EMessage.SUCCESS) {
                            this._facade.removeProxy(this.proxyName);
                            return;
                        }
                        this._settings = message.complex;
                        if (this._loader.content == undefined)
                            this._loader.load();
                        else
                            this.launchGame();
                        break;
                }
            };
            GameProxy.prototype.supportPortrait = function () {
                return true;
            };
            Object.defineProperty(GameProxy.prototype, "settings", {
                get: function () {
                    return this._settings;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(GameProxy.prototype, "hasSettings", {
                get: function () {
                    return this._settings != null && this._loader.content != null;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(GameProxy.prototype, "subscribed", {
                get: function () {
                    return this._subscribed;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(GameProxy.prototype, "iData", {
                get: function () {
                    return this._iData;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(GameProxy.prototype, "_facade", {
                get: function () {
                    return this.facade();
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(GameProxy.prototype, "currentState", {
                get: function () {
                    return null;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(GameProxy.prototype, "canContinueAfterFailure", {
                get: function () {
                    return false;
                },
                enumerable: true,
                configurable: true
            });
            GameProxy.prototype.filtered = function () {
                return this._filtered;
            };
            return GameProxy;
        }(abstract_games.IGame));
        abstract_games.GameProxy = GameProxy;
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var services;
    (function (services) {
        var messages;
        (function (messages) {
            var request;
            (function (request) {
                var BetRequest = (function (_super) {
                    __extends(BetRequest, _super);
                    function BetRequest(command, sessionKey, gameIdentificationNumber, gameNumber, bet, qName) {
                        if (command === void 0) { command = null; }
                        if (sessionKey === void 0) { sessionKey = null; }
                        if (gameIdentificationNumber === void 0) { gameIdentificationNumber = NaN; }
                        if (gameNumber === void 0) { gameNumber = -1; }
                        if (bet === void 0) { bet = null; }
                        if (qName === void 0) { qName = null; }
                        var _this = _super.call(this, command, sessionKey, gameIdentificationNumber, gameNumber, qName) || this;
                        _this.bet = bet;
                        return _this;
                    }
                    BetRequest.prototype.toString = function () {
                        var result = _super.prototype.toString.call(this);
                        return result.substr(0, result.length - 1).concat(', bet: ' + this.bet.toString() + '}');
                    };
                    return BetRequest;
                }(request.GameRequest));
                request.BetRequest = BetRequest;
            })(request = messages.request || (messages.request = {}));
        })(messages = services.messages || (services.messages = {}));
    })(services = gpts.services || (gpts.services = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var b_h_slot;
        (function (b_h_slot) {
            var EBHSlotMessage = (function () {
                function EBHSlotMessage() {
                }
                EBHSlotMessage.IDLE = 'idle';
                EBHSlotMessage.JACKPOT = 'jackpot';
                EBHSlotMessage.SET_RESULT = 'setResult';
                EBHSlotMessage.SET_CHOICE = 'setChoice';
                return EBHSlotMessage;
            }());
            b_h_slot.EBHSlotMessage = EBHSlotMessage;
        })(b_h_slot = abstract_games.b_h_slot || (abstract_games.b_h_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var b_h_slot;
        (function (b_h_slot) {
            var GameEventResponse = gpts.services.messages.response.GameEventResponse;
            var Hash = gamy.Hash;
            var BetRequest = gpts.services.messages.request.BetRequest;
            var ArrayTools = gamy.ArrayTools;
            var BHSlotProxy = (function (_super) {
                __extends(BHSlotProxy, _super);
                function BHSlotProxy(iData) {
                    var _this = _super.call(this, BHSlotProxy.cachedData.merge(iData)) || this;
                    _this.game_number = -1;
                    _this._iData.bonusSpins = iData.bonusSpins;
                    return _this;
                }
                BHSlotProxy.prototype.eventHandler = function (event) {
                    switch (event.type) {
                        case gpts.GameEvent.HIDE:
                            BHSlotProxy.cachedData.merge(event.data);
                            this._facade.removeProxy(this.proxyName);
                            break;
                        default:
                            if (event.type == gpts.EMessage.BET) {
                                this._facade.balance -= event.bet;
                                this.sendNotification(gpts.AppFacade.UPDATE_BALANCE);
                            }
                            this.messages_facade.send(new BetRequest(gpts.EMessage.BET, this._facade.sessionKey, parseInt(this.proxyName), this.game_number, event.data, gpts.EMessage.GAME_PACKAGE + this.gameType() + '.bet.' + event.data.gameCommand));
                            break;
                    }
                };
                BHSlotProxy.prototype.handleTimeoutMessage = function (message) {
                    _super.prototype.handleTimeoutMessage.call(this, message);
                    if (!ArrayTools.has(this._facade.subscribeMessagesIds, message.messageId)) {
                        switch (message.command) {
                            case gpts.EMessage.UNSUBSCRIBE:
                                break;
                            case gpts.EMessage.SETTINGS:
                                break;
                            default:
                                this.current_state = gpts.EMessage.FAILURE;
                                this.sendNotification(this.gameType(), new GameEventResponse(gpts.EMessage.EVENT, -1, null, null, gpts.EMessage.REQUEST_TIMEOUT, null, -1, gpts.EMessage.FAILURE));
                                break;
                        }
                    }
                };
                Object.defineProperty(BHSlotProxy.prototype, "currentState", {
                    get: function () {
                        return this.current_state;
                    },
                    enumerable: true,
                    configurable: true
                });
                BHSlotProxy.prototype.setData = function (value) {
                    if (this.currentState == gpts.EMessage.FAILURE)
                        return;
                    _super.prototype.setData.call(this, value);
                    var message = this.data;
                    switch (message.command) {
                        case gpts.EMessage.SETTINGS:
                            break;
                        case gpts.EMessage.UNSUBSCRIBE:
                            break;
                        default:
                            if (message.complex && (message.complex.gameCommand == b_h_slot.EBHSlotMessage.SET_RESULT || message.complex.gameCommand == b_h_slot.EBHSlotMessage.SET_CHOICE)) {
                                this.sendNotification(this.gameType(), message);
                                return;
                            }
                            if (this._facade.gamesRecoveryList[this.proxyName] == gpts.EMessage.PROGRESS_RECOVERY) {
                                if (message.command == gpts.EMessage.SUBSCRIBE) {
                                    this._facade.gamesRecoveryList[this.proxyName] = gpts.EMessage.NO_RECOVERY;
                                    this.subscribe_response = message;
                                }
                            }
                            if (message.command == gpts.EMessage.BET) {
                                this._facade.balance = message.balance;
                                if (this.data.bonusSpins != null) {
                                    var loginBonusSpinsData = this._facade.gamesList[this._iData.gameIdentificationNumber].bonusSpins;
                                    loginBonusSpinsData.remainingBonusSpins = this.data.bonusSpins.remainingBonusSpins;
                                    loginBonusSpinsData.statusCode = this.data.bonusSpins.statusCode;
                                    if (this.data.bonusSpins.statusCode == gpts.EMessage.BONUS_ERROR) {
                                        this._facade.gamesWithBonusesList.forEach(function (key, value) {
                                            value.bonusSpins.remainingBonusSpins = 0;
                                        });
                                    }
                                    gpts.AppFacade.getInstance().dispatchEvent(new gpts.GameEvent(gpts.GameEvent.BONUS_SPINS_CHANGED, this.proxyName));
                                }
                            }
                            if (message.command != gpts.EMessage.EVENT) {
                                this.current_state = (message.command == gpts.EMessage.SUBSCRIBE && message.msg == gpts.EMessage.SUCCESS) ? message.complex.currentState.state : message.state;
                                this.game_number = message.gameNumber;
                            }
                            this.sendNotification(this.gameType(), message);
                            break;
                    }
                };
                Object.defineProperty(BHSlotProxy.prototype, "subscribeResponse", {
                    get: function () {
                        return this.subscribe_response;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(BHSlotProxy.prototype, "canContinueAfterFailure", {
                    get: function () {
                        return true;
                    },
                    enumerable: true,
                    configurable: true
                });
                BHSlotProxy.cachedData = new Hash();
                return BHSlotProxy;
            }(abstract_games.GameProxy));
            b_h_slot.BHSlotProxy = BHSlotProxy;
        })(b_h_slot = abstract_games.b_h_slot || (abstract_games.b_h_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var a_r_j_slot;
        (function (a_r_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var ARJSlotProxy = (function (_super) {
                __extends(ARJSlotProxy, _super);
                function ARJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return ARJSlotProxy;
            }(BHSlotProxy));
            a_r_j_slot.ARJSlotProxy = ARJSlotProxy;
        })(a_r_j_slot = abstract_games.a_r_j_slot || (abstract_games.a_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_a_r_j_slot;
        (function (f_a_r_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FARJSlotProxy = (function (_super) {
                __extends(FARJSlotProxy, _super);
                function FARJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FARJSlotProxy;
            }(BHSlotProxy));
            f_a_r_j_slot.FARJSlotProxy = FARJSlotProxy;
        })(f_a_r_j_slot = abstract_games.f_a_r_j_slot || (abstract_games.f_a_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var b_h_slot;
        (function (b_h_slot) {
            var BHSlotMediator = (function (_super) {
                __extends(BHSlotMediator, _super);
                function BHSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                BHSlotMediator.prototype.handleNotification = function (notification) {
                    _super.prototype.handleNotification.call(this, notification);
                    var gameProxy = this._facade.retrieveProxy(gpts.Router.getInstance().parameters.gameIdentificationNumber);
                    var data;
                    switch (notification.getName()) {
                        case abstract_games.GameMediator.SHOW + this.mediatorName:
                            data = new abstract_games.GameData(this._facade.balance, gpts.Router.getInstance().language, gameProxy.settings, null, null, !this.messages_facade.connected, gameProxy.iData, this._facade.currency, this._facade.languages, this._facade.currencyISO);
                            data.showRtp = this._facade.showRtp;
                            data.autoplayLimit = this._facade.autoplayLimit;
                            data.minimumSpinTime = this._facade.minimumSpinTime;
                            data.sendTotalsInfo = this._facade.sendTotalsInfo;
                            data.doesOperatorAddWinToBalanceDuringBonusSpins = this._facade.doesOperatorAddWinToBalanceDuringBonusSpins;
                            data.totalBet = this._facade.totalBet;
                            data.totalWin = this._facade.totalWin;
                            if (gameProxy.subscribeResponse)
                                data.merge(gameProxy.subscribeResponse);
                            data.command = abstract_games.GameMediator.SHOW;
                            break;
                    }
                    if ((gameProxy instanceof b_h_slot.BHSlotProxy) && notification.getName() == gameProxy.gameType()) {
                        data = new abstract_games.GameData(this._facade.balance);
                        data.merge(notification.getBody());
                    }
                    if (data)
                        abstract_games.DataHandler.set(this.viewComponent, data);
                };
                return BHSlotMediator;
            }(abstract_games.GameMediator));
            b_h_slot.BHSlotMediator = BHSlotMediator;
        })(b_h_slot = abstract_games.b_h_slot || (abstract_games.b_h_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_a_r_j_slot;
        (function (f_a_r_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FARJSlotMediator = (function (_super) {
                __extends(FARJSlotMediator, _super);
                function FARJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FARJSlotMediator;
            }(BHSlotMediator));
            f_a_r_j_slot.FARJSlotMediator = FARJSlotMediator;
        })(f_a_r_j_slot = abstract_games.f_a_r_j_slot || (abstract_games.f_a_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var a_r_j_slot;
        (function (a_r_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var ARJSlotMediator = (function (_super) {
                __extends(ARJSlotMediator, _super);
                function ARJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return ARJSlotMediator;
            }(BHSlotMediator));
            a_r_j_slot.ARJSlotMediator = ARJSlotMediator;
        })(a_r_j_slot = abstract_games.a_r_j_slot || (abstract_games.a_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var c_d_j_slot;
        (function (c_d_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var CDJSlotProxy = (function (_super) {
                __extends(CDJSlotProxy, _super);
                function CDJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return CDJSlotProxy;
            }(BHSlotProxy));
            c_d_j_slot.CDJSlotProxy = CDJSlotProxy;
        })(c_d_j_slot = abstract_games.c_d_j_slot || (abstract_games.c_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var c_d_j_slot;
        (function (c_d_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var CDJSlotMediator = (function (_super) {
                __extends(CDJSlotMediator, _super);
                function CDJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return CDJSlotMediator;
            }(BHSlotMediator));
            c_d_j_slot.CDJSlotMediator = CDJSlotMediator;
        })(c_d_j_slot = abstract_games.c_d_j_slot || (abstract_games.c_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var b_h_j_slot;
        (function (b_h_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var BHJSlotMediator = (function (_super) {
                __extends(BHJSlotMediator, _super);
                function BHJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return BHJSlotMediator;
            }(BHSlotMediator));
            b_h_j_slot.BHJSlotMediator = BHJSlotMediator;
        })(b_h_j_slot = abstract_games.b_h_j_slot || (abstract_games.b_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var b_h_j_slot;
        (function (b_h_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var BHJSlotProxy = (function (_super) {
                __extends(BHJSlotProxy, _super);
                function BHJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return BHJSlotProxy;
            }(BHSlotProxy));
            b_h_j_slot.BHJSlotProxy = BHJSlotProxy;
        })(b_h_j_slot = abstract_games.b_h_j_slot || (abstract_games.b_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var b_h_s_j_slot;
        (function (b_h_s_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var BHSJSlotMediator = (function (_super) {
                __extends(BHSJSlotMediator, _super);
                function BHSJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return BHSJSlotMediator;
            }(BHSlotMediator));
            b_h_s_j_slot.BHSJSlotMediator = BHSJSlotMediator;
        })(b_h_s_j_slot = abstract_games.b_h_s_j_slot || (abstract_games.b_h_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var b_h_s_j_slot;
        (function (b_h_s_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var BHSJSlotProxy = (function (_super) {
                __extends(BHSJSlotProxy, _super);
                function BHSJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return BHSJSlotProxy;
            }(BHSlotProxy));
            b_h_s_j_slot.BHSJSlotProxy = BHSJSlotProxy;
        })(b_h_s_j_slot = abstract_games.b_h_s_j_slot || (abstract_games.b_h_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var LoaderMax = gamy.LoaderMax;
    var StringTools = gamy.StringTools;
    var log = gamy.log;
    var ArrayTools = gamy.ArrayTools;
    var Capabilities = gamy.Capabilities;
    var EVENT_TYPE = gamy.EVENT_TYPE;
    var Alert = (function () {
        function Alert() {
            throw new Error('static class');
        }
        Alert.init = function () {
            if (!Alert._initialized) {
                Alert._initialized = true;
                Alert.TYPE_LABELS_ARRAY[PopUpType.OK] = ['okLabel'];
                Alert.TYPE_LABELS_ARRAY[PopUpType.OK_EXIT] = ['exitLabel', 'okLabel'];
                Alert.TYPE_LABELS_ARRAY[PopUpType.EXIT_RELOAD] = ['reloadLabel', 'exitLabel'];
                Alert._container = $('.alert');
                Alert._container.hide();
            }
        };
        Alert.overwriteCSSByMini = function () {
            var popup = $('.popup');
            popup.addClass('popup-mini');
            var button = $('.buttons');
            button.addClass('buttons-mini');
            var label = $('.label');
            label.addClass('label-mini');
        };
        Alert.show = function (text, type, options) {
            if (type === void 0) { type = 0; }
            var contentPopup = LoaderMax.getContent(gpts.Main.CONTENT).popup;
            var popupLayoutHTML = MINI ? contentPopup.layoutMini : contentPopup.layout;
            Alert._container.append(StringTools.renderTemplate(popupLayoutHTML, { id: 'popup-' + (++Alert._counter) }));
            if (Alert._counter > 0)
                Alert._container.show();
            $('#popup-' + Alert._counter + ' .label').append(text);
            if (MINI)
                Alert.overwriteCSSByMini();
            var buttonContainer = $('#popup-' + Alert._counter + ' .buttons');
            var buttonLabels = Alert.TYPE_LABELS_ARRAY[type];
            var length = buttonLabels.length;
            for (var i = 0; i < length; i++)
                buttonContainer.append('<button>' + LoaderMax.getContent(gpts.Main.CONTENT).popup[buttonLabels[i]][gpts.Router.getInstance().language] + '</button>');
            buttonContainer.on(Capabilities.eventType(EVENT_TYPE.UP), function (event) {
                var target = event.target;
                console.log(target);
                if (target.tagName == 'BUTTON') {
                    log(true, target.parentNode.parentNode.id, ArrayTools.htmlCollectionToArray(target.parentNode.children).indexOf(target));
                    var i_1 = ArrayTools.htmlCollectionToArray(target.parentNode.children).indexOf(target);
                    var funcName = buttonLabels[i_1] + 'Callback';
                    if (options && options[funcName])
                        options[funcName].call(null);
                    $(target).parent().parent().remove();
                    buttonContainer.off(Capabilities.eventType(EVENT_TYPE.UP));
                    Alert._counter--;
                    if (Alert._counter == 0)
                        Alert._container.hide();
                }
            });
        };
        Alert.TYPE_LABELS_ARRAY = [];
        Alert._initialized = false;
        Alert._counter = 0;
        return Alert;
    }());
    gpts.Alert = Alert;
    var PopUpType;
    (function (PopUpType) {
        PopUpType[PopUpType["OK"] = 0] = "OK";
        PopUpType[PopUpType["OK_EXIT"] = 1] = "OK_EXIT";
        PopUpType[PopUpType["EXIT_RELOAD"] = 2] = "EXIT_RELOAD";
    })(PopUpType = gpts.PopUpType || (gpts.PopUpType = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var r_o_r_j_slot;
        (function (r_o_r_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var RORJSlotProxy = (function (_super) {
                __extends(RORJSlotProxy, _super);
                function RORJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return RORJSlotProxy;
            }(BHSlotProxy));
            r_o_r_j_slot.RORJSlotProxy = RORJSlotProxy;
        })(r_o_r_j_slot = abstract_games.r_o_r_j_slot || (abstract_games.r_o_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var r_o_r_j_slot;
        (function (r_o_r_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var RORJSlotMediator = (function (_super) {
                __extends(RORJSlotMediator, _super);
                function RORJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return RORJSlotMediator;
            }(BHSlotMediator));
            r_o_r_j_slot.RORJSlotMediator = RORJSlotMediator;
        })(r_o_r_j_slot = abstract_games.r_o_r_j_slot || (abstract_games.r_o_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var r_o_r_e_q_slot;
        (function (r_o_r_e_q_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var ROREQSlotProxy = (function (_super) {
                __extends(ROREQSlotProxy, _super);
                function ROREQSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return ROREQSlotProxy;
            }(BHSlotProxy));
            r_o_r_e_q_slot.ROREQSlotProxy = ROREQSlotProxy;
        })(r_o_r_e_q_slot = abstract_games.r_o_r_e_q_slot || (abstract_games.r_o_r_e_q_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var r_o_r_e_q_slot;
        (function (r_o_r_e_q_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var ROREQSlotMediator = (function (_super) {
                __extends(ROREQSlotMediator, _super);
                function ROREQSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return ROREQSlotMediator;
            }(BHSlotMediator));
            r_o_r_e_q_slot.ROREQSlotMediator = ROREQSlotMediator;
        })(r_o_r_e_q_slot = abstract_games.r_o_r_e_q_slot || (abstract_games.r_o_r_e_q_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var e_p_j_slot;
        (function (e_p_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var EPJSlotProxy = (function (_super) {
                __extends(EPJSlotProxy, _super);
                function EPJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return EPJSlotProxy;
            }(BHSlotProxy));
            e_p_j_slot.EPJSlotProxy = EPJSlotProxy;
        })(e_p_j_slot = abstract_games.e_p_j_slot || (abstract_games.e_p_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var e_p_j_slot;
        (function (e_p_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var EPJSlotMediator = (function (_super) {
                __extends(EPJSlotMediator, _super);
                function EPJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return EPJSlotMediator;
            }(BHSlotMediator));
            e_p_j_slot.EPJSlotMediator = EPJSlotMediator;
        })(e_p_j_slot = abstract_games.e_p_j_slot || (abstract_games.e_p_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_h_j_slot;
        (function (f_h_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FHJSlotMediator = (function (_super) {
                __extends(FHJSlotMediator, _super);
                function FHJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FHJSlotMediator;
            }(BHSlotMediator));
            f_h_j_slot.FHJSlotMediator = FHJSlotMediator;
        })(f_h_j_slot = abstract_games.f_h_j_slot || (abstract_games.f_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_h_j_slot;
        (function (f_h_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FHJSlotProxy = (function (_super) {
                __extends(FHJSlotProxy, _super);
                function FHJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FHJSlotProxy;
            }(BHSlotProxy));
            f_h_j_slot.FHJSlotProxy = FHJSlotProxy;
        })(f_h_j_slot = abstract_games.f_h_j_slot || (abstract_games.f_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_d_h_j_slot;
        (function (f_d_h_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FDHJSlotMediator = (function (_super) {
                __extends(FDHJSlotMediator, _super);
                function FDHJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FDHJSlotMediator;
            }(BHSlotMediator));
            f_d_h_j_slot.FDHJSlotMediator = FDHJSlotMediator;
        })(f_d_h_j_slot = abstract_games.f_d_h_j_slot || (abstract_games.f_d_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_d_h_j_slot;
        (function (f_d_h_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FDHJSlotProxy = (function (_super) {
                __extends(FDHJSlotProxy, _super);
                function FDHJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FDHJSlotProxy;
            }(BHSlotProxy));
            f_d_h_j_slot.FDHJSlotProxy = FDHJSlotProxy;
        })(f_d_h_j_slot = abstract_games.f_d_h_j_slot || (abstract_games.f_d_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_s_h_j_slot;
        (function (t_s_h_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var TSHJSlotProxy = (function (_super) {
                __extends(TSHJSlotProxy, _super);
                function TSHJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return TSHJSlotProxy;
            }(BHSlotProxy));
            t_s_h_j_slot.TSHJSlotProxy = TSHJSlotProxy;
        })(t_s_h_j_slot = abstract_games.t_s_h_j_slot || (abstract_games.t_s_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_s_h_j_slot;
        (function (t_s_h_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var TSHJSlotMediator = (function (_super) {
                __extends(TSHJSlotMediator, _super);
                function TSHJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return TSHJSlotMediator;
            }(BHSlotMediator));
            t_s_h_j_slot.TSHJSlotMediator = TSHJSlotMediator;
        })(t_s_h_j_slot = abstract_games.t_s_h_j_slot || (abstract_games.t_s_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var u_h_j_slot;
        (function (u_h_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var UHJSlotMediator = (function (_super) {
                __extends(UHJSlotMediator, _super);
                function UHJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return UHJSlotMediator;
            }(BHSlotMediator));
            u_h_j_slot.UHJSlotMediator = UHJSlotMediator;
        })(u_h_j_slot = abstract_games.u_h_j_slot || (abstract_games.u_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var u_h_j_slot;
        (function (u_h_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var UHJSlotProxy = (function (_super) {
                __extends(UHJSlotProxy, _super);
                function UHJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return UHJSlotProxy;
            }(BHSlotProxy));
            u_h_j_slot.UHJSlotProxy = UHJSlotProxy;
        })(u_h_j_slot = abstract_games.u_h_j_slot || (abstract_games.u_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_k_j_slot;
        (function (f_k_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FKJSlotProxy = (function (_super) {
                __extends(FKJSlotProxy, _super);
                function FKJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FKJSlotProxy;
            }(BHSlotProxy));
            f_k_j_slot.FKJSlotProxy = FKJSlotProxy;
        })(f_k_j_slot = abstract_games.f_k_j_slot || (abstract_games.f_k_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_k_j_slot;
        (function (f_k_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FKJSlotMediator = (function (_super) {
                __extends(FKJSlotMediator, _super);
                function FKJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FKJSlotMediator;
            }(BHSlotMediator));
            f_k_j_slot.FKJSlotMediator = FKJSlotMediator;
        })(f_k_j_slot = abstract_games.f_k_j_slot || (abstract_games.f_k_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var z_w_j_slot;
        (function (z_w_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var ZWJSlotProxy = (function (_super) {
                __extends(ZWJSlotProxy, _super);
                function ZWJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return ZWJSlotProxy;
            }(BHSlotProxy));
            z_w_j_slot.ZWJSlotProxy = ZWJSlotProxy;
        })(z_w_j_slot = abstract_games.z_w_j_slot || (abstract_games.z_w_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var z_w_j_slot;
        (function (z_w_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var ZWJSlotMediator = (function (_super) {
                __extends(ZWJSlotMediator, _super);
                function ZWJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return ZWJSlotMediator;
            }(BHSlotMediator));
            z_w_j_slot.ZWJSlotMediator = ZWJSlotMediator;
        })(z_w_j_slot = abstract_games.z_w_j_slot || (abstract_games.z_w_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var s_c_j_slot;
        (function (s_c_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var SCJSlotProxy = (function (_super) {
                __extends(SCJSlotProxy, _super);
                function SCJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return SCJSlotProxy;
            }(BHSlotProxy));
            s_c_j_slot.SCJSlotProxy = SCJSlotProxy;
        })(s_c_j_slot = abstract_games.s_c_j_slot || (abstract_games.s_c_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var s_c_j_slot;
        (function (s_c_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var SCJSlotMediator = (function (_super) {
                __extends(SCJSlotMediator, _super);
                function SCJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return SCJSlotMediator;
            }(BHSlotMediator));
            s_c_j_slot.SCJSlotMediator = SCJSlotMediator;
        })(s_c_j_slot = abstract_games.s_c_j_slot || (abstract_games.s_c_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_s_h_j_slot;
        (function (f_s_h_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FSHJSlotProxy = (function (_super) {
                __extends(FSHJSlotProxy, _super);
                function FSHJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FSHJSlotProxy;
            }(BHSlotProxy));
            f_s_h_j_slot.FSHJSlotProxy = FSHJSlotProxy;
        })(f_s_h_j_slot = abstract_games.f_s_h_j_slot || (abstract_games.f_s_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_s_h_j_slot;
        (function (f_s_h_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FSHJSlotMediator = (function (_super) {
                __extends(FSHJSlotMediator, _super);
                function FSHJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FSHJSlotMediator;
            }(BHSlotMediator));
            f_s_h_j_slot.FSHJSlotMediator = FSHJSlotMediator;
        })(f_s_h_j_slot = abstract_games.f_s_h_j_slot || (abstract_games.f_s_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var n_d_j_slot;
        (function (n_d_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var NDJSlotMediator = (function (_super) {
                __extends(NDJSlotMediator, _super);
                function NDJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return NDJSlotMediator;
            }(BHSlotMediator));
            n_d_j_slot.NDJSlotMediator = NDJSlotMediator;
        })(n_d_j_slot = abstract_games.n_d_j_slot || (abstract_games.n_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var n_d_j_slot;
        (function (n_d_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var NDJSlotProxy = (function (_super) {
                __extends(NDJSlotProxy, _super);
                function NDJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return NDJSlotProxy;
            }(BHSlotProxy));
            n_d_j_slot.NDJSlotProxy = NDJSlotProxy;
        })(n_d_j_slot = abstract_games.n_d_j_slot || (abstract_games.n_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var b_d_j_slot;
        (function (b_d_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var BDJSlotMediator = (function (_super) {
                __extends(BDJSlotMediator, _super);
                function BDJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return BDJSlotMediator;
            }(BHSlotMediator));
            b_d_j_slot.BDJSlotMediator = BDJSlotMediator;
        })(b_d_j_slot = abstract_games.b_d_j_slot || (abstract_games.b_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var b_d_j_slot;
        (function (b_d_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var BDJSlotProxy = (function (_super) {
                __extends(BDJSlotProxy, _super);
                function BDJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return BDJSlotProxy;
            }(BHSlotProxy));
            b_d_j_slot.BDJSlotProxy = BDJSlotProxy;
        })(b_d_j_slot = abstract_games.b_d_j_slot || (abstract_games.b_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var a_o_t_j_slot;
        (function (a_o_t_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var AOTJSlotMediator = (function (_super) {
                __extends(AOTJSlotMediator, _super);
                function AOTJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return AOTJSlotMediator;
            }(BHSlotMediator));
            a_o_t_j_slot.AOTJSlotMediator = AOTJSlotMediator;
        })(a_o_t_j_slot = abstract_games.a_o_t_j_slot || (abstract_games.a_o_t_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var a_o_t_j_slot;
        (function (a_o_t_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var AOTJSlotProxy = (function (_super) {
                __extends(AOTJSlotProxy, _super);
                function AOTJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return AOTJSlotProxy;
            }(BHSlotProxy));
            a_o_t_j_slot.AOTJSlotProxy = AOTJSlotProxy;
        })(a_o_t_j_slot = abstract_games.a_o_t_j_slot || (abstract_games.a_o_t_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var r_s_j_slot;
        (function (r_s_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var RSJSlotMediator = (function (_super) {
                __extends(RSJSlotMediator, _super);
                function RSJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return RSJSlotMediator;
            }(BHSlotMediator));
            r_s_j_slot.RSJSlotMediator = RSJSlotMediator;
        })(r_s_j_slot = abstract_games.r_s_j_slot || (abstract_games.r_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var r_s_j_slot;
        (function (r_s_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var RSJSlotProxy = (function (_super) {
                __extends(RSJSlotProxy, _super);
                function RSJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return RSJSlotProxy;
            }(BHSlotProxy));
            r_s_j_slot.RSJSlotProxy = RSJSlotProxy;
        })(r_s_j_slot = abstract_games.r_s_j_slot || (abstract_games.r_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var a_a_j_slot;
        (function (a_a_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var AAJSlotProxy = (function (_super) {
                __extends(AAJSlotProxy, _super);
                function AAJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return AAJSlotProxy;
            }(BHSlotProxy));
            a_a_j_slot.AAJSlotProxy = AAJSlotProxy;
        })(a_a_j_slot = abstract_games.a_a_j_slot || (abstract_games.a_a_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var a_a_j_slot;
        (function (a_a_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var AAJSlotMediator = (function (_super) {
                __extends(AAJSlotMediator, _super);
                function AAJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return AAJSlotMediator;
            }(BHSlotMediator));
            a_a_j_slot.AAJSlotMediator = AAJSlotMediator;
        })(a_a_j_slot = abstract_games.a_a_j_slot || (abstract_games.a_a_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var b_o_m_j_slot;
        (function (b_o_m_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var BOMJSlotProxy = (function (_super) {
                __extends(BOMJSlotProxy, _super);
                function BOMJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return BOMJSlotProxy;
            }(BHSlotProxy));
            b_o_m_j_slot.BOMJSlotProxy = BOMJSlotProxy;
        })(b_o_m_j_slot = abstract_games.b_o_m_j_slot || (abstract_games.b_o_m_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var b_o_m_j_slot;
        (function (b_o_m_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var BOMJSlotMediator = (function (_super) {
                __extends(BOMJSlotMediator, _super);
                function BOMJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return BOMJSlotMediator;
            }(BHSlotMediator));
            b_o_m_j_slot.BOMJSlotMediator = BOMJSlotMediator;
        })(b_o_m_j_slot = abstract_games.b_o_m_j_slot || (abstract_games.b_o_m_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var c_m_j_slot;
        (function (c_m_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var CMJSlotProxy = (function (_super) {
                __extends(CMJSlotProxy, _super);
                function CMJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return CMJSlotProxy;
            }(BHSlotProxy));
            c_m_j_slot.CMJSlotProxy = CMJSlotProxy;
        })(c_m_j_slot = abstract_games.c_m_j_slot || (abstract_games.c_m_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var c_m_j_slot;
        (function (c_m_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var CMJSlotMediator = (function (_super) {
                __extends(CMJSlotMediator, _super);
                function CMJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return CMJSlotMediator;
            }(BHSlotMediator));
            c_m_j_slot.CMJSlotMediator = CMJSlotMediator;
        })(c_m_j_slot = abstract_games.c_m_j_slot || (abstract_games.c_m_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var b_h_t_j_slot;
        (function (b_h_t_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var BHTJSlotProxy = (function (_super) {
                __extends(BHTJSlotProxy, _super);
                function BHTJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return BHTJSlotProxy;
            }(BHSlotProxy));
            b_h_t_j_slot.BHTJSlotProxy = BHTJSlotProxy;
        })(b_h_t_j_slot = abstract_games.b_h_t_j_slot || (abstract_games.b_h_t_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var b_h_t_j_slot;
        (function (b_h_t_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var BHTJSlotMediator = (function (_super) {
                __extends(BHTJSlotMediator, _super);
                function BHTJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return BHTJSlotMediator;
            }(BHSlotMediator));
            b_h_t_j_slot.BHTJSlotMediator = BHTJSlotMediator;
        })(b_h_t_j_slot = abstract_games.b_h_t_j_slot || (abstract_games.b_h_t_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var k_g_j_slot;
        (function (k_g_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var KGJSlotProxy = (function (_super) {
                __extends(KGJSlotProxy, _super);
                function KGJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return KGJSlotProxy;
            }(BHSlotProxy));
            k_g_j_slot.KGJSlotProxy = KGJSlotProxy;
        })(k_g_j_slot = abstract_games.k_g_j_slot || (abstract_games.k_g_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var k_g_j_slot;
        (function (k_g_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var KGJSlotMediator = (function (_super) {
                __extends(KGJSlotMediator, _super);
                function KGJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return KGJSlotMediator;
            }(BHSlotMediator));
            k_g_j_slot.KGJSlotMediator = KGJSlotMediator;
        })(k_g_j_slot = abstract_games.k_g_j_slot || (abstract_games.k_g_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var h_c_j_slot;
        (function (h_c_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var HCJSlotProxy = (function (_super) {
                __extends(HCJSlotProxy, _super);
                function HCJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return HCJSlotProxy;
            }(BHSlotProxy));
            h_c_j_slot.HCJSlotProxy = HCJSlotProxy;
        })(h_c_j_slot = abstract_games.h_c_j_slot || (abstract_games.h_c_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var h_c_j_slot;
        (function (h_c_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var HCJSlotMediator = (function (_super) {
                __extends(HCJSlotMediator, _super);
                function HCJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return HCJSlotMediator;
            }(BHSlotMediator));
            h_c_j_slot.HCJSlotMediator = HCJSlotMediator;
        })(h_c_j_slot = abstract_games.h_c_j_slot || (abstract_games.h_c_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var c_h_j_slot;
        (function (c_h_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var CHJSlotMediator = (function (_super) {
                __extends(CHJSlotMediator, _super);
                function CHJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return CHJSlotMediator;
            }(BHSlotMediator));
            c_h_j_slot.CHJSlotMediator = CHJSlotMediator;
        })(c_h_j_slot = abstract_games.c_h_j_slot || (abstract_games.c_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var c_h_j_slot;
        (function (c_h_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var CHJSlotProxy = (function (_super) {
                __extends(CHJSlotProxy, _super);
                function CHJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return CHJSlotProxy;
            }(BHSlotProxy));
            c_h_j_slot.CHJSlotProxy = CHJSlotProxy;
        })(c_h_j_slot = abstract_games.c_h_j_slot || (abstract_games.c_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var s_t_j_slot;
        (function (s_t_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var STJSlotProxy = (function (_super) {
                __extends(STJSlotProxy, _super);
                function STJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return STJSlotProxy;
            }(BHSlotProxy));
            s_t_j_slot.STJSlotProxy = STJSlotProxy;
        })(s_t_j_slot = abstract_games.s_t_j_slot || (abstract_games.s_t_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var s_t_j_slot;
        (function (s_t_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var STJSlotMediator = (function (_super) {
                __extends(STJSlotMediator, _super);
                function STJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return STJSlotMediator;
            }(BHSlotMediator));
            s_t_j_slot.STJSlotMediator = STJSlotMediator;
        })(s_t_j_slot = abstract_games.s_t_j_slot || (abstract_games.s_t_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_d_j_slot;
        (function (t_d_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var TDJSlotProxy = (function (_super) {
                __extends(TDJSlotProxy, _super);
                function TDJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return TDJSlotProxy;
            }(BHSlotProxy));
            t_d_j_slot.TDJSlotProxy = TDJSlotProxy;
        })(t_d_j_slot = abstract_games.t_d_j_slot || (abstract_games.t_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_d_j_slot;
        (function (t_d_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var TDJSlotMediator = (function (_super) {
                __extends(TDJSlotMediator, _super);
                function TDJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return TDJSlotMediator;
            }(BHSlotMediator));
            t_d_j_slot.TDJSlotMediator = TDJSlotMediator;
        })(t_d_j_slot = abstract_games.t_d_j_slot || (abstract_games.t_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var a_b_j_slot;
        (function (a_b_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var ABJSlotProxy = (function (_super) {
                __extends(ABJSlotProxy, _super);
                function ABJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return ABJSlotProxy;
            }(BHSlotProxy));
            a_b_j_slot.ABJSlotProxy = ABJSlotProxy;
        })(a_b_j_slot = abstract_games.a_b_j_slot || (abstract_games.a_b_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var a_b_j_slot;
        (function (a_b_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var ABJSlotMediator = (function (_super) {
                __extends(ABJSlotMediator, _super);
                function ABJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return ABJSlotMediator;
            }(BHSlotMediator));
            a_b_j_slot.ABJSlotMediator = ABJSlotMediator;
        })(a_b_j_slot = abstract_games.a_b_j_slot || (abstract_games.a_b_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var e_h_j_slot;
        (function (e_h_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var EHJSlotProxy = (function (_super) {
                __extends(EHJSlotProxy, _super);
                function EHJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return EHJSlotProxy;
            }(BHSlotProxy));
            e_h_j_slot.EHJSlotProxy = EHJSlotProxy;
        })(e_h_j_slot = abstract_games.e_h_j_slot || (abstract_games.e_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var e_h_j_slot;
        (function (e_h_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var EHJSlotMediator = (function (_super) {
                __extends(EHJSlotMediator, _super);
                function EHJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return EHJSlotMediator;
            }(BHSlotMediator));
            e_h_j_slot.EHJSlotMediator = EHJSlotMediator;
        })(e_h_j_slot = abstract_games.e_h_j_slot || (abstract_games.e_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var l_h_j_slot;
        (function (l_h_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var LHJSlotProxy = (function (_super) {
                __extends(LHJSlotProxy, _super);
                function LHJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return LHJSlotProxy;
            }(BHSlotProxy));
            l_h_j_slot.LHJSlotProxy = LHJSlotProxy;
        })(l_h_j_slot = abstract_games.l_h_j_slot || (abstract_games.l_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var l_h_j_slot;
        (function (l_h_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var LHJSlotMediator = (function (_super) {
                __extends(LHJSlotMediator, _super);
                function LHJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return LHJSlotMediator;
            }(BHSlotMediator));
            l_h_j_slot.LHJSlotMediator = LHJSlotMediator;
        })(l_h_j_slot = abstract_games.l_h_j_slot || (abstract_games.l_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var s_p_j_slot;
        (function (s_p_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var SPJSlotProxy = (function (_super) {
                __extends(SPJSlotProxy, _super);
                function SPJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return SPJSlotProxy;
            }(BHSlotProxy));
            s_p_j_slot.SPJSlotProxy = SPJSlotProxy;
        })(s_p_j_slot = abstract_games.s_p_j_slot || (abstract_games.s_p_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var s_p_j_slot;
        (function (s_p_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var SPJSlotMediator = (function (_super) {
                __extends(SPJSlotMediator, _super);
                function SPJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return SPJSlotMediator;
            }(BHSlotMediator));
            s_p_j_slot.SPJSlotMediator = SPJSlotMediator;
        })(s_p_j_slot = abstract_games.s_p_j_slot || (abstract_games.s_p_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var c_b_j_slot;
        (function (c_b_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var CBJSlotProxy = (function (_super) {
                __extends(CBJSlotProxy, _super);
                function CBJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return CBJSlotProxy;
            }(BHSlotProxy));
            c_b_j_slot.CBJSlotProxy = CBJSlotProxy;
        })(c_b_j_slot = abstract_games.c_b_j_slot || (abstract_games.c_b_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var c_b_j_slot;
        (function (c_b_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var CBJSlotMediator = (function (_super) {
                __extends(CBJSlotMediator, _super);
                function CBJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return CBJSlotMediator;
            }(BHSlotMediator));
            c_b_j_slot.CBJSlotMediator = CBJSlotMediator;
        })(c_b_j_slot = abstract_games.c_b_j_slot || (abstract_games.c_b_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var b_r_d_j_slot;
        (function (b_r_d_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var BRDJSlotProxy = (function (_super) {
                __extends(BRDJSlotProxy, _super);
                function BRDJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return BRDJSlotProxy;
            }(BHSlotProxy));
            b_r_d_j_slot.BRDJSlotProxy = BRDJSlotProxy;
        })(b_r_d_j_slot = abstract_games.b_r_d_j_slot || (abstract_games.b_r_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var b_r_d_j_slot;
        (function (b_r_d_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var BRDJSlotMediator = (function (_super) {
                __extends(BRDJSlotMediator, _super);
                function BRDJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return BRDJSlotMediator;
            }(BHSlotMediator));
            b_r_d_j_slot.BRDJSlotMediator = BRDJSlotMediator;
        })(b_r_d_j_slot = abstract_games.b_r_d_j_slot || (abstract_games.b_r_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var s_h_j_slot;
        (function (s_h_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var SHJSlotProxy = (function (_super) {
                __extends(SHJSlotProxy, _super);
                function SHJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return SHJSlotProxy;
            }(BHSlotProxy));
            s_h_j_slot.SHJSlotProxy = SHJSlotProxy;
        })(s_h_j_slot = abstract_games.s_h_j_slot || (abstract_games.s_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var s_h_j_slot;
        (function (s_h_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var SHJSlotMediator = (function (_super) {
                __extends(SHJSlotMediator, _super);
                function SHJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return SHJSlotMediator;
            }(BHSlotMediator));
            s_h_j_slot.SHJSlotMediator = SHJSlotMediator;
        })(s_h_j_slot = abstract_games.s_h_j_slot || (abstract_games.s_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var r_w_j_slot;
        (function (r_w_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var RWJSlotProxy = (function (_super) {
                __extends(RWJSlotProxy, _super);
                function RWJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return RWJSlotProxy;
            }(BHSlotProxy));
            r_w_j_slot.RWJSlotProxy = RWJSlotProxy;
        })(r_w_j_slot = abstract_games.r_w_j_slot || (abstract_games.r_w_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var r_w_j_slot;
        (function (r_w_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var RWJSlotMediator = (function (_super) {
                __extends(RWJSlotMediator, _super);
                function RWJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return RWJSlotMediator;
            }(BHSlotMediator));
            r_w_j_slot.RWJSlotMediator = RWJSlotMediator;
        })(r_w_j_slot = abstract_games.r_w_j_slot || (abstract_games.r_w_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_s_j_slot;
        (function (f_s_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FSJSlotProxy = (function (_super) {
                __extends(FSJSlotProxy, _super);
                function FSJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FSJSlotProxy;
            }(BHSlotProxy));
            f_s_j_slot.FSJSlotProxy = FSJSlotProxy;
        })(f_s_j_slot = abstract_games.f_s_j_slot || (abstract_games.f_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_s_j_slot;
        (function (f_s_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FSJSlotMediator = (function (_super) {
                __extends(FSJSlotMediator, _super);
                function FSJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FSJSlotMediator;
            }(BHSlotMediator));
            f_s_j_slot.FSJSlotMediator = FSJSlotMediator;
        })(f_s_j_slot = abstract_games.f_s_j_slot || (abstract_games.f_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var s_b_j_slot;
        (function (s_b_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var SBJSlotProxy = (function (_super) {
                __extends(SBJSlotProxy, _super);
                function SBJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return SBJSlotProxy;
            }(BHSlotProxy));
            s_b_j_slot.SBJSlotProxy = SBJSlotProxy;
        })(s_b_j_slot = abstract_games.s_b_j_slot || (abstract_games.s_b_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var s_b_j_slot;
        (function (s_b_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var SBJSlotMediator = (function (_super) {
                __extends(SBJSlotMediator, _super);
                function SBJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return SBJSlotMediator;
            }(BHSlotMediator));
            s_b_j_slot.SBJSlotMediator = SBJSlotMediator;
        })(s_b_j_slot = abstract_games.s_b_j_slot || (abstract_games.s_b_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var m_p_j_slot;
        (function (m_p_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var MPJSlotProxy = (function (_super) {
                __extends(MPJSlotProxy, _super);
                function MPJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return MPJSlotProxy;
            }(BHSlotProxy));
            m_p_j_slot.MPJSlotProxy = MPJSlotProxy;
        })(m_p_j_slot = abstract_games.m_p_j_slot || (abstract_games.m_p_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var m_p_j_slot;
        (function (m_p_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var MPJSlotMediator = (function (_super) {
                __extends(MPJSlotMediator, _super);
                function MPJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return MPJSlotMediator;
            }(BHSlotMediator));
            m_p_j_slot.MPJSlotMediator = MPJSlotMediator;
        })(m_p_j_slot = abstract_games.m_p_j_slot || (abstract_games.m_p_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var blackjack;
        (function (blackjack) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var BlackjackProxy = (function (_super) {
                __extends(BlackjackProxy, _super);
                function BlackjackProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                BlackjackProxy.prototype.supportPortrait = function () {
                    return false;
                };
                return BlackjackProxy;
            }(BHSlotProxy));
            blackjack.BlackjackProxy = BlackjackProxy;
        })(blackjack = abstract_games.blackjack || (abstract_games.blackjack = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var blackjack;
        (function (blackjack) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var BlackjackMediator = (function (_super) {
                __extends(BlackjackMediator, _super);
                function BlackjackMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return BlackjackMediator;
            }(BHSlotMediator));
            blackjack.BlackjackMediator = BlackjackMediator;
        })(blackjack = abstract_games.blackjack || (abstract_games.blackjack = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_b_h_j_slot;
        (function (f_b_h_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FBHJSlotProxy = (function (_super) {
                __extends(FBHJSlotProxy, _super);
                function FBHJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FBHJSlotProxy;
            }(BHSlotProxy));
            f_b_h_j_slot.FBHJSlotProxy = FBHJSlotProxy;
        })(f_b_h_j_slot = abstract_games.f_b_h_j_slot || (abstract_games.f_b_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_b_h_j_slot;
        (function (f_b_h_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FBHJSlotMediator = (function (_super) {
                __extends(FBHJSlotMediator, _super);
                function FBHJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FBHJSlotMediator;
            }(BHSlotMediator));
            f_b_h_j_slot.FBHJSlotMediator = FBHJSlotMediator;
        })(f_b_h_j_slot = abstract_games.f_b_h_j_slot || (abstract_games.f_b_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var w_t_j_slot;
        (function (w_t_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var WTJSlotProxy = (function (_super) {
                __extends(WTJSlotProxy, _super);
                function WTJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return WTJSlotProxy;
            }(BHSlotProxy));
            w_t_j_slot.WTJSlotProxy = WTJSlotProxy;
        })(w_t_j_slot = abstract_games.w_t_j_slot || (abstract_games.w_t_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var w_t_j_slot;
        (function (w_t_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var WTJSlotMediator = (function (_super) {
                __extends(WTJSlotMediator, _super);
                function WTJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return WTJSlotMediator;
            }(BHSlotMediator));
            w_t_j_slot.WTJSlotMediator = WTJSlotMediator;
        })(w_t_j_slot = abstract_games.w_t_j_slot || (abstract_games.w_t_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_w_w_j_slot;
        (function (t_w_w_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var TWWJSlotProxy = (function (_super) {
                __extends(TWWJSlotProxy, _super);
                function TWWJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return TWWJSlotProxy;
            }(BHSlotProxy));
            t_w_w_j_slot.TWWJSlotProxy = TWWJSlotProxy;
        })(t_w_w_j_slot = abstract_games.t_w_w_j_slot || (abstract_games.t_w_w_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_w_w_j_slot;
        (function (t_w_w_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var TWWJSlotMediator = (function (_super) {
                __extends(TWWJSlotMediator, _super);
                function TWWJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return TWWJSlotMediator;
            }(BHSlotMediator));
            t_w_w_j_slot.TWWJSlotMediator = TWWJSlotMediator;
        })(t_w_w_j_slot = abstract_games.t_w_w_j_slot || (abstract_games.t_w_w_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var i_g_t_j_slot;
        (function (i_g_t_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var IGTJSlotProxy = (function (_super) {
                __extends(IGTJSlotProxy, _super);
                function IGTJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return IGTJSlotProxy;
            }(BHSlotProxy));
            i_g_t_j_slot.IGTJSlotProxy = IGTJSlotProxy;
        })(i_g_t_j_slot = abstract_games.i_g_t_j_slot || (abstract_games.i_g_t_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var i_g_t_j_slot;
        (function (i_g_t_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var IGTJSlotMediator = (function (_super) {
                __extends(IGTJSlotMediator, _super);
                function IGTJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return IGTJSlotMediator;
            }(BHSlotMediator));
            i_g_t_j_slot.IGTJSlotMediator = IGTJSlotMediator;
        })(i_g_t_j_slot = abstract_games.i_g_t_j_slot || (abstract_games.i_g_t_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_s_f_j_slot;
        (function (t_s_f_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var TSFJSlotProxy = (function (_super) {
                __extends(TSFJSlotProxy, _super);
                function TSFJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return TSFJSlotProxy;
            }(BHSlotProxy));
            t_s_f_j_slot.TSFJSlotProxy = TSFJSlotProxy;
        })(t_s_f_j_slot = abstract_games.t_s_f_j_slot || (abstract_games.t_s_f_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_s_f_j_slot;
        (function (t_s_f_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var TSFJSlotMediator = (function (_super) {
                __extends(TSFJSlotMediator, _super);
                function TSFJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return TSFJSlotMediator;
            }(BHSlotMediator));
            t_s_f_j_slot.TSFJSlotMediator = TSFJSlotMediator;
        })(t_s_f_j_slot = abstract_games.t_s_f_j_slot || (abstract_games.t_s_f_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var o_c_j_slot;
        (function (o_c_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var OCJSlotProxy = (function (_super) {
                __extends(OCJSlotProxy, _super);
                function OCJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return OCJSlotProxy;
            }(BHSlotProxy));
            o_c_j_slot.OCJSlotProxy = OCJSlotProxy;
        })(o_c_j_slot = abstract_games.o_c_j_slot || (abstract_games.o_c_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var o_c_j_slot;
        (function (o_c_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var OCJSlotMediator = (function (_super) {
                __extends(OCJSlotMediator, _super);
                function OCJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return OCJSlotMediator;
            }(BHSlotMediator));
            o_c_j_slot.OCJSlotMediator = OCJSlotMediator;
        })(o_c_j_slot = abstract_games.o_c_j_slot || (abstract_games.o_c_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var d_r_j_slot;
        (function (d_r_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var DRJSlotProxy = (function (_super) {
                __extends(DRJSlotProxy, _super);
                function DRJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return DRJSlotProxy;
            }(BHSlotProxy));
            d_r_j_slot.DRJSlotProxy = DRJSlotProxy;
        })(d_r_j_slot = abstract_games.d_r_j_slot || (abstract_games.d_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var d_r_j_slot;
        (function (d_r_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var DRJSlotMediator = (function (_super) {
                __extends(DRJSlotMediator, _super);
                function DRJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return DRJSlotMediator;
            }(BHSlotMediator));
            d_r_j_slot.DRJSlotMediator = DRJSlotMediator;
        })(d_r_j_slot = abstract_games.d_r_j_slot || (abstract_games.d_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var c_i_j_slot;
        (function (c_i_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var CIJSlotProxy = (function (_super) {
                __extends(CIJSlotProxy, _super);
                function CIJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return CIJSlotProxy;
            }(BHSlotProxy));
            c_i_j_slot.CIJSlotProxy = CIJSlotProxy;
        })(c_i_j_slot = abstract_games.c_i_j_slot || (abstract_games.c_i_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var c_i_j_slot;
        (function (c_i_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var CIJSlotMediator = (function (_super) {
                __extends(CIJSlotMediator, _super);
                function CIJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return CIJSlotMediator;
            }(BHSlotMediator));
            c_i_j_slot.CIJSlotMediator = CIJSlotMediator;
        })(c_i_j_slot = abstract_games.c_i_j_slot || (abstract_games.c_i_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var w_c_j_slot;
        (function (w_c_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var WCJSlotProxy = (function (_super) {
                __extends(WCJSlotProxy, _super);
                function WCJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return WCJSlotProxy;
            }(BHSlotProxy));
            w_c_j_slot.WCJSlotProxy = WCJSlotProxy;
        })(w_c_j_slot = abstract_games.w_c_j_slot || (abstract_games.w_c_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var w_c_j_slot;
        (function (w_c_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var WCJSlotMediator = (function (_super) {
                __extends(WCJSlotMediator, _super);
                function WCJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return WCJSlotMediator;
            }(BHSlotMediator));
            w_c_j_slot.WCJSlotMediator = WCJSlotMediator;
        })(w_c_j_slot = abstract_games.w_c_j_slot || (abstract_games.w_c_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_h_s_j_slot;
        (function (f_h_s_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FHSJSlotProxy = (function (_super) {
                __extends(FHSJSlotProxy, _super);
                function FHSJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FHSJSlotProxy;
            }(BHSlotProxy));
            f_h_s_j_slot.FHSJSlotProxy = FHSJSlotProxy;
        })(f_h_s_j_slot = abstract_games.f_h_s_j_slot || (abstract_games.f_h_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_h_s_j_slot;
        (function (f_h_s_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FHSJSlotMediator = (function (_super) {
                __extends(FHSJSlotMediator, _super);
                function FHSJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FHSJSlotMediator;
            }(BHSlotMediator));
            f_h_s_j_slot.FHSJSlotMediator = FHSJSlotMediator;
        })(f_h_s_j_slot = abstract_games.f_h_s_j_slot || (abstract_games.f_h_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var q_o_r_j_slot;
        (function (q_o_r_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var QORJSlotProxy = (function (_super) {
                __extends(QORJSlotProxy, _super);
                function QORJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return QORJSlotProxy;
            }(BHSlotProxy));
            q_o_r_j_slot.QORJSlotProxy = QORJSlotProxy;
        })(q_o_r_j_slot = abstract_games.q_o_r_j_slot || (abstract_games.q_o_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var q_o_r_j_slot;
        (function (q_o_r_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var QORJSlotMediator = (function (_super) {
                __extends(QORJSlotMediator, _super);
                function QORJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return QORJSlotMediator;
            }(BHSlotMediator));
            q_o_r_j_slot.QORJSlotMediator = QORJSlotMediator;
        })(q_o_r_j_slot = abstract_games.q_o_r_j_slot || (abstract_games.q_o_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var h_s_h_j_slot;
        (function (h_s_h_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var HSHJSlotProxy = (function (_super) {
                __extends(HSHJSlotProxy, _super);
                function HSHJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return HSHJSlotProxy;
            }(BHSlotProxy));
            h_s_h_j_slot.HSHJSlotProxy = HSHJSlotProxy;
        })(h_s_h_j_slot = abstract_games.h_s_h_j_slot || (abstract_games.h_s_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var h_s_h_j_slot;
        (function (h_s_h_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var HSHJSlotMediator = (function (_super) {
                __extends(HSHJSlotMediator, _super);
                function HSHJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return HSHJSlotMediator;
            }(BHSlotMediator));
            h_s_h_j_slot.HSHJSlotMediator = HSHJSlotMediator;
        })(h_s_h_j_slot = abstract_games.h_s_h_j_slot || (abstract_games.h_s_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_m_j_slot;
        (function (f_m_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FMJSlotProxy = (function (_super) {
                __extends(FMJSlotProxy, _super);
                function FMJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FMJSlotProxy;
            }(BHSlotProxy));
            f_m_j_slot.FMJSlotProxy = FMJSlotProxy;
        })(f_m_j_slot = abstract_games.f_m_j_slot || (abstract_games.f_m_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_m_j_slot;
        (function (f_m_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FMJSlotMediator = (function (_super) {
                __extends(FMJSlotMediator, _super);
                function FMJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FMJSlotMediator;
            }(BHSlotMediator));
            f_m_j_slot.FMJSlotMediator = FMJSlotMediator;
        })(f_m_j_slot = abstract_games.f_m_j_slot || (abstract_games.f_m_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_b_h_j_slot;
        (function (t_b_h_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var TBHJSlotMediator = (function (_super) {
                __extends(TBHJSlotMediator, _super);
                function TBHJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return TBHJSlotMediator;
            }(BHSlotMediator));
            t_b_h_j_slot.TBHJSlotMediator = TBHJSlotMediator;
        })(t_b_h_j_slot = abstract_games.t_b_h_j_slot || (abstract_games.t_b_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_b_h_j_slot;
        (function (t_b_h_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var TBHJSlotProxy = (function (_super) {
                __extends(TBHJSlotProxy, _super);
                function TBHJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return TBHJSlotProxy;
            }(BHSlotProxy));
            t_b_h_j_slot.TBHJSlotProxy = TBHJSlotProxy;
        })(t_b_h_j_slot = abstract_games.t_b_h_j_slot || (abstract_games.t_b_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_d_j_slot;
        (function (f_d_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FDJSlotProxy = (function (_super) {
                __extends(FDJSlotProxy, _super);
                function FDJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FDJSlotProxy;
            }(BHSlotProxy));
            f_d_j_slot.FDJSlotProxy = FDJSlotProxy;
        })(f_d_j_slot = abstract_games.f_d_j_slot || (abstract_games.f_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_d_j_slot;
        (function (f_d_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FDJSlotMediator = (function (_super) {
                __extends(FDJSlotMediator, _super);
                function FDJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FDJSlotMediator;
            }(BHSlotMediator));
            f_d_j_slot.FDJSlotMediator = FDJSlotMediator;
        })(f_d_j_slot = abstract_games.f_d_j_slot || (abstract_games.f_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_b_h_t_j_slot;
        (function (f_b_h_t_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FBHTJSlotProxy = (function (_super) {
                __extends(FBHTJSlotProxy, _super);
                function FBHTJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FBHTJSlotProxy;
            }(BHSlotProxy));
            f_b_h_t_j_slot.FBHTJSlotProxy = FBHTJSlotProxy;
        })(f_b_h_t_j_slot = abstract_games.f_b_h_t_j_slot || (abstract_games.f_b_h_t_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_b_h_t_j_slot;
        (function (f_b_h_t_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FBHTJSlotMediator = (function (_super) {
                __extends(FBHTJSlotMediator, _super);
                function FBHTJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FBHTJSlotMediator;
            }(BHSlotMediator));
            f_b_h_t_j_slot.FBHTJSlotMediator = FBHTJSlotMediator;
        })(f_b_h_t_j_slot = abstract_games.f_b_h_t_j_slot || (abstract_games.f_b_h_t_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var g_e_t_j_slot;
        (function (g_e_t_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var GETJSlotMediator = (function (_super) {
                __extends(GETJSlotMediator, _super);
                function GETJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return GETJSlotMediator;
            }(BHSlotMediator));
            g_e_t_j_slot.GETJSlotMediator = GETJSlotMediator;
        })(g_e_t_j_slot = abstract_games.g_e_t_j_slot || (abstract_games.g_e_t_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var g_e_t_j_slot;
        (function (g_e_t_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var GETJSlotProxy = (function (_super) {
                __extends(GETJSlotProxy, _super);
                function GETJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return GETJSlotProxy;
            }(BHSlotProxy));
            g_e_t_j_slot.GETJSlotProxy = GETJSlotProxy;
        })(g_e_t_j_slot = abstract_games.g_e_t_j_slot || (abstract_games.g_e_t_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_b_j_j_slot;
        (function (t_b_j_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var TBJJSlotProxy = (function (_super) {
                __extends(TBJJSlotProxy, _super);
                function TBJJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return TBJJSlotProxy;
            }(BHSlotProxy));
            t_b_j_j_slot.TBJJSlotProxy = TBJJSlotProxy;
        })(t_b_j_j_slot = abstract_games.t_b_j_j_slot || (abstract_games.t_b_j_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_b_j_j_slot;
        (function (t_b_j_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var TBJJSlotMediator = (function (_super) {
                __extends(TBJJSlotMediator, _super);
                function TBJJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return TBJJSlotMediator;
            }(BHSlotMediator));
            t_b_j_j_slot.TBJJSlotMediator = TBJJSlotMediator;
        })(t_b_j_j_slot = abstract_games.t_b_j_j_slot || (abstract_games.t_b_j_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var m_s_j_slot;
        (function (m_s_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var MSJSlotProxy = (function (_super) {
                __extends(MSJSlotProxy, _super);
                function MSJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return MSJSlotProxy;
            }(BHSlotProxy));
            m_s_j_slot.MSJSlotProxy = MSJSlotProxy;
        })(m_s_j_slot = abstract_games.m_s_j_slot || (abstract_games.m_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var m_s_j_slot;
        (function (m_s_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var MSJSlotMediator = (function (_super) {
                __extends(MSJSlotMediator, _super);
                function MSJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return MSJSlotMediator;
            }(BHSlotMediator));
            m_s_j_slot.MSJSlotMediator = MSJSlotMediator;
        })(m_s_j_slot = abstract_games.m_s_j_slot || (abstract_games.m_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_h_d_j_slot;
        (function (f_h_d_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FHDJSlotProxy = (function (_super) {
                __extends(FHDJSlotProxy, _super);
                function FHDJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FHDJSlotProxy;
            }(BHSlotProxy));
            f_h_d_j_slot.FHDJSlotProxy = FHDJSlotProxy;
        })(f_h_d_j_slot = abstract_games.f_h_d_j_slot || (abstract_games.f_h_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_h_d_j_slot;
        (function (f_h_d_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FHDJSlotMediator = (function (_super) {
                __extends(FHDJSlotMediator, _super);
                function FHDJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FHDJSlotMediator;
            }(BHSlotMediator));
            f_h_d_j_slot.FHDJSlotMediator = FHDJSlotMediator;
        })(f_h_d_j_slot = abstract_games.f_h_d_j_slot || (abstract_games.f_h_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_d_r_j_slot;
        (function (t_d_r_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var TDRJSlotMediator = (function (_super) {
                __extends(TDRJSlotMediator, _super);
                function TDRJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return TDRJSlotMediator;
            }(BHSlotMediator));
            t_d_r_j_slot.TDRJSlotMediator = TDRJSlotMediator;
        })(t_d_r_j_slot = abstract_games.t_d_r_j_slot || (abstract_games.t_d_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_d_r_j_slot;
        (function (t_d_r_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var TDRJSlotProxy = (function (_super) {
                __extends(TDRJSlotProxy, _super);
                function TDRJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return TDRJSlotProxy;
            }(BHSlotProxy));
            t_d_r_j_slot.TDRJSlotProxy = TDRJSlotProxy;
        })(t_d_r_j_slot = abstract_games.t_d_r_j_slot || (abstract_games.t_d_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var d_o_r_j_slot;
        (function (d_o_r_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var DORJSlotMediator = (function (_super) {
                __extends(DORJSlotMediator, _super);
                function DORJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return DORJSlotMediator;
            }(BHSlotMediator));
            d_o_r_j_slot.DORJSlotMediator = DORJSlotMediator;
        })(d_o_r_j_slot = abstract_games.d_o_r_j_slot || (abstract_games.d_o_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var d_o_r_j_slot;
        (function (d_o_r_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var DORJSlotProxy = (function (_super) {
                __extends(DORJSlotProxy, _super);
                function DORJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return DORJSlotProxy;
            }(BHSlotProxy));
            d_o_r_j_slot.DORJSlotProxy = DORJSlotProxy;
        })(d_o_r_j_slot = abstract_games.d_o_r_j_slot || (abstract_games.d_o_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var h_d_j_slot;
        (function (h_d_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var HDJSlotProxy = (function (_super) {
                __extends(HDJSlotProxy, _super);
                function HDJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return HDJSlotProxy;
            }(BHSlotProxy));
            h_d_j_slot.HDJSlotProxy = HDJSlotProxy;
        })(h_d_j_slot = abstract_games.h_d_j_slot || (abstract_games.h_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var h_d_j_slot;
        (function (h_d_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var HDJSlotMediator = (function (_super) {
                __extends(HDJSlotMediator, _super);
                function HDJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return HDJSlotMediator;
            }(BHSlotMediator));
            h_d_j_slot.HDJSlotMediator = HDJSlotMediator;
        })(h_d_j_slot = abstract_games.h_d_j_slot || (abstract_games.h_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_b_d_j_slot;
        (function (f_b_d_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FBDJSlotProxy = (function (_super) {
                __extends(FBDJSlotProxy, _super);
                function FBDJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FBDJSlotProxy;
            }(BHSlotProxy));
            f_b_d_j_slot.FBDJSlotProxy = FBDJSlotProxy;
        })(f_b_d_j_slot = abstract_games.f_b_d_j_slot || (abstract_games.f_b_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_b_d_j_slot;
        (function (f_b_d_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FBDJSlotMediator = (function (_super) {
                __extends(FBDJSlotMediator, _super);
                function FBDJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FBDJSlotMediator;
            }(BHSlotMediator));
            f_b_d_j_slot.FBDJSlotMediator = FBDJSlotMediator;
        })(f_b_d_j_slot = abstract_games.f_b_d_j_slot || (abstract_games.f_b_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_b_d_j_slot;
        (function (t_b_d_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var TBDJSlotProxy = (function (_super) {
                __extends(TBDJSlotProxy, _super);
                function TBDJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return TBDJSlotProxy;
            }(BHSlotProxy));
            t_b_d_j_slot.TBDJSlotProxy = TBDJSlotProxy;
        })(t_b_d_j_slot = abstract_games.t_b_d_j_slot || (abstract_games.t_b_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_b_d_j_slot;
        (function (t_b_d_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var TBDJSlotMediator = (function (_super) {
                __extends(TBDJSlotMediator, _super);
                function TBDJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return TBDJSlotMediator;
            }(BHSlotMediator));
            t_b_d_j_slot.TBDJSlotMediator = TBDJSlotMediator;
        })(t_b_d_j_slot = abstract_games.t_b_d_j_slot || (abstract_games.t_b_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var r_t_s_j_slot;
        (function (r_t_s_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var RTSJSlotProxy = (function (_super) {
                __extends(RTSJSlotProxy, _super);
                function RTSJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return RTSJSlotProxy;
            }(BHSlotProxy));
            r_t_s_j_slot.RTSJSlotProxy = RTSJSlotProxy;
        })(r_t_s_j_slot = abstract_games.r_t_s_j_slot || (abstract_games.r_t_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var r_t_s_j_slot;
        (function (r_t_s_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var RTSJSlotMediator = (function (_super) {
                __extends(RTSJSlotMediator, _super);
                function RTSJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return RTSJSlotMediator;
            }(BHSlotMediator));
            r_t_s_j_slot.RTSJSlotMediator = RTSJSlotMediator;
        })(r_t_s_j_slot = abstract_games.r_t_s_j_slot || (abstract_games.r_t_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var s_d_j_slot;
        (function (s_d_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var SDJSlotProxy = (function (_super) {
                __extends(SDJSlotProxy, _super);
                function SDJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return SDJSlotProxy;
            }(BHSlotProxy));
            s_d_j_slot.SDJSlotProxy = SDJSlotProxy;
        })(s_d_j_slot = abstract_games.s_d_j_slot || (abstract_games.s_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var s_d_j_slot;
        (function (s_d_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var SDJSlotMediator = (function (_super) {
                __extends(SDJSlotMediator, _super);
                function SDJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return SDJSlotMediator;
            }(BHSlotMediator));
            s_d_j_slot.SDJSlotMediator = SDJSlotMediator;
        })(s_d_j_slot = abstract_games.s_d_j_slot || (abstract_games.s_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var m_b_h_slot;
        (function (m_b_h_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var MBHSlotProxy = (function (_super) {
                __extends(MBHSlotProxy, _super);
                function MBHSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return MBHSlotProxy;
            }(BHSlotProxy));
            m_b_h_slot.MBHSlotProxy = MBHSlotProxy;
        })(m_b_h_slot = abstract_games.m_b_h_slot || (abstract_games.m_b_h_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var m_b_h_slot;
        (function (m_b_h_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var MBHSlotMediator = (function (_super) {
                __extends(MBHSlotMediator, _super);
                function MBHSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return MBHSlotMediator;
            }(BHSlotMediator));
            m_b_h_slot.MBHSlotMediator = MBHSlotMediator;
        })(m_b_h_slot = abstract_games.m_b_h_slot || (abstract_games.m_b_h_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var m_s_h_slot;
        (function (m_s_h_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var MSHSlotProxy = (function (_super) {
                __extends(MSHSlotProxy, _super);
                function MSHSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return MSHSlotProxy;
            }(BHSlotProxy));
            m_s_h_slot.MSHSlotProxy = MSHSlotProxy;
        })(m_s_h_slot = abstract_games.m_s_h_slot || (abstract_games.m_s_h_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var m_s_h_slot;
        (function (m_s_h_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var MSHSlotMediator = (function (_super) {
                __extends(MSHSlotMediator, _super);
                function MSHSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return MSHSlotMediator;
            }(BHSlotMediator));
            m_s_h_slot.MSHSlotMediator = MSHSlotMediator;
        })(m_s_h_slot = abstract_games.m_s_h_slot || (abstract_games.m_s_h_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var m_u_h_slot;
        (function (m_u_h_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var MUHSlotProxy = (function (_super) {
                __extends(MUHSlotProxy, _super);
                function MUHSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return MUHSlotProxy;
            }(BHSlotProxy));
            m_u_h_slot.MUHSlotProxy = MUHSlotProxy;
        })(m_u_h_slot = abstract_games.m_u_h_slot || (abstract_games.m_u_h_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var m_u_h_slot;
        (function (m_u_h_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var MUHSlotMediator = (function (_super) {
                __extends(MUHSlotMediator, _super);
                function MUHSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return MUHSlotMediator;
            }(BHSlotMediator));
            m_u_h_slot.MUHSlotMediator = MUHSlotMediator;
        })(m_u_h_slot = abstract_games.m_u_h_slot || (abstract_games.m_u_h_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_h_s_d_j_slot;
        (function (t_h_s_d_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var THSDJSlotProxy = (function (_super) {
                __extends(THSDJSlotProxy, _super);
                function THSDJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return THSDJSlotProxy;
            }(BHSlotProxy));
            t_h_s_d_j_slot.THSDJSlotProxy = THSDJSlotProxy;
        })(t_h_s_d_j_slot = abstract_games.t_h_s_d_j_slot || (abstract_games.t_h_s_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_h_s_d_j_slot;
        (function (t_h_s_d_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var THSDJSlotMediator = (function (_super) {
                __extends(THSDJSlotMediator, _super);
                function THSDJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return THSDJSlotMediator;
            }(BHSlotMediator));
            t_h_s_d_j_slot.THSDJSlotMediator = THSDJSlotMediator;
        })(t_h_s_d_j_slot = abstract_games.t_h_s_d_j_slot || (abstract_games.t_h_s_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var a_s_j_slot;
        (function (a_s_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var ASJSlotProxy = (function (_super) {
                __extends(ASJSlotProxy, _super);
                function ASJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return ASJSlotProxy;
            }(BHSlotProxy));
            a_s_j_slot.ASJSlotProxy = ASJSlotProxy;
        })(a_s_j_slot = abstract_games.a_s_j_slot || (abstract_games.a_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var a_s_j_slot;
        (function (a_s_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var ASJSlotMediator = (function (_super) {
                __extends(ASJSlotMediator, _super);
                function ASJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return ASJSlotMediator;
            }(BHSlotMediator));
            a_s_j_slot.ASJSlotMediator = ASJSlotMediator;
        })(a_s_j_slot = abstract_games.a_s_j_slot || (abstract_games.a_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_b_j_slot;
        (function (f_b_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FBJSlotProxy = (function (_super) {
                __extends(FBJSlotProxy, _super);
                function FBJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FBJSlotProxy;
            }(BHSlotProxy));
            f_b_j_slot.FBJSlotProxy = FBJSlotProxy;
        })(f_b_j_slot = abstract_games.f_b_j_slot || (abstract_games.f_b_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_b_j_slot;
        (function (f_b_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FBJSlotMediator = (function (_super) {
                __extends(FBJSlotMediator, _super);
                function FBJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FBJSlotMediator;
            }(BHSlotMediator));
            f_b_j_slot.FBJSlotMediator = FBJSlotMediator;
        })(f_b_j_slot = abstract_games.f_b_j_slot || (abstract_games.f_b_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var c_r_j_slot;
        (function (c_r_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var CRJSlotProxy = (function (_super) {
                __extends(CRJSlotProxy, _super);
                function CRJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return CRJSlotProxy;
            }(BHSlotProxy));
            c_r_j_slot.CRJSlotProxy = CRJSlotProxy;
        })(c_r_j_slot = abstract_games.c_r_j_slot || (abstract_games.c_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var c_r_j_slot;
        (function (c_r_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var CRJSlotMediator = (function (_super) {
                __extends(CRJSlotMediator, _super);
                function CRJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return CRJSlotMediator;
            }(BHSlotMediator));
            c_r_j_slot.CRJSlotMediator = CRJSlotMediator;
        })(c_r_j_slot = abstract_games.c_r_j_slot || (abstract_games.c_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var d_q_j_slot;
        (function (d_q_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var DQJSlotProxy = (function (_super) {
                __extends(DQJSlotProxy, _super);
                function DQJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return DQJSlotProxy;
            }(BHSlotProxy));
            d_q_j_slot.DQJSlotProxy = DQJSlotProxy;
        })(d_q_j_slot = abstract_games.d_q_j_slot || (abstract_games.d_q_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var d_q_j_slot;
        (function (d_q_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var DQJSlotMediator = (function (_super) {
                __extends(DQJSlotMediator, _super);
                function DQJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return DQJSlotMediator;
            }(BHSlotMediator));
            d_q_j_slot.DQJSlotMediator = DQJSlotMediator;
        })(d_q_j_slot = abstract_games.d_q_j_slot || (abstract_games.d_q_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var e_s_j_slot;
        (function (e_s_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var ESJSlotProxy = (function (_super) {
                __extends(ESJSlotProxy, _super);
                function ESJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return ESJSlotProxy;
            }(BHSlotProxy));
            e_s_j_slot.ESJSlotProxy = ESJSlotProxy;
        })(e_s_j_slot = abstract_games.e_s_j_slot || (abstract_games.e_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var e_s_j_slot;
        (function (e_s_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var ESJSlotMediator = (function (_super) {
                __extends(ESJSlotMediator, _super);
                function ESJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return ESJSlotMediator;
            }(BHSlotMediator));
            e_s_j_slot.ESJSlotMediator = ESJSlotMediator;
        })(e_s_j_slot = abstract_games.e_s_j_slot || (abstract_games.e_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var l_b_j_slot;
        (function (l_b_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var LBJSlotProxy = (function (_super) {
                __extends(LBJSlotProxy, _super);
                function LBJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return LBJSlotProxy;
            }(BHSlotProxy));
            l_b_j_slot.LBJSlotProxy = LBJSlotProxy;
        })(l_b_j_slot = abstract_games.l_b_j_slot || (abstract_games.l_b_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var l_b_j_slot;
        (function (l_b_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var LBJSlotMediator = (function (_super) {
                __extends(LBJSlotMediator, _super);
                function LBJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return LBJSlotMediator;
            }(BHSlotMediator));
            l_b_j_slot.LBJSlotMediator = LBJSlotMediator;
        })(l_b_j_slot = abstract_games.l_b_j_slot || (abstract_games.l_b_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_s_o_a_j_slot;
        (function (t_s_o_a_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var TSOAJSlotProxy = (function (_super) {
                __extends(TSOAJSlotProxy, _super);
                function TSOAJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return TSOAJSlotProxy;
            }(BHSlotProxy));
            t_s_o_a_j_slot.TSOAJSlotProxy = TSOAJSlotProxy;
        })(t_s_o_a_j_slot = abstract_games.t_s_o_a_j_slot || (abstract_games.t_s_o_a_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_s_o_a_j_slot;
        (function (t_s_o_a_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var TSOAJSlotMediator = (function (_super) {
                __extends(TSOAJSlotMediator, _super);
                function TSOAJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return TSOAJSlotMediator;
            }(BHSlotMediator));
            t_s_o_a_j_slot.TSOAJSlotMediator = TSOAJSlotMediator;
        })(t_s_o_a_j_slot = abstract_games.t_s_o_a_j_slot || (abstract_games.t_s_o_a_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var casino_battle;
        (function (casino_battle) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var CasinoBattleProxy = (function (_super) {
                __extends(CasinoBattleProxy, _super);
                function CasinoBattleProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return CasinoBattleProxy;
            }(BHSlotProxy));
            casino_battle.CasinoBattleProxy = CasinoBattleProxy;
        })(casino_battle = abstract_games.casino_battle || (abstract_games.casino_battle = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var casino_battle;
        (function (casino_battle) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var CasinoBattleMediator = (function (_super) {
                __extends(CasinoBattleMediator, _super);
                function CasinoBattleMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return CasinoBattleMediator;
            }(BHSlotMediator));
            casino_battle.CasinoBattleMediator = CasinoBattleMediator;
        })(casino_battle = abstract_games.casino_battle || (abstract_games.casino_battle = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var p_s_j_slot;
        (function (p_s_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var PSJSlotProxy = (function (_super) {
                __extends(PSJSlotProxy, _super);
                function PSJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return PSJSlotProxy;
            }(BHSlotProxy));
            p_s_j_slot.PSJSlotProxy = PSJSlotProxy;
        })(p_s_j_slot = abstract_games.p_s_j_slot || (abstract_games.p_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var p_s_j_slot;
        (function (p_s_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var PSJSlotMediator = (function (_super) {
                __extends(PSJSlotMediator, _super);
                function PSJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return PSJSlotMediator;
            }(BHSlotMediator));
            p_s_j_slot.PSJSlotMediator = PSJSlotMediator;
        })(p_s_j_slot = abstract_games.p_s_j_slot || (abstract_games.p_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var m_f_j_slot;
        (function (m_f_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var MFJSlotProxy = (function (_super) {
                __extends(MFJSlotProxy, _super);
                function MFJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return MFJSlotProxy;
            }(BHSlotProxy));
            m_f_j_slot.MFJSlotProxy = MFJSlotProxy;
        })(m_f_j_slot = abstract_games.m_f_j_slot || (abstract_games.m_f_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var m_f_j_slot;
        (function (m_f_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var MFJSlotMediator = (function (_super) {
                __extends(MFJSlotMediator, _super);
                function MFJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return MFJSlotMediator;
            }(BHSlotMediator));
            m_f_j_slot.MFJSlotMediator = MFJSlotMediator;
        })(m_f_j_slot = abstract_games.m_f_j_slot || (abstract_games.m_f_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var o_g_j_slot;
        (function (o_g_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var OGJSlotProxy = (function (_super) {
                __extends(OGJSlotProxy, _super);
                function OGJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return OGJSlotProxy;
            }(BHSlotProxy));
            o_g_j_slot.OGJSlotProxy = OGJSlotProxy;
        })(o_g_j_slot = abstract_games.o_g_j_slot || (abstract_games.o_g_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var o_g_j_slot;
        (function (o_g_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var OGJSlotMediator = (function (_super) {
                __extends(OGJSlotMediator, _super);
                function OGJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return OGJSlotMediator;
            }(BHSlotMediator));
            o_g_j_slot.OGJSlotMediator = OGJSlotMediator;
        })(o_g_j_slot = abstract_games.o_g_j_slot || (abstract_games.o_g_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var g_o_c_j_slot;
        (function (g_o_c_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var GOCJSlotProxy = (function (_super) {
                __extends(GOCJSlotProxy, _super);
                function GOCJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return GOCJSlotProxy;
            }(BHSlotProxy));
            g_o_c_j_slot.GOCJSlotProxy = GOCJSlotProxy;
        })(g_o_c_j_slot = abstract_games.g_o_c_j_slot || (abstract_games.g_o_c_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var g_o_c_j_slot;
        (function (g_o_c_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var GOCJSlotMediator = (function (_super) {
                __extends(GOCJSlotMediator, _super);
                function GOCJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return GOCJSlotMediator;
            }(BHSlotMediator));
            g_o_c_j_slot.GOCJSlotMediator = GOCJSlotMediator;
        })(g_o_c_j_slot = abstract_games.g_o_c_j_slot || (abstract_games.g_o_c_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var r_q_j_slot;
        (function (r_q_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var RQJSlotProxy = (function (_super) {
                __extends(RQJSlotProxy, _super);
                function RQJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return RQJSlotProxy;
            }(BHSlotProxy));
            r_q_j_slot.RQJSlotProxy = RQJSlotProxy;
        })(r_q_j_slot = abstract_games.r_q_j_slot || (abstract_games.r_q_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var r_q_j_slot;
        (function (r_q_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var RQJSlotMediator = (function (_super) {
                __extends(RQJSlotMediator, _super);
                function RQJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return RQJSlotMediator;
            }(BHSlotMediator));
            r_q_j_slot.RQJSlotMediator = RQJSlotMediator;
        })(r_q_j_slot = abstract_games.r_q_j_slot || (abstract_games.r_q_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var v_g_j_slot;
        (function (v_g_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var VGJSlotProxy = (function (_super) {
                __extends(VGJSlotProxy, _super);
                function VGJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return VGJSlotProxy;
            }(BHSlotProxy));
            v_g_j_slot.VGJSlotProxy = VGJSlotProxy;
        })(v_g_j_slot = abstract_games.v_g_j_slot || (abstract_games.v_g_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var v_g_j_slot;
        (function (v_g_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var VGJSlotMediator = (function (_super) {
                __extends(VGJSlotMediator, _super);
                function VGJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return VGJSlotMediator;
            }(BHSlotMediator));
            v_g_j_slot.VGJSlotMediator = VGJSlotMediator;
        })(v_g_j_slot = abstract_games.v_g_j_slot || (abstract_games.v_g_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var v_n_j_slot;
        (function (v_n_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var VNJSlotProxy = (function (_super) {
                __extends(VNJSlotProxy, _super);
                function VNJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return VNJSlotProxy;
            }(BHSlotProxy));
            v_n_j_slot.VNJSlotProxy = VNJSlotProxy;
        })(v_n_j_slot = abstract_games.v_n_j_slot || (abstract_games.v_n_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var v_n_j_slot;
        (function (v_n_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var VNJSlotMediator = (function (_super) {
                __extends(VNJSlotMediator, _super);
                function VNJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return VNJSlotMediator;
            }(BHSlotMediator));
            v_n_j_slot.VNJSlotMediator = VNJSlotMediator;
        })(v_n_j_slot = abstract_games.v_n_j_slot || (abstract_games.v_n_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var a_g_j_slot;
        (function (a_g_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var AGJSlotProxy = (function (_super) {
                __extends(AGJSlotProxy, _super);
                function AGJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return AGJSlotProxy;
            }(BHSlotProxy));
            a_g_j_slot.AGJSlotProxy = AGJSlotProxy;
        })(a_g_j_slot = abstract_games.a_g_j_slot || (abstract_games.a_g_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var a_g_j_slot;
        (function (a_g_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var AGJSlotMediator = (function (_super) {
                __extends(AGJSlotMediator, _super);
                function AGJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return AGJSlotMediator;
            }(BHSlotMediator));
            a_g_j_slot.AGJSlotMediator = AGJSlotMediator;
        })(a_g_j_slot = abstract_games.a_g_j_slot || (abstract_games.a_g_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var r_l_t_j_slot;
        (function (r_l_t_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var RLTJSlotProxy = (function (_super) {
                __extends(RLTJSlotProxy, _super);
                function RLTJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return RLTJSlotProxy;
            }(BHSlotProxy));
            r_l_t_j_slot.RLTJSlotProxy = RLTJSlotProxy;
        })(r_l_t_j_slot = abstract_games.r_l_t_j_slot || (abstract_games.r_l_t_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var r_l_t_j_slot;
        (function (r_l_t_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var RLTJSlotMediator = (function (_super) {
                __extends(RLTJSlotMediator, _super);
                function RLTJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return RLTJSlotMediator;
            }(BHSlotMediator));
            r_l_t_j_slot.RLTJSlotMediator = RLTJSlotMediator;
        })(r_l_t_j_slot = abstract_games.r_l_t_j_slot || (abstract_games.r_l_t_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var j_p_j_poker;
        (function (j_p_j_poker) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var JPJPokerMediator = (function (_super) {
                __extends(JPJPokerMediator, _super);
                function JPJPokerMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return JPJPokerMediator;
            }(BHSlotMediator));
            j_p_j_poker.JPJPokerMediator = JPJPokerMediator;
        })(j_p_j_poker = abstract_games.j_p_j_poker || (abstract_games.j_p_j_poker = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var j_p_j_poker;
        (function (j_p_j_poker) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var JPJPokerProxy = (function (_super) {
                __extends(JPJPokerProxy, _super);
                function JPJPokerProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return JPJPokerProxy;
            }(BHSlotProxy));
            j_p_j_poker.JPJPokerProxy = JPJPokerProxy;
        })(j_p_j_poker = abstract_games.j_p_j_poker || (abstract_games.j_p_j_poker = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var j_o_b_j_poker;
        (function (j_o_b_j_poker) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var JOBJPokerMediator = (function (_super) {
                __extends(JOBJPokerMediator, _super);
                function JOBJPokerMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return JOBJPokerMediator;
            }(BHSlotMediator));
            j_o_b_j_poker.JOBJPokerMediator = JOBJPokerMediator;
        })(j_o_b_j_poker = abstract_games.j_o_b_j_poker || (abstract_games.j_o_b_j_poker = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var j_o_b_j_poker;
        (function (j_o_b_j_poker) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var JOBJPokerProxy = (function (_super) {
                __extends(JOBJPokerProxy, _super);
                function JOBJPokerProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return JOBJPokerProxy;
            }(BHSlotProxy));
            j_o_b_j_poker.JOBJPokerProxy = JOBJPokerProxy;
        })(j_o_b_j_poker = abstract_games.j_o_b_j_poker || (abstract_games.j_o_b_j_poker = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_o_k_b_j_poker;
        (function (f_o_k_b_j_poker) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FOKBJPokerMediator = (function (_super) {
                __extends(FOKBJPokerMediator, _super);
                function FOKBJPokerMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FOKBJPokerMediator;
            }(BHSlotMediator));
            f_o_k_b_j_poker.FOKBJPokerMediator = FOKBJPokerMediator;
        })(f_o_k_b_j_poker = abstract_games.f_o_k_b_j_poker || (abstract_games.f_o_k_b_j_poker = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_o_k_b_j_poker;
        (function (f_o_k_b_j_poker) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FOKBJPokerProxy = (function (_super) {
                __extends(FOKBJPokerProxy, _super);
                function FOKBJPokerProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FOKBJPokerProxy;
            }(BHSlotProxy));
            f_o_k_b_j_poker.FOKBJPokerProxy = FOKBJPokerProxy;
        })(f_o_k_b_j_poker = abstract_games.f_o_k_b_j_poker || (abstract_games.f_o_k_b_j_poker = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var h_w_j_slot;
        (function (h_w_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var HWJSlotProxy = (function (_super) {
                __extends(HWJSlotProxy, _super);
                function HWJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return HWJSlotProxy;
            }(BHSlotProxy));
            h_w_j_slot.HWJSlotProxy = HWJSlotProxy;
        })(h_w_j_slot = abstract_games.h_w_j_slot || (abstract_games.h_w_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var h_w_j_slot;
        (function (h_w_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var HWJSlotMediator = (function (_super) {
                __extends(HWJSlotMediator, _super);
                function HWJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return HWJSlotMediator;
            }(BHSlotMediator));
            h_w_j_slot.HWJSlotMediator = HWJSlotMediator;
        })(h_w_j_slot = abstract_games.h_w_j_slot || (abstract_games.h_w_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var r_d_j_slot;
        (function (r_d_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var RDJSlotProxy = (function (_super) {
                __extends(RDJSlotProxy, _super);
                function RDJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return RDJSlotProxy;
            }(BHSlotProxy));
            r_d_j_slot.RDJSlotProxy = RDJSlotProxy;
        })(r_d_j_slot = abstract_games.r_d_j_slot || (abstract_games.r_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var r_d_j_slot;
        (function (r_d_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var RDJSlotMediator = (function (_super) {
                __extends(RDJSlotMediator, _super);
                function RDJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return RDJSlotMediator;
            }(BHSlotMediator));
            r_d_j_slot.RDJSlotMediator = RDJSlotMediator;
        })(r_d_j_slot = abstract_games.r_d_j_slot || (abstract_games.r_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_b_h_s_j_slot;
        (function (f_b_h_s_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FBHSJSlotProxy = (function (_super) {
                __extends(FBHSJSlotProxy, _super);
                function FBHSJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FBHSJSlotProxy;
            }(BHSlotProxy));
            f_b_h_s_j_slot.FBHSJSlotProxy = FBHSJSlotProxy;
        })(f_b_h_s_j_slot = abstract_games.f_b_h_s_j_slot || (abstract_games.f_b_h_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_b_h_s_j_slot;
        (function (f_b_h_s_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FBHSJSlotMediator = (function (_super) {
                __extends(FBHSJSlotMediator, _super);
                function FBHSJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FBHSJSlotMediator;
            }(BHSlotMediator));
            f_b_h_s_j_slot.FBHSJSlotMediator = FBHSJSlotMediator;
        })(f_b_h_s_j_slot = abstract_games.f_b_h_s_j_slot || (abstract_games.f_b_h_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var d_a_r_j_slot;
        (function (d_a_r_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var DARJSlotProxy = (function (_super) {
                __extends(DARJSlotProxy, _super);
                function DARJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return DARJSlotProxy;
            }(BHSlotProxy));
            d_a_r_j_slot.DARJSlotProxy = DARJSlotProxy;
        })(d_a_r_j_slot = abstract_games.d_a_r_j_slot || (abstract_games.d_a_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var d_a_r_j_slot;
        (function (d_a_r_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var DARJSlotMediator = (function (_super) {
                __extends(DARJSlotMediator, _super);
                function DARJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return DARJSlotMediator;
            }(BHSlotMediator));
            d_a_r_j_slot.DARJSlotMediator = DARJSlotMediator;
        })(d_a_r_j_slot = abstract_games.d_a_r_j_slot || (abstract_games.d_a_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_h_n_c_j_slot;
        (function (f_h_n_c_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FHNCJSlotProxy = (function (_super) {
                __extends(FHNCJSlotProxy, _super);
                function FHNCJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FHNCJSlotProxy;
            }(BHSlotProxy));
            f_h_n_c_j_slot.FHNCJSlotProxy = FHNCJSlotProxy;
        })(f_h_n_c_j_slot = abstract_games.f_h_n_c_j_slot || (abstract_games.f_h_n_c_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_h_n_c_j_slot;
        (function (f_h_n_c_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FHNCJSlotMediator = (function (_super) {
                __extends(FHNCJSlotMediator, _super);
                function FHNCJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FHNCJSlotMediator;
            }(BHSlotMediator));
            f_h_n_c_j_slot.FHNCJSlotMediator = FHNCJSlotMediator;
        })(f_h_n_c_j_slot = abstract_games.f_h_n_c_j_slot || (abstract_games.f_h_n_c_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var x_s_j_slot;
        (function (x_s_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var XSJSlotMediator = (function (_super) {
                __extends(XSJSlotMediator, _super);
                function XSJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return XSJSlotMediator;
            }(BHSlotMediator));
            x_s_j_slot.XSJSlotMediator = XSJSlotMediator;
        })(x_s_j_slot = abstract_games.x_s_j_slot || (abstract_games.x_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var x_s_j_slot;
        (function (x_s_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var XSJSlotProxy = (function (_super) {
                __extends(XSJSlotProxy, _super);
                function XSJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return XSJSlotProxy;
            }(BHSlotProxy));
            x_s_j_slot.XSJSlotProxy = XSJSlotProxy;
        })(x_s_j_slot = abstract_games.x_s_j_slot || (abstract_games.x_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var x_j_j_slot;
        (function (x_j_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var XJJSlotMediator = (function (_super) {
                __extends(XJJSlotMediator, _super);
                function XJJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return XJJSlotMediator;
            }(BHSlotMediator));
            x_j_j_slot.XJJSlotMediator = XJJSlotMediator;
        })(x_j_j_slot = abstract_games.x_j_j_slot || (abstract_games.x_j_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var x_j_j_slot;
        (function (x_j_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var XJJSlotProxy = (function (_super) {
                __extends(XJJSlotProxy, _super);
                function XJJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return XJJSlotProxy;
            }(BHSlotProxy));
            x_j_j_slot.XJJSlotProxy = XJJSlotProxy;
        })(x_j_j_slot = abstract_games.x_j_j_slot || (abstract_games.x_j_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var r_m_j_slot;
        (function (r_m_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var RMJSlotProxy = (function (_super) {
                __extends(RMJSlotProxy, _super);
                function RMJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return RMJSlotProxy;
            }(BHSlotProxy));
            r_m_j_slot.RMJSlotProxy = RMJSlotProxy;
        })(r_m_j_slot = abstract_games.r_m_j_slot || (abstract_games.r_m_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var r_m_j_slot;
        (function (r_m_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var RMJSlotMediator = (function (_super) {
                __extends(RMJSlotMediator, _super);
                function RMJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return RMJSlotMediator;
            }(BHSlotMediator));
            r_m_j_slot.RMJSlotMediator = RMJSlotMediator;
        })(r_m_j_slot = abstract_games.r_m_j_slot || (abstract_games.r_m_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var g_o_l_j_slot;
        (function (g_o_l_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var GOLJSlotProxy = (function (_super) {
                __extends(GOLJSlotProxy, _super);
                function GOLJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return GOLJSlotProxy;
            }(BHSlotProxy));
            g_o_l_j_slot.GOLJSlotProxy = GOLJSlotProxy;
        })(g_o_l_j_slot = abstract_games.g_o_l_j_slot || (abstract_games.g_o_l_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var g_o_l_j_slot;
        (function (g_o_l_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var GOLJSlotMediator = (function (_super) {
                __extends(GOLJSlotMediator, _super);
                function GOLJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return GOLJSlotMediator;
            }(BHSlotMediator));
            g_o_l_j_slot.GOLJSlotMediator = GOLJSlotMediator;
        })(g_o_l_j_slot = abstract_games.g_o_l_j_slot || (abstract_games.g_o_l_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_b_h_t_j_slot;
        (function (t_b_h_t_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var TBHTJSlotProxy = (function (_super) {
                __extends(TBHTJSlotProxy, _super);
                function TBHTJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return TBHTJSlotProxy;
            }(BHSlotProxy));
            t_b_h_t_j_slot.TBHTJSlotProxy = TBHTJSlotProxy;
        })(t_b_h_t_j_slot = abstract_games.t_b_h_t_j_slot || (abstract_games.t_b_h_t_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_b_h_t_j_slot;
        (function (t_b_h_t_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var TBHTJSlotMediator = (function (_super) {
                __extends(TBHTJSlotMediator, _super);
                function TBHTJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return TBHTJSlotMediator;
            }(BHSlotMediator));
            t_b_h_t_j_slot.TBHTJSlotMediator = TBHTJSlotMediator;
        })(t_b_h_t_j_slot = abstract_games.t_b_h_t_j_slot || (abstract_games.t_b_h_t_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var h_n_c_j_slot;
        (function (h_n_c_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var HNCJSlotProxy = (function (_super) {
                __extends(HNCJSlotProxy, _super);
                function HNCJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return HNCJSlotProxy;
            }(BHSlotProxy));
            h_n_c_j_slot.HNCJSlotProxy = HNCJSlotProxy;
        })(h_n_c_j_slot = abstract_games.h_n_c_j_slot || (abstract_games.h_n_c_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var h_n_c_j_slot;
        (function (h_n_c_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var HNCJSlotMediator = (function (_super) {
                __extends(HNCJSlotMediator, _super);
                function HNCJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return HNCJSlotMediator;
            }(BHSlotMediator));
            h_n_c_j_slot.HNCJSlotMediator = HNCJSlotMediator;
        })(h_n_c_j_slot = abstract_games.h_n_c_j_slot || (abstract_games.h_n_c_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var l_a_w_j_slot;
        (function (l_a_w_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var LAWJSlotProxy = (function (_super) {
                __extends(LAWJSlotProxy, _super);
                function LAWJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return LAWJSlotProxy;
            }(BHSlotProxy));
            l_a_w_j_slot.LAWJSlotProxy = LAWJSlotProxy;
        })(l_a_w_j_slot = abstract_games.l_a_w_j_slot || (abstract_games.l_a_w_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var l_a_w_j_slot;
        (function (l_a_w_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var LAWJSlotMediator = (function (_super) {
                __extends(LAWJSlotMediator, _super);
                function LAWJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return LAWJSlotMediator;
            }(BHSlotMediator));
            l_a_w_j_slot.LAWJSlotMediator = LAWJSlotMediator;
        })(l_a_w_j_slot = abstract_games.l_a_w_j_slot || (abstract_games.l_a_w_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var m_l_a_w_j_slot;
        (function (m_l_a_w_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var MLAWJSlotProxy = (function (_super) {
                __extends(MLAWJSlotProxy, _super);
                function MLAWJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return MLAWJSlotProxy;
            }(BHSlotProxy));
            m_l_a_w_j_slot.MLAWJSlotProxy = MLAWJSlotProxy;
        })(m_l_a_w_j_slot = abstract_games.m_l_a_w_j_slot || (abstract_games.m_l_a_w_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var m_l_a_w_j_slot;
        (function (m_l_a_w_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var MLAWJSlotMediator = (function (_super) {
                __extends(MLAWJSlotMediator, _super);
                function MLAWJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return MLAWJSlotMediator;
            }(BHSlotMediator));
            m_l_a_w_j_slot.MLAWJSlotMediator = MLAWJSlotMediator;
        })(m_l_a_w_j_slot = abstract_games.m_l_a_w_j_slot || (abstract_games.m_l_a_w_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var m_d_a_r_j_slot;
        (function (m_d_a_r_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var MDARJSlotProxy = (function (_super) {
                __extends(MDARJSlotProxy, _super);
                function MDARJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return MDARJSlotProxy;
            }(BHSlotProxy));
            m_d_a_r_j_slot.MDARJSlotProxy = MDARJSlotProxy;
        })(m_d_a_r_j_slot = abstract_games.m_d_a_r_j_slot || (abstract_games.m_d_a_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var m_d_a_r_j_slot;
        (function (m_d_a_r_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var MDARJSlotMediator = (function (_super) {
                __extends(MDARJSlotMediator, _super);
                function MDARJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return MDARJSlotMediator;
            }(BHSlotMediator));
            m_d_a_r_j_slot.MDARJSlotMediator = MDARJSlotMediator;
        })(m_d_a_r_j_slot = abstract_games.m_d_a_r_j_slot || (abstract_games.m_d_a_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var w_h_j_slot;
        (function (w_h_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var WHJSlotProxy = (function (_super) {
                __extends(WHJSlotProxy, _super);
                function WHJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return WHJSlotProxy;
            }(BHSlotProxy));
            w_h_j_slot.WHJSlotProxy = WHJSlotProxy;
        })(w_h_j_slot = abstract_games.w_h_j_slot || (abstract_games.w_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var w_h_j_slot;
        (function (w_h_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var WHJSlotMediator = (function (_super) {
                __extends(WHJSlotMediator, _super);
                function WHJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return WHJSlotMediator;
            }(BHSlotMediator));
            w_h_j_slot.WHJSlotMediator = WHJSlotMediator;
        })(w_h_j_slot = abstract_games.w_h_j_slot || (abstract_games.w_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var s_o_a_j_slot;
        (function (s_o_a_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var SOAJSlotProxy = (function (_super) {
                __extends(SOAJSlotProxy, _super);
                function SOAJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return SOAJSlotProxy;
            }(BHSlotProxy));
            s_o_a_j_slot.SOAJSlotProxy = SOAJSlotProxy;
        })(s_o_a_j_slot = abstract_games.s_o_a_j_slot || (abstract_games.s_o_a_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var s_o_a_j_slot;
        (function (s_o_a_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var SOAJSlotMediator = (function (_super) {
                __extends(SOAJSlotMediator, _super);
                function SOAJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return SOAJSlotMediator;
            }(BHSlotMediator));
            s_o_a_j_slot.SOAJSlotMediator = SOAJSlotMediator;
        })(s_o_a_j_slot = abstract_games.s_o_a_j_slot || (abstract_games.s_o_a_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_s_o_l_j_slot;
        (function (t_s_o_l_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var TSOLJSlotProxy = (function (_super) {
                __extends(TSOLJSlotProxy, _super);
                function TSOLJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return TSOLJSlotProxy;
            }(BHSlotProxy));
            t_s_o_l_j_slot.TSOLJSlotProxy = TSOLJSlotProxy;
        })(t_s_o_l_j_slot = abstract_games.t_s_o_l_j_slot || (abstract_games.t_s_o_l_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_s_o_l_j_slot;
        (function (t_s_o_l_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var TSOLJSlotMediator = (function (_super) {
                __extends(TSOLJSlotMediator, _super);
                function TSOLJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return TSOLJSlotMediator;
            }(BHSlotMediator));
            t_s_o_l_j_slot.TSOLJSlotMediator = TSOLJSlotMediator;
        })(t_s_o_l_j_slot = abstract_games.t_s_o_l_j_slot || (abstract_games.t_s_o_l_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var a_p_j_slot;
        (function (a_p_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var APJSlotProxy = (function (_super) {
                __extends(APJSlotProxy, _super);
                function APJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return APJSlotProxy;
            }(BHSlotProxy));
            a_p_j_slot.APJSlotProxy = APJSlotProxy;
        })(a_p_j_slot = abstract_games.a_p_j_slot || (abstract_games.a_p_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var a_p_j_slot;
        (function (a_p_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var APJSlotMediator = (function (_super) {
                __extends(APJSlotMediator, _super);
                function APJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return APJSlotMediator;
            }(BHSlotMediator));
            a_p_j_slot.APJSlotMediator = APJSlotMediator;
        })(a_p_j_slot = abstract_games.a_p_j_slot || (abstract_games.a_p_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var d_g_r_j_slot;
        (function (d_g_r_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var DGRJSlotProxy = (function (_super) {
                __extends(DGRJSlotProxy, _super);
                function DGRJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return DGRJSlotProxy;
            }(BHSlotProxy));
            d_g_r_j_slot.DGRJSlotProxy = DGRJSlotProxy;
        })(d_g_r_j_slot = abstract_games.d_g_r_j_slot || (abstract_games.d_g_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var d_g_r_j_slot;
        (function (d_g_r_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var DGRJSlotMediator = (function (_super) {
                __extends(DGRJSlotMediator, _super);
                function DGRJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return DGRJSlotMediator;
            }(BHSlotMediator));
            d_g_r_j_slot.DGRJSlotMediator = DGRJSlotMediator;
        })(d_g_r_j_slot = abstract_games.d_g_r_j_slot || (abstract_games.d_g_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var v_d_j_slot;
        (function (v_d_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var VDJSlotProxy = (function (_super) {
                __extends(VDJSlotProxy, _super);
                function VDJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return VDJSlotProxy;
            }(BHSlotProxy));
            v_d_j_slot.VDJSlotProxy = VDJSlotProxy;
        })(v_d_j_slot = abstract_games.v_d_j_slot || (abstract_games.v_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var v_d_j_slot;
        (function (v_d_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var VDJSlotMediator = (function (_super) {
                __extends(VDJSlotMediator, _super);
                function VDJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return VDJSlotMediator;
            }(BHSlotMediator));
            v_d_j_slot.VDJSlotMediator = VDJSlotMediator;
        })(v_d_j_slot = abstract_games.v_d_j_slot || (abstract_games.v_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_e_j_slot;
        (function (t_e_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var TEJSlotProxy = (function (_super) {
                __extends(TEJSlotProxy, _super);
                function TEJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return TEJSlotProxy;
            }(BHSlotProxy));
            t_e_j_slot.TEJSlotProxy = TEJSlotProxy;
        })(t_e_j_slot = abstract_games.t_e_j_slot || (abstract_games.t_e_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_e_j_slot;
        (function (t_e_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var TEJSlotMediator = (function (_super) {
                __extends(TEJSlotMediator, _super);
                function TEJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return TEJSlotMediator;
            }(BHSlotMediator));
            t_e_j_slot.TEJSlotMediator = TEJSlotMediator;
        })(t_e_j_slot = abstract_games.t_e_j_slot || (abstract_games.t_e_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_r_s_j_slot;
        (function (f_r_s_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FRSJSlotProxy = (function (_super) {
                __extends(FRSJSlotProxy, _super);
                function FRSJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FRSJSlotProxy;
            }(BHSlotProxy));
            f_r_s_j_slot.FRSJSlotProxy = FRSJSlotProxy;
        })(f_r_s_j_slot = abstract_games.f_r_s_j_slot || (abstract_games.f_r_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_r_s_j_slot;
        (function (f_r_s_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FRSJSlotMediator = (function (_super) {
                __extends(FRSJSlotMediator, _super);
                function FRSJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FRSJSlotMediator;
            }(BHSlotMediator));
            f_r_s_j_slot.FRSJSlotMediator = FRSJSlotMediator;
        })(f_r_s_j_slot = abstract_games.f_r_s_j_slot || (abstract_games.f_r_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var j_a_j_slot;
        (function (j_a_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var JAJSlotProxy = (function (_super) {
                __extends(JAJSlotProxy, _super);
                function JAJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return JAJSlotProxy;
            }(BHSlotProxy));
            j_a_j_slot.JAJSlotProxy = JAJSlotProxy;
        })(j_a_j_slot = abstract_games.j_a_j_slot || (abstract_games.j_a_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var j_a_j_slot;
        (function (j_a_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var JAJSlotMediator = (function (_super) {
                __extends(JAJSlotMediator, _super);
                function JAJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return JAJSlotMediator;
            }(BHSlotMediator));
            j_a_j_slot.JAJSlotMediator = JAJSlotMediator;
        })(j_a_j_slot = abstract_games.j_a_j_slot || (abstract_games.j_a_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var k_l_j_slot;
        (function (k_l_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var KLJSlotProxy = (function (_super) {
                __extends(KLJSlotProxy, _super);
                function KLJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return KLJSlotProxy;
            }(BHSlotProxy));
            k_l_j_slot.KLJSlotProxy = KLJSlotProxy;
        })(k_l_j_slot = abstract_games.k_l_j_slot || (abstract_games.k_l_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var k_l_j_slot;
        (function (k_l_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var KLJSlotMediator = (function (_super) {
                __extends(KLJSlotMediator, _super);
                function KLJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return KLJSlotMediator;
            }(BHSlotMediator));
            k_l_j_slot.KLJSlotMediator = KLJSlotMediator;
        })(k_l_j_slot = abstract_games.k_l_j_slot || (abstract_games.k_l_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_l_k_j_slot;
        (function (f_l_k_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FLKJSlotProxy = (function (_super) {
                __extends(FLKJSlotProxy, _super);
                function FLKJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FLKJSlotProxy;
            }(BHSlotProxy));
            f_l_k_j_slot.FLKJSlotProxy = FLKJSlotProxy;
        })(f_l_k_j_slot = abstract_games.f_l_k_j_slot || (abstract_games.f_l_k_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_l_k_j_slot;
        (function (f_l_k_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FLKJSlotMediator = (function (_super) {
                __extends(FLKJSlotMediator, _super);
                function FLKJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FLKJSlotMediator;
            }(BHSlotMediator));
            f_l_k_j_slot.FLKJSlotMediator = FLKJSlotMediator;
        })(f_l_k_j_slot = abstract_games.f_l_k_j_slot || (abstract_games.f_l_k_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_m_c_j_slot;
        (function (f_m_c_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FMCJSlotProxy = (function (_super) {
                __extends(FMCJSlotProxy, _super);
                function FMCJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FMCJSlotProxy;
            }(BHSlotProxy));
            f_m_c_j_slot.FMCJSlotProxy = FMCJSlotProxy;
        })(f_m_c_j_slot = abstract_games.f_m_c_j_slot || (abstract_games.f_m_c_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_m_c_j_slot;
        (function (f_m_c_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FMCJSlotMediator = (function (_super) {
                __extends(FMCJSlotMediator, _super);
                function FMCJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FMCJSlotMediator;
            }(BHSlotMediator));
            f_m_c_j_slot.FMCJSlotMediator = FMCJSlotMediator;
        })(f_m_c_j_slot = abstract_games.f_m_c_j_slot || (abstract_games.f_m_c_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var h_b_h_j_slot;
        (function (h_b_h_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var HBHJSlotProxy = (function (_super) {
                __extends(HBHJSlotProxy, _super);
                function HBHJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return HBHJSlotProxy;
            }(BHSlotProxy));
            h_b_h_j_slot.HBHJSlotProxy = HBHJSlotProxy;
        })(h_b_h_j_slot = abstract_games.h_b_h_j_slot || (abstract_games.h_b_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var h_b_h_j_slot;
        (function (h_b_h_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var HBHJSlotMediator = (function (_super) {
                __extends(HBHJSlotMediator, _super);
                function HBHJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return HBHJSlotMediator;
            }(BHSlotMediator));
            h_b_h_j_slot.HBHJSlotMediator = HBHJSlotMediator;
        })(h_b_h_j_slot = abstract_games.h_b_h_j_slot || (abstract_games.h_b_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var l_a_d_j_slot;
        (function (l_a_d_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var LADJSlotProxy = (function (_super) {
                __extends(LADJSlotProxy, _super);
                function LADJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return LADJSlotProxy;
            }(BHSlotProxy));
            l_a_d_j_slot.LADJSlotProxy = LADJSlotProxy;
        })(l_a_d_j_slot = abstract_games.l_a_d_j_slot || (abstract_games.l_a_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var l_a_d_j_slot;
        (function (l_a_d_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var LADJSlotMediator = (function (_super) {
                __extends(LADJSlotMediator, _super);
                function LADJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return LADJSlotMediator;
            }(BHSlotMediator));
            l_a_d_j_slot.LADJSlotMediator = LADJSlotMediator;
        })(l_a_d_j_slot = abstract_games.l_a_d_j_slot || (abstract_games.l_a_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var m_l_a_d_j_slot;
        (function (m_l_a_d_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var MLADJSlotProxy = (function (_super) {
                __extends(MLADJSlotProxy, _super);
                function MLADJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return MLADJSlotProxy;
            }(BHSlotProxy));
            m_l_a_d_j_slot.MLADJSlotProxy = MLADJSlotProxy;
        })(m_l_a_d_j_slot = abstract_games.m_l_a_d_j_slot || (abstract_games.m_l_a_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var m_l_a_d_j_slot;
        (function (m_l_a_d_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var MLADJSlotMediator = (function (_super) {
                __extends(MLADJSlotMediator, _super);
                function MLADJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return MLADJSlotMediator;
            }(BHSlotMediator));
            m_l_a_d_j_slot.MLADJSlotMediator = MLADJSlotMediator;
        })(m_l_a_d_j_slot = abstract_games.m_l_a_d_j_slot || (abstract_games.m_l_a_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var g_e_j_slot;
        (function (g_e_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var GEJSlotProxy = (function (_super) {
                __extends(GEJSlotProxy, _super);
                function GEJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return GEJSlotProxy;
            }(BHSlotProxy));
            g_e_j_slot.GEJSlotProxy = GEJSlotProxy;
        })(g_e_j_slot = abstract_games.g_e_j_slot || (abstract_games.g_e_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var g_e_j_slot;
        (function (g_e_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var GEJSlotMediator = (function (_super) {
                __extends(GEJSlotMediator, _super);
                function GEJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return GEJSlotMediator;
            }(BHSlotMediator));
            g_e_j_slot.GEJSlotMediator = GEJSlotMediator;
        })(g_e_j_slot = abstract_games.g_e_j_slot || (abstract_games.g_e_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var p_q_j_slot;
        (function (p_q_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var PQJSlotProxy = (function (_super) {
                __extends(PQJSlotProxy, _super);
                function PQJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return PQJSlotProxy;
            }(BHSlotProxy));
            p_q_j_slot.PQJSlotProxy = PQJSlotProxy;
        })(p_q_j_slot = abstract_games.p_q_j_slot || (abstract_games.p_q_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var p_q_j_slot;
        (function (p_q_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var PQJSlotMediator = (function (_super) {
                __extends(PQJSlotMediator, _super);
                function PQJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return PQJSlotMediator;
            }(BHSlotMediator));
            p_q_j_slot.PQJSlotMediator = PQJSlotMediator;
        })(p_q_j_slot = abstract_games.p_q_j_slot || (abstract_games.p_q_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var i_w_j_slot;
        (function (i_w_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var IWJSlotProxy = (function (_super) {
                __extends(IWJSlotProxy, _super);
                function IWJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return IWJSlotProxy;
            }(BHSlotProxy));
            i_w_j_slot.IWJSlotProxy = IWJSlotProxy;
        })(i_w_j_slot = abstract_games.i_w_j_slot || (abstract_games.i_w_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var i_w_j_slot;
        (function (i_w_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var IWJSlotMediator = (function (_super) {
                __extends(IWJSlotMediator, _super);
                function IWJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return IWJSlotMediator;
            }(BHSlotMediator));
            i_w_j_slot.IWJSlotMediator = IWJSlotMediator;
        })(i_w_j_slot = abstract_games.i_w_j_slot || (abstract_games.i_w_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var i_m_d_j_slot;
        (function (i_m_d_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var IMDJSlotProxy = (function (_super) {
                __extends(IMDJSlotProxy, _super);
                function IMDJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return IMDJSlotProxy;
            }(BHSlotProxy));
            i_m_d_j_slot.IMDJSlotProxy = IMDJSlotProxy;
        })(i_m_d_j_slot = abstract_games.i_m_d_j_slot || (abstract_games.i_m_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var i_m_d_j_slot;
        (function (i_m_d_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var IMDJSlotMediator = (function (_super) {
                __extends(IMDJSlotMediator, _super);
                function IMDJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return IMDJSlotMediator;
            }(BHSlotMediator));
            i_m_d_j_slot.IMDJSlotMediator = IMDJSlotMediator;
        })(i_m_d_j_slot = abstract_games.i_m_d_j_slot || (abstract_games.i_m_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var b_c_j_slot;
        (function (b_c_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var BCJSlotProxy = (function (_super) {
                __extends(BCJSlotProxy, _super);
                function BCJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return BCJSlotProxy;
            }(BHSlotProxy));
            b_c_j_slot.BCJSlotProxy = BCJSlotProxy;
        })(b_c_j_slot = abstract_games.b_c_j_slot || (abstract_games.b_c_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var b_c_j_slot;
        (function (b_c_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var BCJSlotMediator = (function (_super) {
                __extends(BCJSlotMediator, _super);
                function BCJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return BCJSlotMediator;
            }(BHSlotMediator));
            b_c_j_slot.BCJSlotMediator = BCJSlotMediator;
        })(b_c_j_slot = abstract_games.b_c_j_slot || (abstract_games.b_c_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var g_a_j_slot;
        (function (g_a_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var GAJSlotProxy = (function (_super) {
                __extends(GAJSlotProxy, _super);
                function GAJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return GAJSlotProxy;
            }(BHSlotProxy));
            g_a_j_slot.GAJSlotProxy = GAJSlotProxy;
        })(g_a_j_slot = abstract_games.g_a_j_slot || (abstract_games.g_a_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var g_a_j_slot;
        (function (g_a_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var GAJSlotMediator = (function (_super) {
                __extends(GAJSlotMediator, _super);
                function GAJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return GAJSlotMediator;
            }(BHSlotMediator));
            g_a_j_slot.GAJSlotMediator = GAJSlotMediator;
        })(g_a_j_slot = abstract_games.g_a_j_slot || (abstract_games.g_a_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var s_l_j_slot;
        (function (s_l_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var SLJSlotProxy = (function (_super) {
                __extends(SLJSlotProxy, _super);
                function SLJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return SLJSlotProxy;
            }(BHSlotProxy));
            s_l_j_slot.SLJSlotProxy = SLJSlotProxy;
        })(s_l_j_slot = abstract_games.s_l_j_slot || (abstract_games.s_l_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var s_l_j_slot;
        (function (s_l_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var SLJSlotMediator = (function (_super) {
                __extends(SLJSlotMediator, _super);
                function SLJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return SLJSlotMediator;
            }(BHSlotMediator));
            s_l_j_slot.SLJSlotMediator = SLJSlotMediator;
        })(s_l_j_slot = abstract_games.s_l_j_slot || (abstract_games.s_l_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_d_h_j_slot;
        (function (t_d_h_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var TDHJSlotMediator = (function (_super) {
                __extends(TDHJSlotMediator, _super);
                function TDHJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return TDHJSlotMediator;
            }(BHSlotMediator));
            t_d_h_j_slot.TDHJSlotMediator = TDHJSlotMediator;
        })(t_d_h_j_slot = abstract_games.t_d_h_j_slot || (abstract_games.t_d_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_d_h_j_slot;
        (function (t_d_h_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var TDHJSlotProxy = (function (_super) {
                __extends(TDHJSlotProxy, _super);
                function TDHJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return TDHJSlotProxy;
            }(BHSlotProxy));
            t_d_h_j_slot.TDHJSlotProxy = TDHJSlotProxy;
        })(t_d_h_j_slot = abstract_games.t_d_h_j_slot || (abstract_games.t_d_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var g_e_o_l_j_slot;
        (function (g_e_o_l_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var GEOLJSlotMediator = (function (_super) {
                __extends(GEOLJSlotMediator, _super);
                function GEOLJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return GEOLJSlotMediator;
            }(BHSlotMediator));
            g_e_o_l_j_slot.GEOLJSlotMediator = GEOLJSlotMediator;
        })(g_e_o_l_j_slot = abstract_games.g_e_o_l_j_slot || (abstract_games.g_e_o_l_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var g_e_o_l_j_slot;
        (function (g_e_o_l_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var GEOLJSlotProxy = (function (_super) {
                __extends(GEOLJSlotProxy, _super);
                function GEOLJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return GEOLJSlotProxy;
            }(BHSlotProxy));
            g_e_o_l_j_slot.GEOLJSlotProxy = GEOLJSlotProxy;
        })(g_e_o_l_j_slot = abstract_games.g_e_o_l_j_slot || (abstract_games.g_e_o_l_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var s_c_h_j_slot;
        (function (s_c_h_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var SCHJSlotMediator = (function (_super) {
                __extends(SCHJSlotMediator, _super);
                function SCHJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return SCHJSlotMediator;
            }(BHSlotMediator));
            s_c_h_j_slot.SCHJSlotMediator = SCHJSlotMediator;
        })(s_c_h_j_slot = abstract_games.s_c_h_j_slot || (abstract_games.s_c_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var s_c_h_j_slot;
        (function (s_c_h_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var SCHJSlotProxy = (function (_super) {
                __extends(SCHJSlotProxy, _super);
                function SCHJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return SCHJSlotProxy;
            }(BHSlotProxy));
            s_c_h_j_slot.SCHJSlotProxy = SCHJSlotProxy;
        })(s_c_h_j_slot = abstract_games.s_c_h_j_slot || (abstract_games.s_c_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_s_d_j_slot;
        (function (f_s_d_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FSDJSlotMediator = (function (_super) {
                __extends(FSDJSlotMediator, _super);
                function FSDJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FSDJSlotMediator;
            }(BHSlotMediator));
            f_s_d_j_slot.FSDJSlotMediator = FSDJSlotMediator;
        })(f_s_d_j_slot = abstract_games.f_s_d_j_slot || (abstract_games.f_s_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_s_d_j_slot;
        (function (f_s_d_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FSDJSlotProxy = (function (_super) {
                __extends(FSDJSlotProxy, _super);
                function FSDJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FSDJSlotProxy;
            }(BHSlotProxy));
            f_s_d_j_slot.FSDJSlotProxy = FSDJSlotProxy;
        })(f_s_d_j_slot = abstract_games.f_s_d_j_slot || (abstract_games.f_s_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_g_s_j_slot;
        (function (f_g_s_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FGSJSlotMediator = (function (_super) {
                __extends(FGSJSlotMediator, _super);
                function FGSJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FGSJSlotMediator;
            }(BHSlotMediator));
            f_g_s_j_slot.FGSJSlotMediator = FGSJSlotMediator;
        })(f_g_s_j_slot = abstract_games.f_g_s_j_slot || (abstract_games.f_g_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_g_s_j_slot;
        (function (f_g_s_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FGSJSlotProxy = (function (_super) {
                __extends(FGSJSlotProxy, _super);
                function FGSJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FGSJSlotProxy;
            }(BHSlotProxy));
            f_g_s_j_slot.FGSJSlotProxy = FGSJSlotProxy;
        })(f_g_s_j_slot = abstract_games.f_g_s_j_slot || (abstract_games.f_g_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_a_b_j_slot;
        (function (f_a_b_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FABJSlotProxy = (function (_super) {
                __extends(FABJSlotProxy, _super);
                function FABJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FABJSlotProxy;
            }(BHSlotProxy));
            f_a_b_j_slot.FABJSlotProxy = FABJSlotProxy;
        })(f_a_b_j_slot = abstract_games.f_a_b_j_slot || (abstract_games.f_a_b_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_a_b_j_slot;
        (function (f_a_b_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FABJSlotMediator = (function (_super) {
                __extends(FABJSlotMediator, _super);
                function FABJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FABJSlotMediator;
            }(BHSlotMediator));
            f_a_b_j_slot.FABJSlotMediator = FABJSlotMediator;
        })(f_a_b_j_slot = abstract_games.f_a_b_j_slot || (abstract_games.f_a_b_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var o_r_j_slot;
        (function (o_r_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var ORJSlotMediator = (function (_super) {
                __extends(ORJSlotMediator, _super);
                function ORJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return ORJSlotMediator;
            }(BHSlotMediator));
            o_r_j_slot.ORJSlotMediator = ORJSlotMediator;
        })(o_r_j_slot = abstract_games.o_r_j_slot || (abstract_games.o_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var o_r_j_slot;
        (function (o_r_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var ORJSlotProxy = (function (_super) {
                __extends(ORJSlotProxy, _super);
                function ORJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return ORJSlotProxy;
            }(BHSlotProxy));
            o_r_j_slot.ORJSlotProxy = ORJSlotProxy;
        })(o_r_j_slot = abstract_games.o_r_j_slot || (abstract_games.o_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var l_r_j_slot;
        (function (l_r_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var LRJSlotMediator = (function (_super) {
                __extends(LRJSlotMediator, _super);
                function LRJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return LRJSlotMediator;
            }(BHSlotMediator));
            l_r_j_slot.LRJSlotMediator = LRJSlotMediator;
        })(l_r_j_slot = abstract_games.l_r_j_slot || (abstract_games.l_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var l_r_j_slot;
        (function (l_r_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var LRJSlotProxy = (function (_super) {
                __extends(LRJSlotProxy, _super);
                function LRJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return LRJSlotProxy;
            }(BHSlotProxy));
            l_r_j_slot.LRJSlotProxy = LRJSlotProxy;
        })(l_r_j_slot = abstract_games.l_r_j_slot || (abstract_games.l_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_s_d_j_slot;
        (function (t_s_d_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var TSDJSlotMediator = (function (_super) {
                __extends(TSDJSlotMediator, _super);
                function TSDJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return TSDJSlotMediator;
            }(BHSlotMediator));
            t_s_d_j_slot.TSDJSlotMediator = TSDJSlotMediator;
        })(t_s_d_j_slot = abstract_games.t_s_d_j_slot || (abstract_games.t_s_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_s_d_j_slot;
        (function (t_s_d_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var TSDJSlotProxy = (function (_super) {
                __extends(TSDJSlotProxy, _super);
                function TSDJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return TSDJSlotProxy;
            }(BHSlotProxy));
            t_s_d_j_slot.TSDJSlotProxy = TSDJSlotProxy;
        })(t_s_d_j_slot = abstract_games.t_s_d_j_slot || (abstract_games.t_s_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var d_h_i_j_slot;
        (function (d_h_i_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var DHIJSlotMediator = (function (_super) {
                __extends(DHIJSlotMediator, _super);
                function DHIJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return DHIJSlotMediator;
            }(BHSlotMediator));
            d_h_i_j_slot.DHIJSlotMediator = DHIJSlotMediator;
        })(d_h_i_j_slot = abstract_games.d_h_i_j_slot || (abstract_games.d_h_i_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var d_h_i_j_slot;
        (function (d_h_i_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var DHIJSlotProxy = (function (_super) {
                __extends(DHIJSlotProxy, _super);
                function DHIJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return DHIJSlotProxy;
            }(BHSlotProxy));
            d_h_i_j_slot.DHIJSlotProxy = DHIJSlotProxy;
        })(d_h_i_j_slot = abstract_games.d_h_i_j_slot || (abstract_games.d_h_i_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_u_r_j_slot;
        (function (f_u_r_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FURJSlotMediator = (function (_super) {
                __extends(FURJSlotMediator, _super);
                function FURJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FURJSlotMediator;
            }(BHSlotMediator));
            f_u_r_j_slot.FURJSlotMediator = FURJSlotMediator;
        })(f_u_r_j_slot = abstract_games.f_u_r_j_slot || (abstract_games.f_u_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_u_r_j_slot;
        (function (f_u_r_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FURJSlotProxy = (function (_super) {
                __extends(FURJSlotProxy, _super);
                function FURJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FURJSlotProxy;
            }(BHSlotProxy));
            f_u_r_j_slot.FURJSlotProxy = FURJSlotProxy;
        })(f_u_r_j_slot = abstract_games.f_u_r_j_slot || (abstract_games.f_u_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_j_r_j_slot;
        (function (t_j_r_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var TJRJSlotMediator = (function (_super) {
                __extends(TJRJSlotMediator, _super);
                function TJRJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return TJRJSlotMediator;
            }(BHSlotMediator));
            t_j_r_j_slot.TJRJSlotMediator = TJRJSlotMediator;
        })(t_j_r_j_slot = abstract_games.t_j_r_j_slot || (abstract_games.t_j_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_j_r_j_slot;
        (function (t_j_r_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var TJRJSlotProxy = (function (_super) {
                __extends(TJRJSlotProxy, _super);
                function TJRJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return TJRJSlotProxy;
            }(BHSlotProxy));
            t_j_r_j_slot.TJRJSlotProxy = TJRJSlotProxy;
        })(t_j_r_j_slot = abstract_games.t_j_r_j_slot || (abstract_games.t_j_r_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_s_w_j_slot;
        (function (t_s_w_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var TSWJSlotMediator = (function (_super) {
                __extends(TSWJSlotMediator, _super);
                function TSWJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return TSWJSlotMediator;
            }(BHSlotMediator));
            t_s_w_j_slot.TSWJSlotMediator = TSWJSlotMediator;
        })(t_s_w_j_slot = abstract_games.t_s_w_j_slot || (abstract_games.t_s_w_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_s_w_j_slot;
        (function (t_s_w_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var TSWJSlotProxy = (function (_super) {
                __extends(TSWJSlotProxy, _super);
                function TSWJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return TSWJSlotProxy;
            }(BHSlotProxy));
            t_s_w_j_slot.TSWJSlotProxy = TSWJSlotProxy;
        })(t_s_w_j_slot = abstract_games.t_s_w_j_slot || (abstract_games.t_s_w_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var g_t_s_j_slot;
        (function (g_t_s_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var GTSJSlotMediator = (function (_super) {
                __extends(GTSJSlotMediator, _super);
                function GTSJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return GTSJSlotMediator;
            }(BHSlotMediator));
            g_t_s_j_slot.GTSJSlotMediator = GTSJSlotMediator;
        })(g_t_s_j_slot = abstract_games.g_t_s_j_slot || (abstract_games.g_t_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var g_t_s_j_slot;
        (function (g_t_s_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var GTSJSlotProxy = (function (_super) {
                __extends(GTSJSlotProxy, _super);
                function GTSJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return GTSJSlotProxy;
            }(BHSlotProxy));
            g_t_s_j_slot.GTSJSlotProxy = GTSJSlotProxy;
        })(g_t_s_j_slot = abstract_games.g_t_s_j_slot || (abstract_games.g_t_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var roulette;
        (function (roulette) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var RouletteMediator = (function (_super) {
                __extends(RouletteMediator, _super);
                function RouletteMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                RouletteMediator.prototype.handleNotification = function (note) {
                    var rouletteProxy = this._facade.retrieveProxy(gpts.Router.getInstance().parameters.gameIdentificationNumber);
                    var noteName = note.getName();
                    if (noteName === abstract_games.GameMediator.SHOW + this.mediatorName) {
                        if (rouletteProxy.subscribeResponse !== undefined) {
                            rouletteProxy.updateSubscribeRemainingTime();
                        }
                    }
                    _super.prototype.handleNotification.call(this, note);
                };
                return RouletteMediator;
            }(BHSlotMediator));
            roulette.RouletteMediator = RouletteMediator;
        })(roulette = abstract_games.roulette || (abstract_games.roulette = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var roulette;
        (function (roulette) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var BetRequest = gpts.services.messages.request.BetRequest;
            var RouletteProxy = (function (_super) {
                __extends(RouletteProxy, _super);
                function RouletteProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                RouletteProxy.prototype.setData = function (value) {
                    if (this.subscribeResponse !== undefined) {
                        this.updateSubscribe(value);
                    }
                    if (value.command === gpts.EMessage.EVENT) {
                        this.game_number = value.gameNumber;
                        if (value.balance !== undefined) {
                            this._facade.balance = value.balance;
                        }
                        if (value.state === "bet") {
                            this._betEventDate = new Date();
                        }
                    }
                    _super.prototype.setData.call(this, value);
                };
                RouletteProxy.prototype.eventHandler = function (event) {
                    switch (event.type) {
                        case gpts.GameEvent.HIDE:
                            BHSlotProxy.cachedData.merge(event.data);
                            this._facade.removeProxy(this.proxyName);
                            break;
                        default:
                            if (event.type == gpts.EMessage.BET) {
                                var bet = event.data.bet;
                                var totalBet = 0;
                                for (var i in bet) {
                                    totalBet += bet[i];
                                }
                                this._facade.balance -= totalBet;
                                this.sendNotification(gpts.AppFacade.UPDATE_BALANCE);
                                var qName = gpts.EMessage.GAME_PACKAGE + this.gameType() + '.bet';
                                var betRequest = new BetRequest(gpts.EMessage.BET, this._facade.sessionKey, parseInt(this.proxyName), this.game_number, bet, qName);
                                this.messages_facade.send(betRequest);
                            }
                            break;
                    }
                };
                RouletteProxy.prototype.updateSubscribeRemainingTime = function () {
                    var now = new Date();
                    var complex = this.subscribeResponse.complex;
                    var currentState = complex.currentState;
                    var stateName = currentState.state;
                    switch (stateName) {
                        case "nmb":
                            currentState.remaining = -1;
                            break;
                        case "bet":
                            var secondsBetweenBetAndShow = Math.abs(now.getTime() - this._betEventDate.getTime()) / 1000;
                            currentState.remaining = currentState.remaining - secondsBetweenBetAndShow;
                            break;
                        case "win":
                            currentState.remaining = -1;
                            break;
                    }
                };
                RouletteProxy.prototype.updateSubscribe = function (value) {
                    if (value.command === "event") {
                        var stateName = value.state;
                        var gameNumber = value.gameNumber;
                        var complex = this.subscribeResponse.complex;
                        var currentState = complex.currentState;
                        currentState.state = stateName;
                        if (stateName === "nmb") {
                            if (this._currBet !== undefined) {
                                complex.history.unshift(this._currBet);
                                complex.history.pop();
                            }
                        }
                        else if (stateName === "bet") {
                            this.subscribeResponse.gameNumber = gameNumber;
                            currentState.remaining = value.remaining;
                            this._currBet = {
                                winNumber: -1,
                                winAmount: 0,
                                playerBet: {},
                                betSum: 0,
                                balance: this._facade.balance,
                            };
                        }
                        else if (stateName === "win" && complex.history[0].winNumber === -1) {
                            currentState.loseBets = value.loseBets;
                            currentState.winNumber = value.winNumber;
                            currentState.winAmount = value.winAmount;
                            currentState.winBets = value.winBets;
                            var bet = {
                                winAmount: value.winAmount,
                                balance: this._facade.balance,
                                winNumber: value.winNumber,
                                betSum: 0,
                                playerBet: {},
                            };
                            for (var slotId in value.winBets) {
                                var chipMoney = value.winBets[slotId];
                                bet.betSum += chipMoney;
                                bet.playerBet[slotId] = chipMoney;
                            }
                            for (var slotId in value.loseBets) {
                                var chipMoney = value.loseBets[slotId];
                                bet.betSum += chipMoney;
                                bet.playerBet[slotId] = chipMoney;
                            }
                            complex.history[0] = bet;
                        }
                    }
                    else if (value.command === "statistics") {
                        this.subscribeResponse.complex.statistics = value.complex;
                    }
                };
                return RouletteProxy;
            }(BHSlotProxy));
            roulette.RouletteProxy = RouletteProxy;
        })(roulette = abstract_games.roulette || (abstract_games.roulette = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var services;
    (function (services) {
        var messages;
        (function (messages) {
            var response;
            (function (response) {
                var roulette;
                (function (roulette) {
                    var RouletteEventResponse = (function (_super) {
                        __extends(RouletteEventResponse, _super);
                        function RouletteEventResponse(command, eventTimestamp, msg, complex, reason, gameIdentificationNumber, gameNumber, state, winAmount, winNumber, winBets, loseBets, remaining, qName) {
                            if (command === void 0) { command = null; }
                            if (eventTimestamp === void 0) { eventTimestamp = -1; }
                            if (msg === void 0) { msg = null; }
                            if (complex === void 0) { complex = null; }
                            if (reason === void 0) { reason = null; }
                            if (gameIdentificationNumber === void 0) { gameIdentificationNumber = null; }
                            if (gameNumber === void 0) { gameNumber = -1; }
                            if (state === void 0) { state = null; }
                            if (winAmount === void 0) { winAmount = -1; }
                            if (winNumber === void 0) { winNumber = -1; }
                            if (winBets === void 0) { winBets = null; }
                            if (loseBets === void 0) { loseBets = null; }
                            if (remaining === void 0) { remaining = -1; }
                            if (qName === void 0) { qName = null; }
                            var _this = _super.call(this, command, eventTimestamp, msg, complex, reason, gameIdentificationNumber, gameNumber, state, winAmount, qName) || this;
                            _this.win_number = winNumber;
                            _this.win_bets = winBets;
                            _this.lose_bets = loseBets;
                            _this._remaining = remaining;
                            return _this;
                        }
                        Object.defineProperty(RouletteEventResponse.prototype, "winNumber", {
                            get: function () {
                                return this.win_number;
                            },
                            set: function (value) {
                                this.win_number = value;
                            },
                            enumerable: true,
                            configurable: true
                        });
                        Object.defineProperty(RouletteEventResponse.prototype, "winBets", {
                            get: function () {
                                return this.win_bets;
                            },
                            set: function (value) {
                                this.win_bets = value;
                            },
                            enumerable: true,
                            configurable: true
                        });
                        Object.defineProperty(RouletteEventResponse.prototype, "loseBets", {
                            get: function () {
                                return this.lose_bets;
                            },
                            set: function (value) {
                                this.lose_bets = value;
                            },
                            enumerable: true,
                            configurable: true
                        });
                        Object.defineProperty(RouletteEventResponse.prototype, "remaining", {
                            get: function () {
                                return this._remaining;
                            },
                            set: function (value) {
                                this._remaining = value;
                            },
                            enumerable: true,
                            configurable: true
                        });
                        RouletteEventResponse.prototype.toString = function () {
                            var result = _super.prototype.toString.call(this);
                            return result.substr(0, result.length - 1).concat(', winNumber: ' + this.win_number + ', winBets: ' + this.win_bets + ', loseBets: ' + this.lose_bets + ', remaining: ' + this._remaining + '}');
                        };
                        return RouletteEventResponse;
                    }(response.GameEventResponse));
                    roulette.RouletteEventResponse = RouletteEventResponse;
                })(roulette = response.roulette || (response.roulette = {}));
            })(response = messages.response || (messages.response = {}));
        })(messages = services.messages || (services.messages = {}));
    })(services = gpts.services || (gpts.services = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var services;
    (function (services) {
        var messages;
        (function (messages) {
            var response;
            (function (response) {
                var roulette;
                (function (roulette) {
                    var RouletteRecoverResponse = (function (_super) {
                        __extends(RouletteRecoverResponse, _super);
                        function RouletteRecoverResponse(command, eventTimestamp, msg, complex, reason, gameIdentificationNumber, gameNumber, gameRecoveryType, winAmount, credit, winNumber, winBets, loseBets, qName) {
                            if (command === void 0) { command = null; }
                            if (eventTimestamp === void 0) { eventTimestamp = -1; }
                            if (msg === void 0) { msg = null; }
                            if (complex === void 0) { complex = null; }
                            if (reason === void 0) { reason = null; }
                            if (gameIdentificationNumber === void 0) { gameIdentificationNumber = null; }
                            if (gameNumber === void 0) { gameNumber = -1; }
                            if (gameRecoveryType === void 0) { gameRecoveryType = null; }
                            if (winAmount === void 0) { winAmount = -1; }
                            if (credit === void 0) { credit = -1; }
                            if (winNumber === void 0) { winNumber = -1; }
                            if (winBets === void 0) { winBets = null; }
                            if (loseBets === void 0) { loseBets = null; }
                            if (qName === void 0) { qName = null; }
                            var _this = _super.call(this, command, eventTimestamp, msg, complex, reason, gameIdentificationNumber, gameNumber, gameRecoveryType, winAmount, credit, qName) || this;
                            _this.win_number = winNumber;
                            _this.win_bets = winBets;
                            _this.lose_bets = loseBets;
                            return _this;
                        }
                        Object.defineProperty(RouletteRecoverResponse.prototype, "winNumber", {
                            get: function () {
                                return this.win_number;
                            },
                            set: function (value) {
                                this.win_number = value;
                            },
                            enumerable: true,
                            configurable: true
                        });
                        Object.defineProperty(RouletteRecoverResponse.prototype, "winBets", {
                            get: function () {
                                return this.win_bets;
                            },
                            set: function (value) {
                                this.win_bets = value;
                            },
                            enumerable: true,
                            configurable: true
                        });
                        Object.defineProperty(RouletteRecoverResponse.prototype, "loseBets", {
                            get: function () {
                                return this.lose_bets;
                            },
                            set: function (value) {
                                this.lose_bets = value;
                            },
                            enumerable: true,
                            configurable: true
                        });
                        RouletteRecoverResponse.prototype.toString = function () {
                            var result = _super.prototype.toString.call(this);
                            return result.substr(0, result.length - 1).concat(', winNumber: ' + this.win_number + ', winBets: ' + this.win_bets + ', loseBets: ' + this.lose_bets + '}');
                        };
                        return RouletteRecoverResponse;
                    }(response.RecoverResponse));
                    roulette.RouletteRecoverResponse = RouletteRecoverResponse;
                })(roulette = response.roulette || (response.roulette = {}));
            })(response = messages.response || (messages.response = {}));
        })(messages = services.messages || (services.messages = {}));
    })(services = gpts.services || (gpts.services = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var services;
    (function (services) {
        var messages;
        (function (messages) {
            var response;
            (function (response) {
                var roulette;
                (function (roulette) {
                    var RouletteSubscribeComplex = (function (_super) {
                        __extends(RouletteSubscribeComplex, _super);
                        function RouletteSubscribeComplex(command, currentState, statistics, history) {
                            if (command === void 0) { command = null; }
                            if (currentState === void 0) { currentState = null; }
                            if (statistics === void 0) { statistics = null; }
                            if (history === void 0) { history = null; }
                            var _this = _super.call(this, command) || this;
                            _this.current_state = currentState || new roulette.RouletteEventResponse();
                            _this._statistics = statistics || {};
                            _this._history = history || [];
                            return _this;
                        }
                        Object.defineProperty(RouletteSubscribeComplex.prototype, "currentState", {
                            get: function () {
                                return this.current_state;
                            },
                            set: function (value) {
                                this.current_state = value;
                            },
                            enumerable: true,
                            configurable: true
                        });
                        Object.defineProperty(RouletteSubscribeComplex.prototype, "statistics", {
                            get: function () {
                                return this._statistics;
                            },
                            set: function (value) {
                                this._statistics = value;
                            },
                            enumerable: true,
                            configurable: true
                        });
                        Object.defineProperty(RouletteSubscribeComplex.prototype, "history", {
                            get: function () {
                                return this._history;
                            },
                            set: function (value) {
                                this._history = value;
                            },
                            enumerable: true,
                            configurable: true
                        });
                        RouletteSubscribeComplex.prototype.toString = function () {
                            return '{currentState: ' + this.currentState + ', statistics: ' + this.statistics + ', history: ' + this._history + '}';
                        };
                        return RouletteSubscribeComplex;
                    }(services.Message));
                    roulette.RouletteSubscribeComplex = RouletteSubscribeComplex;
                })(roulette = response.roulette || (response.roulette = {}));
            })(response = messages.response || (messages.response = {}));
        })(messages = services.messages || (services.messages = {}));
    })(services = gpts.services || (gpts.services = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var services;
    (function (services) {
        var messages;
        (function (messages) {
            var response;
            (function (response) {
                var roulette;
                (function (roulette) {
                    var RouletteSubscribeResponse = (function (_super) {
                        __extends(RouletteSubscribeResponse, _super);
                        function RouletteSubscribeResponse(command, eventTimestamp, msg, complex, reason, gameIdentificationNumber, gameNumber, qName) {
                            if (command === void 0) { command = null; }
                            if (eventTimestamp === void 0) { eventTimestamp = -1; }
                            if (msg === void 0) { msg = null; }
                            if (complex === void 0) { complex = null; }
                            if (reason === void 0) { reason = null; }
                            if (gameIdentificationNumber === void 0) { gameIdentificationNumber = null; }
                            if (gameNumber === void 0) { gameNumber = -1; }
                            if (qName === void 0) { qName = null; }
                            return _super.call(this, command, eventTimestamp, msg, complex instanceof roulette.RouletteSubscribeComplex ? complex : null, reason, gameIdentificationNumber, gameNumber, qName) || this;
                        }
                        return RouletteSubscribeResponse;
                    }(response.GameResponse));
                    roulette.RouletteSubscribeResponse = RouletteSubscribeResponse;
                })(roulette = response.roulette || (response.roulette = {}));
            })(response = messages.response || (messages.response = {}));
        })(messages = services.messages || (services.messages = {}));
    })(services = gpts.services || (gpts.services = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_j_f_j_slot;
        (function (f_j_f_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FJFJSlotMediator = (function (_super) {
                __extends(FJFJSlotMediator, _super);
                function FJFJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FJFJSlotMediator;
            }(BHSlotMediator));
            f_j_f_j_slot.FJFJSlotMediator = FJFJSlotMediator;
        })(f_j_f_j_slot = abstract_games.f_j_f_j_slot || (abstract_games.f_j_f_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_j_f_j_slot;
        (function (f_j_f_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FJFJSlotProxy = (function (_super) {
                __extends(FJFJSlotProxy, _super);
                function FJFJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FJFJSlotProxy;
            }(BHSlotProxy));
            f_j_f_j_slot.FJFJSlotProxy = FJFJSlotProxy;
        })(f_j_f_j_slot = abstract_games.f_j_f_j_slot || (abstract_games.f_j_f_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_h_b_j_slot;
        (function (t_h_b_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var THBJSlotMediator = (function (_super) {
                __extends(THBJSlotMediator, _super);
                function THBJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return THBJSlotMediator;
            }(BHSlotMediator));
            t_h_b_j_slot.THBJSlotMediator = THBJSlotMediator;
        })(t_h_b_j_slot = abstract_games.t_h_b_j_slot || (abstract_games.t_h_b_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var t_h_b_j_slot;
        (function (t_h_b_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var THBJSlotProxy = (function (_super) {
                __extends(THBJSlotProxy, _super);
                function THBJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return THBJSlotProxy;
            }(BHSlotProxy));
            t_h_b_j_slot.THBJSlotProxy = THBJSlotProxy;
        })(t_h_b_j_slot = abstract_games.t_h_b_j_slot || (abstract_games.t_h_b_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var e_o_w_j_slot;
        (function (e_o_w_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var EOWJSlotMediator = (function (_super) {
                __extends(EOWJSlotMediator, _super);
                function EOWJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return EOWJSlotMediator;
            }(BHSlotMediator));
            e_o_w_j_slot.EOWJSlotMediator = EOWJSlotMediator;
        })(e_o_w_j_slot = abstract_games.e_o_w_j_slot || (abstract_games.e_o_w_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var e_o_w_j_slot;
        (function (e_o_w_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var EOWJSlotProxy = (function (_super) {
                __extends(EOWJSlotProxy, _super);
                function EOWJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return EOWJSlotProxy;
            }(BHSlotProxy));
            e_o_w_j_slot.EOWJSlotProxy = EOWJSlotProxy;
        })(e_o_w_j_slot = abstract_games.e_o_w_j_slot || (abstract_games.e_o_w_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var h_s_d_j_slot;
        (function (h_s_d_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var HSDJSlotMediator = (function (_super) {
                __extends(HSDJSlotMediator, _super);
                function HSDJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return HSDJSlotMediator;
            }(BHSlotMediator));
            h_s_d_j_slot.HSDJSlotMediator = HSDJSlotMediator;
        })(h_s_d_j_slot = abstract_games.h_s_d_j_slot || (abstract_games.h_s_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var h_s_d_j_slot;
        (function (h_s_d_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var HSDJSlotProxy = (function (_super) {
                __extends(HSDJSlotProxy, _super);
                function HSDJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return HSDJSlotProxy;
            }(BHSlotProxy));
            h_s_d_j_slot.HSDJSlotProxy = HSDJSlotProxy;
        })(h_s_d_j_slot = abstract_games.h_s_d_j_slot || (abstract_games.h_s_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var b_d_i_j_slot;
        (function (b_d_i_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var BDIJSlotMediator = (function (_super) {
                __extends(BDIJSlotMediator, _super);
                function BDIJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return BDIJSlotMediator;
            }(BHSlotMediator));
            b_d_i_j_slot.BDIJSlotMediator = BDIJSlotMediator;
        })(b_d_i_j_slot = abstract_games.b_d_i_j_slot || (abstract_games.b_d_i_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var b_d_i_j_slot;
        (function (b_d_i_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var BDIJSlotProxy = (function (_super) {
                __extends(BDIJSlotProxy, _super);
                function BDIJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return BDIJSlotProxy;
            }(BHSlotProxy));
            b_d_i_j_slot.BDIJSlotProxy = BDIJSlotProxy;
        })(b_d_i_j_slot = abstract_games.b_d_i_j_slot || (abstract_games.b_d_i_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var r_b_d_j_slot;
        (function (r_b_d_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var RBDJSlotMediator = (function (_super) {
                __extends(RBDJSlotMediator, _super);
                function RBDJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return RBDJSlotMediator;
            }(BHSlotMediator));
            r_b_d_j_slot.RBDJSlotMediator = RBDJSlotMediator;
        })(r_b_d_j_slot = abstract_games.r_b_d_j_slot || (abstract_games.r_b_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var r_b_d_j_slot;
        (function (r_b_d_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var RBDJSlotProxy = (function (_super) {
                __extends(RBDJSlotProxy, _super);
                function RBDJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return RBDJSlotProxy;
            }(BHSlotProxy));
            r_b_d_j_slot.RBDJSlotProxy = RBDJSlotProxy;
        })(r_b_d_j_slot = abstract_games.r_b_d_j_slot || (abstract_games.r_b_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var m_d_j_slot;
        (function (m_d_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var MDJSlotMediator = (function (_super) {
                __extends(MDJSlotMediator, _super);
                function MDJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return MDJSlotMediator;
            }(BHSlotMediator));
            m_d_j_slot.MDJSlotMediator = MDJSlotMediator;
        })(m_d_j_slot = abstract_games.m_d_j_slot || (abstract_games.m_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var m_d_j_slot;
        (function (m_d_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var MDJSlotProxy = (function (_super) {
                __extends(MDJSlotProxy, _super);
                function MDJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return MDJSlotProxy;
            }(BHSlotProxy));
            m_d_j_slot.MDJSlotProxy = MDJSlotProxy;
        })(m_d_j_slot = abstract_games.m_d_j_slot || (abstract_games.m_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_t_j_slot;
        (function (f_t_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FTJSlotMediator = (function (_super) {
                __extends(FTJSlotMediator, _super);
                function FTJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FTJSlotMediator;
            }(BHSlotMediator));
            f_t_j_slot.FTJSlotMediator = FTJSlotMediator;
        })(f_t_j_slot = abstract_games.f_t_j_slot || (abstract_games.f_t_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_t_j_slot;
        (function (f_t_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FTJSlotProxy = (function (_super) {
                __extends(FTJSlotProxy, _super);
                function FTJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FTJSlotProxy;
            }(BHSlotProxy));
            f_t_j_slot.FTJSlotProxy = FTJSlotProxy;
        })(f_t_j_slot = abstract_games.f_t_j_slot || (abstract_games.f_t_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var d_s_j_slot;
        (function (d_s_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var DSJSlotMediator = (function (_super) {
                __extends(DSJSlotMediator, _super);
                function DSJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return DSJSlotMediator;
            }(BHSlotMediator));
            d_s_j_slot.DSJSlotMediator = DSJSlotMediator;
        })(d_s_j_slot = abstract_games.d_s_j_slot || (abstract_games.d_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var d_s_j_slot;
        (function (d_s_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var DSJSlotProxy = (function (_super) {
                __extends(DSJSlotProxy, _super);
                function DSJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return DSJSlotProxy;
            }(BHSlotProxy));
            d_s_j_slot.DSJSlotProxy = DSJSlotProxy;
        })(d_s_j_slot = abstract_games.d_s_j_slot || (abstract_games.d_s_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var a_m_j_slot;
        (function (a_m_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var AMJSlotMediator = (function (_super) {
                __extends(AMJSlotMediator, _super);
                function AMJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return AMJSlotMediator;
            }(BHSlotMediator));
            a_m_j_slot.AMJSlotMediator = AMJSlotMediator;
        })(a_m_j_slot = abstract_games.a_m_j_slot || (abstract_games.a_m_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var a_m_j_slot;
        (function (a_m_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var AMJSlotProxy = (function (_super) {
                __extends(AMJSlotProxy, _super);
                function AMJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return AMJSlotProxy;
            }(BHSlotProxy));
            a_m_j_slot.AMJSlotProxy = AMJSlotProxy;
        })(a_m_j_slot = abstract_games.a_m_j_slot || (abstract_games.a_m_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var r_g_j_slot;
        (function (r_g_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var RGJSlotMediator = (function (_super) {
                __extends(RGJSlotMediator, _super);
                function RGJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return RGJSlotMediator;
            }(BHSlotMediator));
            r_g_j_slot.RGJSlotMediator = RGJSlotMediator;
        })(r_g_j_slot = abstract_games.r_g_j_slot || (abstract_games.r_g_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var r_g_j_slot;
        (function (r_g_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var RGJSlotProxy = (function (_super) {
                __extends(RGJSlotProxy, _super);
                function RGJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return RGJSlotProxy;
            }(BHSlotProxy));
            r_g_j_slot.RGJSlotProxy = RGJSlotProxy;
        })(r_g_j_slot = abstract_games.r_g_j_slot || (abstract_games.r_g_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var c_r_b_j_slot;
        (function (c_r_b_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var CRBJSlotMediator = (function (_super) {
                __extends(CRBJSlotMediator, _super);
                function CRBJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return CRBJSlotMediator;
            }(BHSlotMediator));
            c_r_b_j_slot.CRBJSlotMediator = CRBJSlotMediator;
        })(c_r_b_j_slot = abstract_games.c_r_b_j_slot || (abstract_games.c_r_b_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var c_r_b_j_slot;
        (function (c_r_b_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var CRBJSlotProxy = (function (_super) {
                __extends(CRBJSlotProxy, _super);
                function CRBJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return CRBJSlotProxy;
            }(BHSlotProxy));
            c_r_b_j_slot.CRBJSlotProxy = CRBJSlotProxy;
        })(c_r_b_j_slot = abstract_games.c_r_b_j_slot || (abstract_games.c_r_b_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var i_d_j_slot;
        (function (i_d_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var IDJSlotMediator = (function (_super) {
                __extends(IDJSlotMediator, _super);
                function IDJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return IDJSlotMediator;
            }(BHSlotMediator));
            i_d_j_slot.IDJSlotMediator = IDJSlotMediator;
        })(i_d_j_slot = abstract_games.i_d_j_slot || (abstract_games.i_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var i_d_j_slot;
        (function (i_d_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var IDJSlotProxy = (function (_super) {
                __extends(IDJSlotProxy, _super);
                function IDJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return IDJSlotProxy;
            }(BHSlotProxy));
            i_d_j_slot.IDJSlotProxy = IDJSlotProxy;
        })(i_d_j_slot = abstract_games.i_d_j_slot || (abstract_games.i_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_h_e_j_slot;
        (function (f_h_e_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var FHEJSlotProxy = (function (_super) {
                __extends(FHEJSlotProxy, _super);
                function FHEJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return FHEJSlotProxy;
            }(BHSlotProxy));
            f_h_e_j_slot.FHEJSlotProxy = FHEJSlotProxy;
        })(f_h_e_j_slot = abstract_games.f_h_e_j_slot || (abstract_games.f_h_e_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var f_h_e_j_slot;
        (function (f_h_e_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var FHEJSlotMediator = (function (_super) {
                __extends(FHEJSlotMediator, _super);
                function FHEJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return FHEJSlotMediator;
            }(BHSlotMediator));
            f_h_e_j_slot.FHEJSlotMediator = FHEJSlotMediator;
        })(f_h_e_j_slot = abstract_games.f_h_e_j_slot || (abstract_games.f_h_e_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var a_d_j_slot;
        (function (a_d_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var ADJSlotProxy = (function (_super) {
                __extends(ADJSlotProxy, _super);
                function ADJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return ADJSlotProxy;
            }(BHSlotProxy));
            a_d_j_slot.ADJSlotProxy = ADJSlotProxy;
        })(a_d_j_slot = abstract_games.a_d_j_slot || (abstract_games.a_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var a_d_j_slot;
        (function (a_d_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var ADJSlotMediator = (function (_super) {
                __extends(ADJSlotMediator, _super);
                function ADJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return ADJSlotMediator;
            }(BHSlotMediator));
            a_d_j_slot.ADJSlotMediator = ADJSlotMediator;
        })(a_d_j_slot = abstract_games.a_d_j_slot || (abstract_games.a_d_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var r_l_j_slot;
        (function (r_l_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var RLJSlotMediator = (function (_super) {
                __extends(RLJSlotMediator, _super);
                function RLJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return RLJSlotMediator;
            }(BHSlotMediator));
            r_l_j_slot.RLJSlotMediator = RLJSlotMediator;
        })(r_l_j_slot = abstract_games.r_l_j_slot || (abstract_games.r_l_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var r_l_j_slot;
        (function (r_l_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var RLJSlotProxy = (function (_super) {
                __extends(RLJSlotProxy, _super);
                function RLJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return RLJSlotProxy;
            }(BHSlotProxy));
            r_l_j_slot.RLJSlotProxy = RLJSlotProxy;
        })(r_l_j_slot = abstract_games.r_l_j_slot || (abstract_games.r_l_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var i_v_j_slot;
        (function (i_v_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var IVJSlotMediator = (function (_super) {
                __extends(IVJSlotMediator, _super);
                function IVJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return IVJSlotMediator;
            }(BHSlotMediator));
            i_v_j_slot.IVJSlotMediator = IVJSlotMediator;
        })(i_v_j_slot = abstract_games.i_v_j_slot || (abstract_games.i_v_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var i_v_j_slot;
        (function (i_v_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var IVJSlotProxy = (function (_super) {
                __extends(IVJSlotProxy, _super);
                function IVJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return IVJSlotProxy;
            }(BHSlotProxy));
            i_v_j_slot.IVJSlotProxy = IVJSlotProxy;
        })(i_v_j_slot = abstract_games.i_v_j_slot || (abstract_games.i_v_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var k_h_j_slot;
        (function (k_h_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var KHJSlotMediator = (function (_super) {
                __extends(KHJSlotMediator, _super);
                function KHJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return KHJSlotMediator;
            }(BHSlotMediator));
            k_h_j_slot.KHJSlotMediator = KHJSlotMediator;
        })(k_h_j_slot = abstract_games.k_h_j_slot || (abstract_games.k_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var k_h_j_slot;
        (function (k_h_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var KHJSlotProxy = (function (_super) {
                __extends(KHJSlotProxy, _super);
                function KHJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return KHJSlotProxy;
            }(BHSlotProxy));
            k_h_j_slot.KHJSlotProxy = KHJSlotProxy;
        })(k_h_j_slot = abstract_games.k_h_j_slot || (abstract_games.k_h_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var v_w_j_slot;
        (function (v_w_j_slot) {
            var BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
            var VWJSlotProxy = (function (_super) {
                __extends(VWJSlotProxy, _super);
                function VWJSlotProxy(iData) {
                    return _super.call(this, iData) || this;
                }
                return VWJSlotProxy;
            }(BHSlotProxy));
            v_w_j_slot.VWJSlotProxy = VWJSlotProxy;
        })(v_w_j_slot = abstract_games.v_w_j_slot || (abstract_games.v_w_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var v_w_j_slot;
        (function (v_w_j_slot) {
            var BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
            var VWJSlotMediator = (function (_super) {
                __extends(VWJSlotMediator, _super);
                function VWJSlotMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                return VWJSlotMediator;
            }(BHSlotMediator));
            v_w_j_slot.VWJSlotMediator = VWJSlotMediator;
        })(v_w_j_slot = abstract_games.v_w_j_slot || (abstract_games.v_w_j_slot = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var lottery;
        (function (lottery) {
            var GameEventResponse = gpts.services.messages.response.GameEventResponse;
            var Hash = gamy.Hash;
            var BetRequest = gpts.services.messages.request.BetRequest;
            var ArrayTools = gamy.ArrayTools;
            var LotteryProxy = (function (_super) {
                __extends(LotteryProxy, _super);
                function LotteryProxy(iData) {
                    var _this = _super.call(this, LotteryProxy.cachedData.merge(iData)) || this;
                    _this.game_number = -1;
                    _this._iData.bonusSpins = iData.bonusSpins;
                    return _this;
                }
                LotteryProxy.prototype.eventHandler = function (event) {
                    switch (event.type) {
                        case gpts.GameEvent.HIDE:
                            LotteryProxy.cachedData.merge(event.data);
                            this._facade.removeProxy(this.proxyName);
                            break;
                        default:
                            if (event.type == gpts.EMessage.BET) {
                                this._facade.balance -= event.bet;
                                this.sendNotification(gpts.AppFacade.UPDATE_BALANCE);
                            }
                            this.messages_facade.send(new BetRequest(gpts.EMessage.BET, this._facade.sessionKey, parseInt(this.proxyName), this.game_number, event.data, gpts.EMessage.GAME_PACKAGE + this.gameType() + '.bet.' + event.data.gameCommand));
                            break;
                    }
                };
                LotteryProxy.prototype.handleTimeoutMessage = function (message) {
                    _super.prototype.handleTimeoutMessage.call(this, message);
                    if (!ArrayTools.has(this._facade.subscribeMessagesIds, message.messageId)) {
                        switch (message.command) {
                            case gpts.EMessage.UNSUBSCRIBE:
                                break;
                            case gpts.EMessage.SETTINGS:
                                break;
                            default:
                                this.current_state = gpts.EMessage.FAILURE;
                                this.sendNotification(this.gameType(), new GameEventResponse(gpts.EMessage.EVENT, -1, null, null, gpts.EMessage.REQUEST_TIMEOUT, null, -1, gpts.EMessage.FAILURE));
                                break;
                        }
                    }
                };
                Object.defineProperty(LotteryProxy.prototype, "currentState", {
                    get: function () {
                        return this.current_state;
                    },
                    enumerable: true,
                    configurable: true
                });
                LotteryProxy.prototype.setData = function (value) {
                    if (this.currentState == gpts.EMessage.FAILURE)
                        return;
                    _super.prototype.setData.call(this, value);
                    var message = this.data;
                    switch (message.command) {
                        case gpts.EMessage.SETTINGS:
                            break;
                        case gpts.EMessage.UNSUBSCRIBE:
                            break;
                        default:
                            if (this._facade.gamesRecoveryList[this.proxyName] == gpts.EMessage.PROGRESS_RECOVERY) {
                                if (message.command == gpts.EMessage.SUBSCRIBE) {
                                    this._facade.gamesRecoveryList[this.proxyName] = gpts.EMessage.NO_RECOVERY;
                                    this.subscribe_response = message;
                                }
                            }
                            if (message.command == gpts.EMessage.BET) {
                                this._facade.balance = message.balance;
                                if (this.data.bonusSpins != null) {
                                    var loginBonusSpinsData = this._facade.gamesList[this._iData.gameIdentificationNumber].bonusSpins;
                                    loginBonusSpinsData.remainingBonusSpins = this.data.bonusSpins.remainingBonusSpins;
                                    loginBonusSpinsData.statusCode = this.data.bonusSpins.statusCode;
                                    if (this.data.bonusSpins.statusCode == gpts.EMessage.BONUS_ERROR) {
                                        this._facade.gamesWithBonusesList.forEach(function (key, value) {
                                            value.bonusSpins.remainingBonusSpins = 0;
                                        });
                                    }
                                    gpts.AppFacade.getInstance().dispatchEvent(new gpts.GameEvent(gpts.GameEvent.BONUS_SPINS_CHANGED, this.proxyName));
                                }
                            }
                            if (message.command != gpts.EMessage.EVENT) {
                                this.current_state = (message.command == gpts.EMessage.SUBSCRIBE && message.msg == gpts.EMessage.SUCCESS) ? message.complex.currentState.state : message.state;
                                this.game_number = message.gameNumber;
                            }
                            this.sendNotification(this.gameType(), message);
                            break;
                    }
                };
                Object.defineProperty(LotteryProxy.prototype, "subscribeResponse", {
                    get: function () {
                        return this.subscribe_response;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(LotteryProxy.prototype, "canContinueAfterFailure", {
                    get: function () {
                        return true;
                    },
                    enumerable: true,
                    configurable: true
                });
                LotteryProxy.cachedData = new Hash();
                return LotteryProxy;
            }(abstract_games.GameProxy));
            lottery.LotteryProxy = LotteryProxy;
        })(lottery = abstract_games.lottery || (abstract_games.lottery = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var lottery;
        (function (lottery) {
            var LotteryMediator = (function (_super) {
                __extends(LotteryMediator, _super);
                function LotteryMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                LotteryMediator.prototype.handleNotification = function (notification) {
                    _super.prototype.handleNotification.call(this, notification);
                    var gameProxy = this._facade.retrieveProxy(gpts.Router.getInstance().parameters.gameIdentificationNumber);
                    var data;
                    switch (notification.getName()) {
                        case abstract_games.GameMediator.SHOW + this.mediatorName:
                            data = new abstract_games.GameData(this._facade.balance, gpts.Router.getInstance().language, gameProxy.settings, null, null, !this.messages_facade.connected, gameProxy.iData, this._facade.currency, this._facade.languages, this._facade.currencyISO);
                            data.showRtp = this._facade.showRtp;
                            data.autoplayLimit = this._facade.autoplayLimit;
                            data.minimumSpinTime = this._facade.minimumSpinTime;
                            data.sendTotalsInfo = this._facade.sendTotalsInfo;
                            data.totalBet = this._facade.totalBet;
                            data.totalWin = this._facade.totalWin;
                            if (gameProxy.subscribeResponse)
                                data.merge(gameProxy.subscribeResponse);
                            data.command = abstract_games.GameMediator.SHOW;
                            break;
                    }
                    if ((gameProxy instanceof lottery.LotteryProxy) && notification.getName() == gameProxy.gameType()) {
                        data = new abstract_games.GameData(this._facade.balance);
                        data.merge(notification.getBody());
                    }
                    if (data)
                        abstract_games.DataHandler.set(this.viewComponent, data);
                };
                return LotteryMediator;
            }(abstract_games.GameMediator));
            lottery.LotteryMediator = LotteryMediator;
        })(lottery = abstract_games.lottery || (abstract_games.lottery = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var lotto_five_thirty_five;
        (function (lotto_five_thirty_five) {
            var LotteryProxy = gpts.abstract_games.lottery.LotteryProxy;
            var BetRequest = gpts.services.messages.request.BetRequest;
            var GameRequest = gpts.services.messages.request.GameRequest;
            var LottoFiveThirtyFiveProxy = (function (_super) {
                __extends(LottoFiveThirtyFiveProxy, _super);
                function LottoFiveThirtyFiveProxy(iData) {
                    var _this = _super.call(this, iData) || this;
                    _this._appReady = false;
                    return _this;
                }
                LottoFiveThirtyFiveProxy.prototype.setData = function (value) {
                    if (value.command && value.command === gpts.EMessage.EVENT && value.state === 'BET') {
                        this.game_number = value.gameNumber;
                    }
                    switch (value.command) {
                        case gpts.EMessage.SUBSCRIBE:
                            this.handleSubscribe(value);
                            break;
                        case gpts.EMessage.EVENT:
                            this.handleEvent(value);
                            break;
                        default:
                            this.handleDefaultEvent(value);
                            break;
                    }
                };
                LottoFiveThirtyFiveProxy.prototype.handleSubscribe = function (value) {
                    this._subscribeTime = new Date().getTime();
                    this._startMsg = value;
                    if (this._iData.gameNumber === value.gameNumber) {
                        this._startMsg.complex.currentState.tickets = this._iData.tickets;
                    }
                    else {
                        this._startMsg.complex.currentState.tickets = {};
                    }
                    _super.prototype.setData.call(this, value);
                    if (this._appReady) {
                        this.sendStart();
                    }
                    if (value.complex.currentState.state === 'bet') {
                        this._betEventDate = new Date();
                    }
                };
                LottoFiveThirtyFiveProxy.prototype.handleEvent = function (value) {
                    if (!value.complex) {
                        if (value.gameNumber)
                            this.game_number = value.gameNumber;
                        if (this._startMsg) {
                            var currentState = this._startMsg.complex.currentState;
                            this._startMsg.complex.currentState.state = value.state;
                            switch (value.state) {
                                case 'BET':
                                    {
                                        var remaining = value.remaining, gameNumber = value.gameNumber, eventTimestamp = value.eventTimestamp;
                                        this._betEventDate = new Date();
                                        this._startMsg.gameNumber = gameNumber;
                                        this._startMsg.complex.currentState.remaining = remaining;
                                        this._startMsg.complex.currentState.tickets = {};
                                        this._startMsg.complex.currentState.eventTimestamp = eventTimestamp;
                                    }
                                    break;
                                case 'NMB':
                                    break;
                                case 'DRAW':
                                    {
                                        var winNumber = value.winNumber;
                                        if (currentState.winNumbers)
                                            this._startMsg.complex.currentState.winNumbers = currentState.winNumbers.concat([winNumber]);
                                    }
                                    break;
                                case 'WIN':
                                    {
                                        var winNumber = value.winNumber, winTicketIdsPerLevel = value.winTicketIdsPerLevel, loseTicketIds = value.loseTicketIds, ticketWinPerLevel = value.ticketWinPerLevel, jackpotStatisticsPerLevel = value.jackpotStatisticsPerLevel, jackpotLevels = value.jackpotLevels, balance = value.balance;
                                        this._startMsg.balance = balance;
                                        this._startMsg.jackpotStatisticsPerLevel = jackpotStatisticsPerLevel;
                                        this._startMsg.jackpotLevels = jackpotLevels;
                                        this._startMsg.complex.currentState.winNumber = winNumber;
                                        this._startMsg.complex.currentState.loseTicketIds = loseTicketIds;
                                        this._startMsg.complex.currentState.ticketWinPerLevel = ticketWinPerLevel;
                                        this._startMsg.complex.currentState.winTicketIdsPerLevel = winTicketIdsPerLevel;
                                        if (currentState.winNumbers) {
                                            this._startMsg.complex.currentState.winNumbers = currentState.winNumbers.concat([winNumber]);
                                        }
                                        if (balance) {
                                            this._facade.balance = balance;
                                        }
                                    }
                                    break;
                            }
                        }
                        else {
                            this._facade.balance = value.balance;
                            _super.prototype.setData.call(this, value);
                        }
                    }
                    else {
                        _super.prototype.setData.call(this, value);
                    }
                };
                LottoFiveThirtyFiveProxy.prototype.handleDefaultEvent = function (value) {
                    if (value.command === gpts.EMessage.EVENT && value.state === 'WIN' && value.balance) {
                        this._facade.balance = value.balance;
                    }
                    _super.prototype.setData.call(this, value);
                };
                LottoFiveThirtyFiveProxy.prototype.clearStartMsg = function () {
                    this._startMsg = undefined;
                };
                LottoFiveThirtyFiveProxy.prototype.sendStart = function () {
                    this.sendNotification('startLottoFiveThirtyFive', this._startMsg);
                };
                LottoFiveThirtyFiveProxy.prototype.eventHandler = function (event) {
                    switch (event.type) {
                        case gpts.GameEvent.HIDE:
                            LotteryProxy.cachedData.merge(event.data);
                            this._facade.removeProxy(this.proxyName);
                            break;
                        default:
                            if (event.type == gpts.EMessage.BET) {
                                var qName = gpts.EMessage.GAME_PACKAGE + this.gameType() + '.bet';
                                var gameNumber = this.game_number;
                                var betRequest = new BetRequest(gpts.EMessage.BET, this._facade.sessionKey, parseInt(this.proxyName), gameNumber, event.data.bet, qName);
                                this.messages_facade.send(betRequest);
                            }
                            if (event.type === gpts.EMessage.HISTORY) {
                                var qName = gpts.EMessage.GAME_PACKAGE + this.gameType() + '.history';
                                var gameNumber = this.game_number;
                                var historyRequest = new GameRequest(gpts.EMessage.HISTORY, this._facade.sessionKey, parseInt(this.proxyName), gameNumber, qName);
                                this.messages_facade.send(historyRequest);
                            }
                            if (event.type === gpts.EMessage.STATISTICS) {
                                var qName = gpts.EMessage.GAME_PACKAGE + this.gameType() + '.statistics';
                                var gameNumber = this.game_number;
                                var statisticsRequest = new GameRequest(gpts.EMessage.STATISTICS, this._facade.sessionKey, parseInt(this.proxyName), gameNumber, qName);
                                this.messages_facade.send(statisticsRequest);
                            }
                            break;
                    }
                };
                LottoFiveThirtyFiveProxy.prototype.startGame = function () {
                    this._appReady = true;
                    if (this._startMsg) {
                        var resourcesEndLoadingTime = new Date().getTime();
                        var resourcesLoadingTime = resourcesEndLoadingTime - this._subscribeTime;
                        if (this.currentState === 'BET')
                            this._startMsg.complex.currentState.remaining -= resourcesLoadingTime;
                        this.sendStart();
                    }
                };
                return LottoFiveThirtyFiveProxy;
            }(LotteryProxy));
            lotto_five_thirty_five.LottoFiveThirtyFiveProxy = LottoFiveThirtyFiveProxy;
        })(lotto_five_thirty_five = abstract_games.lotto_five_thirty_five || (abstract_games.lotto_five_thirty_five = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var abstract_games;
    (function (abstract_games) {
        var lotto_five_thirty_five;
        (function (lotto_five_thirty_five) {
            var LotteryMediator = gpts.abstract_games.lottery.LotteryMediator;
            var LottoFiveThirtyFiveMediator = (function (_super) {
                __extends(LottoFiveThirtyFiveMediator, _super);
                function LottoFiveThirtyFiveMediator(gameType) {
                    return _super.call(this, gameType) || this;
                }
                LottoFiveThirtyFiveMediator.prototype.listNotificationInterests = function () {
                    return _super.prototype.listNotificationInterests.call(this).concat([
                        'startLottoFiveThirtyFive',
                    ]);
                };
                LottoFiveThirtyFiveMediator.prototype.handleNotification = function (note) {
                    var noteName = note.getName();
                    var lottoProxy = this._facade.retrieveProxy(gpts.Router.getInstance().parameters.gameIdentificationNumber);
                    if (noteName === 'startLottoFiveThirtyFive') {
                        var startMsg = note.getBody();
                        var data = new abstract_games.GameData(this._facade.balance);
                        data.iData = lottoProxy.iData;
                        data.merge(startMsg);
                        data.command = 'start';
                        abstract_games.DataHandler.set(this.viewComponent, data);
                        lottoProxy.clearStartMsg();
                    }
                    _super.prototype.handleNotification.call(this, note);
                };
                return LottoFiveThirtyFiveMediator;
            }(LotteryMediator));
            lotto_five_thirty_five.LottoFiveThirtyFiveMediator = LottoFiveThirtyFiveMediator;
        })(lotto_five_thirty_five = abstract_games.lotto_five_thirty_five || (abstract_games.lotto_five_thirty_five = {}));
    })(abstract_games = gpts.abstract_games || (gpts.abstract_games = {}));
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var MobileView = egtLibrary.MobileView;
    var DeviceOrientation = egtLibrary.DeviceOrientation;
    var StageInfo = (function () {
        function StageInfo() {
        }
        Object.defineProperty(StageInfo, "isTallDevice", {
            get: function () {
                var w = screen.width;
                var h = screen.height;
                if (w > h) {
                    w = h + ((h = w), 0);
                }
                return Math.round((w / h) * 1e2) / 1e2 <= 0.49;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(StageInfo, "width", {
            get: function () {
                if (MINI) {
                    return StageInfo.MiniWidth;
                }
                else if (MOB) {
                    if (MobileView.deviceOrientation === DeviceOrientation.Landscape) {
                        if (StageInfo.isTallDevice) {
                            return StageInfo.MobWidthIPhoneX;
                        }
                        return StageInfo.MobWidth;
                    }
                    else {
                        return StageInfo.MobHeight;
                    }
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(StageInfo, "height", {
            get: function () {
                if (MINI) {
                    return StageInfo.MiniHeight;
                }
                else if (MOB) {
                    if (MobileView.deviceOrientation === DeviceOrientation.Landscape) {
                        return StageInfo.MobHeight;
                    }
                    else {
                        if (StageInfo.isTallDevice) {
                            return StageInfo.MobWidthIPhoneX - 91;
                        }
                        return StageInfo.MobWidth;
                    }
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(StageInfo, "visibleWidth", {
            get: function () {
                if (MINI) {
                    return StageInfo.MiniWidth;
                }
                else if (MOB) {
                    if (MobileView.deviceOrientation === DeviceOrientation.Landscape) {
                        return StageInfo.MobWidth;
                    }
                    else {
                        return StageInfo.MobHeight;
                    }
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(StageInfo, "visibleHeight", {
            get: function () {
                if (MINI) {
                    return StageInfo.MiniWidth;
                }
                else if (MOB) {
                    if (MobileView.deviceOrientation === DeviceOrientation.Landscape) {
                        return StageInfo.MobWidth;
                    }
                    else {
                        return StageInfo.MobHeight;
                    }
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(StageInfo, "landscapeWidth", {
            get: function () {
                return;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(StageInfo, "landscapeHeight", {
            get: function () {
                return;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(StageInfo, "landscapeVisibleWidth", {
            get: function () {
                return;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(StageInfo, "landscapeVisibleHeight", {
            get: function () {
                return;
            },
            enumerable: true,
            configurable: true
        });
        StageInfo.MiniWidth = 286;
        StageInfo.MiniHeight = 355;
        StageInfo.MobWidth = 960;
        StageInfo.MobHeight = 540;
        StageInfo.MobWidthIPhoneX = 1170;
        return StageInfo;
    }());
    gpts.StageInfo = StageInfo;
})(gpts || (gpts = {}));
var gpts;
(function (gpts) {
    var UncaughtErrorsHandler = egtLibrary.UncaughtErrorsHandler;
    var ErrorSerializer = egtLibrary.ErrorSerializer;
    var LogServer = egtLibrary.logserver.LogServer;
    var trace = gamy.trace;
    var Hash = gamy.Hash;
    var JSONLoader = gamy.JSONLoader;
    var LoaderEvent = gamy.LoaderEvent;
    var Capabilities = gamy.Capabilities;
    var OperatingSystem = gamy.OperatingSystem;
    var Main = (function () {
        function Main(options) {
            if (options === void 0) { options = null; }
            var _this = this;
            options = new Hash({
                sessionKey: "INT:EUR:5000000:IPC:taenagent",
                tcpHost: "wss://mgs-demo.egtmgs.com",
                tcpPort: 8095,
                lang: "en",
            }).merge(options);
            trace("tcp host: " + options.tcpHost);
            trace("tcp port: " + options.tcpPort);
            gpts.Router.getInstance().language = options.lang;
            gpts.Alert.init();
            var appFacade = gpts.AppFacade.getInstance();
            appFacade.sessionKey = options.sessionKey;
            appFacade.tcpHost = options.tcpHost;
            appFacade.tcpPort = options.tcpPort;
            appFacade.gameIdentificationNumber = options.has("gameIdentificationNumber")
                ? parseInt(options.gameIdentificationNumber)
                : -1;
            appFacade.doesOperatorAddWinToBalanceDuringBonusSpins = options.doesOperatorAddWinToBalanceDuringBonusSpins;
            var jsonLoader = new JSONLoader("content.json", {
                name: Main.CONTENT,
                query: {
                    build: BUILD,
                },
            });
            jsonLoader.addEventListener(LoaderEvent.COMPLETE, function () {
                var operatingSystem = Capabilities.operatingSystem;
                if (MOB && (operatingSystem != OperatingSystem.android && operatingSystem != OperatingSystem.iOS)) {
                    gpts.Router.getInstance().redirectTo(gpts.Router.SESSION_CLOSED_PAGE, { reason: gpts.EMessage.USE_MOBILE_DEVICES });
                }
                else {
                    appFacade.registerProxy(new gpts.SocketProxy(options.testServer, options.login, options.scenario));
                }
                if (DEBUG) {
                    new gpts.DebugCode();
                    if (options.errorID)
                        new gpts.ErrorTest(options.errorID);
                }
                var hostname = window.location.hostname.toLowerCase();
                var isLocalHost = hostname.indexOf("localhost") !== -1 || hostname.indexOf("127.0.0.1") !== -1;
                if (!isLocalHost) {
                    _this.handleUncaughtErrors();
                }
            });
            gpts.Router.getInstance().redirectTo(gpts.Router.LOADING_PAGE);
            jsonLoader.load();
        }
        Main.prototype.handleUncaughtErrors = function () {
            this._handleError = new UncaughtErrorsHandler(this.onUncaughtError, true);
        };
        Main.prototype.sendStatisticUsage = function () {
            var playerName;
            try {
                playerName = gpts.AppFacade.getInstance().playerName.toString();
            }
            catch (e) {
            }
            LogServer.sendStatisticUsage({ playerName: playerName });
        };
        Main.prototype.onUncaughtError = function (e) {
            var projectName;
            var projectBuild;
            var additional = {
                userAgent: window.navigator.userAgent,
                playerName: gpts.AppFacade.getInstance().playerName.toString(),
            };
            var allowedErrorOrigins = [
                "mobile-base-slot.min.js",
                "Game.min.js",
                "game.min.js",
                "gpts.min.js",
                "egt-library",
                "gamy.min.js",
                "pixi.js",
                "pixi.min.js",
            ];
            var serializedError;
            var shouldSendError;
            try {
                serializedError = ErrorSerializer.Serialize(e instanceof ErrorEvent ? e : e.error);
            }
            catch (failedSerializationError) {
                var message = e.message || (e.error ? e.error.message : null);
                var stack = e.stack || (e.error ? e.error.stack : null);
                serializedError = {
                    message: message,
                    stack: stack,
                };
                try {
                    additional.failedSerializationError = ErrorSerializer.Serialize(failedSerializationError);
                }
                catch (_a) {
                }
            }
            if (e instanceof ErrorEvent) {
                if (!egtLibrary.logserver.projectMetadata || serializedError.filename.indexOf("gpts.min.js") !== -1) {
                    projectName = "GamePlatform";
                    projectBuild = VERSION;
                }
            }
            shouldSendError = allowedErrorOrigins.some(function (origin) {
                return serializedError[e instanceof ErrorEvent ? "filename" : "stack"].indexOf(origin) !== -1
                    ? true
                    : false;
            });
            if (shouldSendError) {
                LogServer.sendError({ projectName: projectName, projectBuild: projectBuild, additional: additional, error: serializedError });
            }
        };
        Main.PLATFORM = "Platform";
        Main.CONTENT = "Content";
        Main.GAME_INTERFACE = "GameInterface";
        Main.CANVAS_ID = "gpts";
        Main.EGT = "EGT";
        return Main;
    }());
    gpts.Main = Main;
    function environmentString() {
        switch (environment()) {
            case Environment.desktop:
                return "desktop";
            case Environment.mini:
                return "mini";
            case Environment.mobile:
                return "mobile";
        }
        return "unknown";
    }
    var Environment;
    (function (Environment) {
        Environment[Environment["desktop"] = 0] = "desktop";
        Environment[Environment["mobile"] = 1] = "mobile";
        Environment[Environment["mini"] = 2] = "mini";
    })(Environment = gpts.Environment || (gpts.Environment = {}));
    function environment() {
        if (MOB) {
            return Environment.mobile;
        }
        if (MINI) {
            return Environment.mini;
        }
        return Environment.desktop;
    }
    gpts.environment = environment;
})(gpts || (gpts = {}));
//# sourceMappingURL=gpts.js.map