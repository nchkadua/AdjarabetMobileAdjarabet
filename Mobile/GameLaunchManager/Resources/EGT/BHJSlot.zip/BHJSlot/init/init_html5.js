var params = {
	menu: "false",
	allowFullscreen: "true",
	allowScriptAccess: "always",
	bgcolor: "#000000",
	allowFullScreenInteractive: "true",
	wmode: "opaque"
};

var gptsInit = {
    loadScript: function (src, onComplete, query) {
        // with script injection, async is true by default
        var script = document.createElement('script');
        script.onload = onComplete
        script.setAttribute('src', src + this.getQueryString(query));
        document.head.appendChild(script);
    },
    loadQueue: function (srcs, onComplete) {
        var length = srcs.length
        var loadedCount = 0
        for (var i = 0; i < length; i++) {
            if (typeof srcs[i] == 'string')
                srcs[i] = {src: srcs[i]}
            gptsInit.loadScript(srcs[i].src, function () {
                loadedCount++
                if (loadedCount == length) onComplete()
            }, srcs[i].query)
        }
    },
    getParameterBy: function (name, url) {
        if (!url) {
            url = window.location.href;
        }
        name = name.replace(/[\[\]]/g, "\\$&");
        var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, " "));
    },
    loadCSS: function (src, onComplete, query) {
        var css = document.createElement('link');
        css.onload = onComplete
        css.setAttribute('href', src + this.getQueryString(query));
        css.setAttribute("rel", "stylesheet")
        css.setAttribute("type", "text/css")
        document.head.appendChild(css);
    },
    getQueryString: function (query) {
        if (query == undefined)
            return ''
        var queryString = '?'
        for (var name in query)
            queryString += name + '=' + query[name] + '&'
        return queryString.substr(0, queryString.length - 1)
    },
    loadQueues: function (srcs, onComplete) {
        var length = srcs.length
        var counter = 0
        var that = this

        function onCompleteLoadingQueue() {
            if (counter == length)
                onComplete()
            else that.loadQueue(srcs[counter], onCompleteLoadingQueue)
            counter++
        }

        onCompleteLoadingQueue()
    }
}

function initFlash(initFlashvars, initParams) {

	$.extend(params, initParams);

	addHTML();

    // validate get parameters; used for debug purpose only
    var lang = gptsInit.getParameterBy('l');
    var gameIdentificationNumber = parseInt(gptsInit.getParameterBy('gin'));
    var playerName = gptsInit.getParameterBy('pn');
    var currency = gptsInit.getParameterBy('c');
    var balance = parseInt(gptsInit.getParameterBy('b'));

    if (lang == null || lang == '') lang = 'en'
    if (isNaN(gameIdentificationNumber)) gameIdentificationNumber = -1//-1//801//520
    if (playerName == null || playerName == '') playerName = new Date().getTime()
    if (currency == null || currency == '') currency = 'EUR';
    if (isNaN(balance)) balance = 5000000;
    // end

    gptsInit.loadScript('options.js', function () {
        gptsInit.loadCSS('platform.css', function () {
            gptsInit.loadQueues(gptsOptions.queues, function () {
                gpts.start(function () {
                    // Place here socket options, etc.
                    new gpts.Main({
                        sessionKey: initParams.sessionKey,
                        tcpHost: 'wss://' + initParams.tcpHost,
                        tcpPort: initParams.tcpPort,
                        lang: initParams.lang,
                        gameIdentificationNumber: initParams.gameIdentificationNumber
                    })
                })
            })
        }, {build: gptsOptions.build})
    }, {gyCacheBusterID: new Date().getTime()})
}

function addHTML() {
	$("#flashContent").remove();

    var content = $('\
			<div id="content">\n' +
        '        <div id="gpts"></div>\n' +
        '        <div id="sessionClosed">\n' +
        '        <div id="sessionClosedLabel"></div>\n' +
        '        </div>\n' +
        '        <div class="alert"></div>\n' +
        '        </div>');

    $("body").prepend(content);
}

// function closePopup() {
// 	window.parent.postMessage({ command: 'com.egt-bg.exit' }, '*')
//
// 	if (window.parent && window.parent['onExitGamePlatformEGT'])
// 		window.parent['onExitGamePlatformEGT'].call()
// 	else {
// 		// Executes the default logic on exit, which uses popup instead of an iframe
// 		top.window.close()
// 	}
// }