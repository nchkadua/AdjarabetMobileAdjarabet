var gptsInit = {
	loadScript: function (src, onComplete, query) {
		// with script injection, async is true by default
		var script = document.createElement('script');
		script.onload = onComplete
		script.setAttribute('src', src + this.getQueryString(query));
		document.head.appendChild(script);
	},
	loadQueue: function (srcs, onComplete) {
		var length = srcs.length
		var loadedCount = 0
		for (var i = 0; i < length; i++) {
			if (typeof srcs[i] == 'string')
				srcs[i] = {src: srcs[i]}
			gptsInit.loadScript(srcs[i].src, function () {
				loadedCount++
				if (loadedCount == length) onComplete()
			}, srcs[i].query)
		}
	},
	getParameterBy: function (name, url) {
		if (!url) {
			url = window.location.href;
		}
		name = name.replace(/[\[\]]/g, "\\$&");
		var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
				results = regex.exec(url);
		if (!results) return null;
		if (!results[2]) return '';
		return decodeURIComponent(results[2].replace(/\+/g, " "));
	},
	loadCSS: function (src, onComplete, query) {
		var css = document.createElement('link');
		css.onload = onComplete
		css.setAttribute('href', src + this.getQueryString(query));
		css.setAttribute("rel", "stylesheet")
		css.setAttribute("type", "text/css")
		document.head.appendChild(css);
	},
	getQueryString: function (query) {
		if (query == undefined)
			return ''
		var queryString = '?'
		for (var name in query)
			queryString += name + '=' + query[name] + '&'
		return queryString.substr(0, queryString.length - 1)
	},
	loadQueues: function (srcs, onComplete) {
		var length = srcs.length
		var counter = 0
		var that = this

		function onCompleteLoadingQueue() {
			if (counter == length)
				onComplete()
			else that.loadQueue(srcs[counter], onCompleteLoadingQueue)
			counter++
		}

		onCompleteLoadingQueue()
	}
}

function initDesktopHtml(params) {
	// TODO: the schema should be provided by the server
	params.tcpHost = "wss://" + params.tcpHost;

	gptsInit.loadScript('options.js', function () {
		gptsInit.loadCSS('platform.css', function () {
			gptsInit.loadQueues(gptsOptions.queues, function () {
				// Place here socket options, etc.
				new gpts.Main(params)
			})
		}, {build: gptsOptions.build})
	}, {gyCacheBusterID: new Date().getTime()})
}