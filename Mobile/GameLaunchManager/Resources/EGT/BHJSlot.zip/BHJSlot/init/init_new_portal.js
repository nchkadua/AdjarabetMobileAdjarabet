var gptsInit = {
    loadScript: function(src, onComplete, query) {
        // with script injection, async is true by default
        var script = document.createElement("script");
        script.onload = onComplete;
        script.setAttribute("src", src + this.getQueryString(query));
        var head = document.getElementsByTagName("head")[0];
        head.appendChild(script);
    },
    loadQueue: function(srcs, onComplete) {
        var length = srcs.length;
        var loadedCount = 0;
        for (var i = 0; i < length; i++) {
            if (typeof srcs[i] == "string") srcs[i] = { src: srcs[i] };
            gptsInit.loadScript(
                srcs[i].src,
                function() {
                    loadedCount++;
                    if (loadedCount == length) onComplete();
                },
                srcs[i].query
            );
        }
    },
    getParameterBy: function(name, url) {
        if (!url) {
            url = window.location.href;
        }
        name = name.replace(/[\[\]]/g, "\\$&");
        var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return "";
        return decodeURIComponent(results[2].replace(/\+/g, " "));
    },
    loadCSS: function(src, onComplete, query) {
        var css = document.createElement("link");
        css.onload = onComplete;
        css.setAttribute("href", src + this.getQueryString(query));
        css.setAttribute("rel", "stylesheet");
        css.setAttribute("type", "text/css");
        var head = document.getElementsByTagName("head")[0];
        head.appendChild(css);
    },
    getQueryString: function(query) {
        if (query == undefined) return "";
        var queryString = "?";
        for (var name in query) queryString += name + "=" + query[name] + "&";
        return queryString.substr(0, queryString.length - 1);
    },
    loadQueues: function(srcs, onComplete) {
        var length = srcs.length;
        var counter = 0;
        var that = this;

        function onCompleteLoadingQueue() {
            if (counter == length) onComplete();
            else that.loadQueue(srcs[counter], onCompleteLoadingQueue);
            counter++;
        }

        onCompleteLoadingQueue();
    },
};

function closePopup() {
    window.focus();

    window.parent.postMessage({ command: "com.egt-bg.exit" }, "*");

    top.window.close();

    var closeUrl = gptsInit.getParameterBy("closeurl");
    if (closeUrl == "com.egt-bg.postMessage") window.parent.postMessage({ command: "com.egt-bg.exit" }, "*");
    else if (closeUrl == "") window.close();
    else document.location.href = closeUrl;
}

function reloadGame() {
    window.parent.postMessage({ command: "com.egt-bg.reload" }, "*");
}

function initDesktopHtml(params) {
    var base = $(
        '<div id="root"></div>'
    );

    // TODO: the schema should be provided by the server
    params.tcpHost = "wss://" + params.tcpHost;
    params.tcpPort = "8095";

    window.reactBridge = {onOptionsReady: null}; 
 
    gptsInit.loadQueues([["lib/pixi.min.js"], ["lib/pixi-layers.js"], ["lib/bottle.min.js"],
        ["lib/egt-library.min.js"], ["lib/sha1.min.js"], ["lib/game-platform.js"],
        ["./static/js/2.dbd7640c.chunk.js"], ["./static/js/main.0edff9b1.chunk.js"]], function () {
        gptsInit.loadCSS("./static/css/main.259084f3.chunk.css", function () {
            $("body").append(base);

            !function (e) {
                function r(r) {
                    for (var n, l, a = r[0], f = r[1], p = r[2], c = 0, s = []; c < a.length; c++) l = a[c], Object.prototype.hasOwnProperty.call(o, l) && o[l] && s.push(o[l][0]), o[l] = 0;
                    for (n in f) Object.prototype.hasOwnProperty.call(f, n) && (e[n] = f[n]);
                    for (i && i(r); s.length;) s.shift()();
                    return u.push.apply(u, p || []), t()
                }

                function t() {
                    for (var e, r = 0; r < u.length; r++) {
                        for (var t = u[r], n = !0, a = 1; a < t.length; a++) {
                            var f = t[a];
                            0 !== o[f] && (n = !1)
                        }
                        n && (u.splice(r--, 1), e = l(l.s = t[0]))
                    }
                    return e
                }

                var n = {}, o = {1: 0}, u = [];

                function l(r) {
                    if (n[r]) return n[r].exports;
                    var t = n[r] = {i: r, l: !1, exports: {}};
                    return e[r].call(t.exports, t, t.exports, l), t.l = !0, t.exports
                }

                l.m = e, l.c = n, l.d = function (e, r, t) {
                    l.o(e, r) || Object.defineProperty(e, r, {enumerable: !0, get: t})
                }, l.r = function (e) {
                    "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {value: "Module"}), Object.defineProperty(e, "__esModule", {value: !0})
                }, l.t = function (e, r) {
                    if (1 & r && (e = l(e)), 8 & r) return e;
                    if (4 & r && "object" == typeof e && e && e.__esModule) return e;
                    var t = Object.create(null);
                    if (l.r(t), Object.defineProperty(t, "default", {
                        enumerable: !0,
                        value: e
                    }), 2 & r && "string" != typeof e) for (var n in e) l.d(t, n, function (r) {
                        return e[r]
                    }.bind(null, n));
                    return t
                }, l.n = function (e) {
                    var r = e && e.__esModule ? function () {
                        return e.default
                    } : function () {
                        return e
                    };
                    return l.d(r, "a", r), r
                }, l.o = function (e, r) {
                    return Object.prototype.hasOwnProperty.call(e, r)
                }, l.p = "./";
                var a = this["webpackJsonpgame-platform"] = this["webpackJsonpgame-platform"] || [], f = a.push.bind(a);
                a.push = r, a = a.slice();
                for (var p = 0; p < a.length; p++) r(a[p]);
                var i = f;
                t()
            }([])

            reactBridge.options = params
            reactBridge.onOptionsReady()
        })
    })
}
