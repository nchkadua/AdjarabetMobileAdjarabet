var loadersCount = 0;

var params = {
	menu: "false",
	allowFullscreen: "true",
	allowScriptAccess: "always",
	bgcolor: "#000000",
	allowFullScreenInteractive: "true",
	wmode: "opaque"
};

var flashvars = {
	content: 'assets/content.xml'
};

var platformVersion = -1;

function initFlash(initFlashvars, initParams) {
	
	$.extend(flashvars, initFlashvars);
	$.extend(params, initParams);

	var style = $("<link>", {
		rel: 'stylesheet',
		type: 'text/css',
		href: 'init/style.css'
	});

	style[0].onload = onLoadingComplete;
	
	style.appendTo("head");

	$.ajax({
		type: "GET",
		crossDomain: "false",
		url: "js/swfobject.js",
		dataType: "script",
		cache: true,
		success: onLoadingComplete
	});
	
	$.ajax({
		type: "GET",
		crossDomain: "false",
		url: "options.xml",
		dataType: "xml",
		cache: false,
		success: function (xml) {

			// Parse the xml file and get data
			$xml = $(xml);
			platformVersion = $xml.find('GamePlatform').attr("version");
			
			onLoadingComplete();
		}
	});
}

function closePopup() {   
	window.parent.postMessage({ command: 'com.egt-bg.exit' }, '*')
	
	if (window.parent && window.parent['onExitGamePlatformEGT']) 
		window.parent['onExitGamePlatformEGT'].call()
	else {
		// Executes the default logic on exit, which uses popup instead of an iframe
		top.window.close()
	}
}

function startFlash() {
	var version = swfobject.getFlashPlayerVersion();
	if(version.major < 11 || (version.major == 11 && version.minor < 1)) {
		var error = $('\
			<div class="com_egt_flashPlayerDetect">\
				<div class="com_egt_verticalAlignContainer">\
					<div class="com_egt_innerContanier">\
						<div class="com_egt_rectangle">\
							<h1 class="com_egt_text com_egt_title">Please, enable Adobe Flash Player to continue.</h1>\
							<h5 class="com_egt_text com_egt_clarification">To enable/download Adobe Flash Player,<br/>please press the "START" button.</h5>\
						</div>\
						<div class="com_egt_start_button_div">\
							<a class="com_egt_start_button_a" rel="external" target="_blank" href="http://www.adobe.com/go/getflash/">START</a>\
						</div>\
					</div>\
				</div>\
			</div>');
		$("body").prepend(error);
		$("#flashContent").hide();
	} else {
		var flashContent = $("<div id='flashContent'></div>");
		$("body").append(flashContent);
		swfobject.embedSWF("GamePlatform.swf?v=" + platformVersion, "flashContent", "100%", "100%", "11.1", "expressInstall.swf", flashvars, params, {
			id:"GamePlatform"
		});
	}
}

function onLoadingComplete() {
	loadersCount++;
	if(loadersCount == 3) {
		startFlash();
	}
}