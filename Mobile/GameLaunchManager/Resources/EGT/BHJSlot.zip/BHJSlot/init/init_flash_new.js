var loadersCount = 0;

var params = {
	menu: "false",
	allowFullscreen: "true",
	allowScriptAccess: "always",
	bgcolor: "#000000",
	allowFullScreenInteractive: "true",
	wmode: "direct"
};

var flashvars = {
	content: 'assets/content.xml'
};

var platformVersion = -1;

function initFlash(initFlashvars, initParams) {
	
	$.extend(flashvars, initFlashvars);
	$.extend(params, initParams);

	var gin = parseInt(params.gameIdentificationNumber);

    if(isNaN(gin) || gin == -1) {
    	loadHTML5();
	} else {
        $.ajax({
            type: "GET",
            crossDomain: "false",
            url: "html5/options.js",
            dataType: "script",
            cache: false,
            success: function () {
				if(gptsOptions.supportedGames.indexOf(gin) == -1)
					loadFlash();
				else
					loadHTML5();
            }
        });
    }
}

function loadFlash() {
    var style = $("<link>", {
        rel: 'stylesheet',
        type: 'text/css',
        href: 'init/style.css'
    });

    style[0].onload = onLoadingComplete;

    style.appendTo("head");

    $.ajax({
        type: "GET",
        crossDomain: "false",
        url: "js/swfobject.js",
        dataType: "script",
        cache: true,
        success: onLoadingComplete
    });

    $.ajax({
        type: "GET",
        crossDomain: "false",
        url: "options.xml",
        dataType: "xml",
        cache: false,
        success: function (xml) {

            // Parse the xml file and get data
            $xml = $(xml);
            platformVersion = $xml.find('GamePlatform').attr("build");

            onLoadingComplete();
        }
    });
}

function loadHTML5() {
	$("#flashContent").remove();
	var prev = $("base")[0].href;
	$("base").remove();

	setTimeout(function() {
        var baseTag = $("<base>");
        baseTag[0].href = prev + "html5";
        $("head").prepend(baseTag);

        var htmlElements = $('\
		<div id="content">\
    		<div id="gpts"></div>\
        	<div id="sessionClosed">\
        		<div id="sessionClosedLabel"></div>\
        	</div>\
        	<div class="alert"></div>\
        </div>');

        $("body").prepend(htmlElements);

        params.tcpPort = "8095";

        setTimeout(function() {
            $.ajax({
                type: "GET",
                crossDomain: "false",
                url: "../init/init_desktop_html.js",
                dataType: "script",
                cache: false,
                success: function () {
                    initDesktopHtml(params);
                }
            });
        }, 5000);
    }, 5000);

    //document.write("<base href='"+baseTag.href + "html5"+"' />");


}

function closePopup() {   
	try {
		if (window.parent && window.parent['onExitGamePlatformEGT']) 
			window.parent['onExitGamePlatformEGT'].call()
		else {
			// Executes the default logic on exit, which uses popup instead of an iframe
			top.window.close()
		}
	}
	catch(error) {
		// in case of different domans for iframe and original hosting the error is not traced in the chrome's dev tool(in mozilla it is fine)
		window.parent.postMessage({ command: 'com.egt-bg.exit' }, '*')
	}
}

function startFlash() {
	var version = swfobject.getFlashPlayerVersion();
	if(version.major < 11 || (version.major == 11 && version.minor < 1)) {
		var error = $('\
			<div class="com_egt_flashPlayerDetect">\
				<div class="com_egt_verticalAlignContainer">\
					<div class="com_egt_innerContanier">\
						<div class="com_egt_rectangle">\
							<h1 class="com_egt_text com_egt_title">Please, enable Adobe Flash Player to continue.</h1>\
							<h5 class="com_egt_text com_egt_clarification">To enable/download Adobe Flash Player,<br/>please press the "START" button.</h5>\
						</div>\
						<div class="com_egt_start_button">START</div>\
					</div>\
				</div>\
			</div>');
		$("body").prepend(error);
		$(".com_egt_start_button").on("click", function() {
			location.href = "https://get.adobe.com/flashplayer/?no_redirect";
		});
		$("#flashContent").hide();
	} else {
		swfobject.embedSWF("GamePlatform.swf?v=" + platformVersion, "flashContent", "100%", "100%", "11.1", "expressInstall.swf", flashvars, params, {
			id:"GamePlatform"
		});
	}
}

function onLoadingComplete() {
	loadersCount++;
	if(loadersCount == 3) {
		startFlash();
	}
}