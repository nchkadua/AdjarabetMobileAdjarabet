/// <reference path="../node_modules/pixi-layers/dist/pixi-layers.d.ts" />
/// <reference path="../node_modules/@egt/egt-library/dist/egt-library.d.ts" />
/// <reference types="pixi.js" />
/// <reference types="puremvc" />
/// <reference types="gamy-ts" />
/// <reference types="howler" />
declare namespace gpts.services {
    class Message {
        messageId: string;
        command: string;
        qName: string;
        protected _data: Object;
        constructor(command?: string, qName?: string);
        encode(): any;
        getData(): Object;
        setData(data: Object): Message;
        toString(): string;
    }
}
declare namespace gpts.services.messages.response {
    class BaseResponse extends Message {
        static className: string;
        eventTimestamp: number;
        msg: string;
        complex: any;
        reason: string;
        constructor(command?: string, eventTimestamp?: number, msg?: string, complex?: any, reason?: string, qName?: string);
        toString(): string;
        setData(data: Object): Message;
    }
}
declare namespace gpts.services.messages.response {
    class LoginResponse extends BaseResponse {
        static className: string;
        balance: number;
        playerName: string;
        currency: string;
        languages: Array<any>;
        groups: Array<any>;
        showRtp: Object;
        multigame: boolean;
        autoplayLimit: any;
        minimumSpinTime: number;
        sendTotalsInfo: boolean;
        constructor(command?: string, eventTimestamp?: number, msg?: string, complex?: Object, reason?: string, balance?: number, playerName?: string, currency?: string, languages?: Array<any>, qName?: string, groups?: Array<any>, showRtp?: Object, multigame?: boolean, autoplayLimit?: any, minimumSpinTime?: number, sendTotalsInfo?: boolean);
        toString(): string;
    }
}
declare namespace gpts {
    class Reflection {
        toString(): string;
    }
}
declare namespace gpts.services.messages.request {
    class BaseRequest extends Message {
        sessionKey: string;
        constructor(command?: string, sessionKey?: string, qName?: string);
        toString(): string;
    }
}
declare namespace gpts.services.messages.request {
    class GameRequest extends BaseRequest {
        gameIdentificationNumber: number;
        gameNumber: number;
        constructor(command?: string, sessionKey?: string, gameIdentificationNumber?: number, gameNumber?: number, qName?: string);
        toString(): string;
    }
}
declare namespace gpts.abstract_games {
    import Message = gpts.services.Message;
    class GameData {
        balance: number;
        language: string;
        settings: any;
        command: string;
        bets: any;
        looseConnection: boolean;
        iData: any;
        currency: string;
        languages: Array<any>;
        currencyISO: string;
        constructor(balance?: number, language?: string, settings?: any, command?: string, bets?: any, looseConnection?: boolean, iData?: any, currency?: string, languages?: Array<any>, currencyISO?: string);
        merge(message: Message, withJSON?: boolean): GameData;
        toString(): string;
    }
}
declare namespace gpts.services.messages.response {
    class GameResponse extends BaseResponse {
        static className: string;
        gameIdentificationNumber: number;
        gameNumber: number;
        balance: number;
        totalBet: number;
        totalWin: number;
        playTime: number;
        constructor(command?: string, eventTimestamp?: number, msg?: string, complex?: Object, reason?: string, gameIdentificationNumber?: number, gameNumber?: number, qName?: string);
        toString(): string;
    }
}
declare namespace gpts {
    interface IMovieClip {
        gotoAndStopToLabel(label: string): void;
    }
}
declare namespace gpts {
    import MovieClip = PIXI.extras.AnimatedSprite;
    import Texture = PIXI.Texture;
    class SpriteSheet extends MovieClip implements IMovieClip {
        protected _frames: Array<Frame>;
        constructor(frames: Array<Frame>);
        gotoAndStopToLabel(label: string): void;
        dispose(): void;
    }
    class Frame {
        texture: Texture;
        label: string;
        constructor(texture: Texture, label?: string);
        dispose(): void;
    }
}
declare namespace gpts {
    import Container = PIXI.Container;
    class Holder extends Container {
        protected _options: any;
        constructor(options?: any);
        private onRemoveFromDisplayTree(event);
        dispose(): void;
        attrs(options?: any): any;
        addChildren(...rest: any[]): void;
        hasListener(type: string): boolean;
    }
}
declare namespace gpts {
    import Graphics = PIXI.Graphics;
    class Button extends Holder {
        private static STATE_UNSUPPORTED;
        label: PIXI.Text;
        protected _state: string;
        protected _src: SpriteSheet;
        graphics: Graphics;
        constructor(src?: SpriteSheet, options?: any);
        src: SpriteSheet;
        onOver(event?: any): void;
        onDown(event?: any): void;
        onUp(event?: any): void;
        protected createLabel(): void;
        getState(): string;
        setState(value: string): void;
        dispose(): void;
    }
}
declare namespace gpts.services {
    import Proxy = puremvc.Proxy;
    import IProxy = puremvc.IProxy;
    interface IMessageModel {
        pendingCommand(commandName: string): boolean;
        getCommand(commandName: string): Message;
    }
    abstract class IMessageProxy extends Proxy implements IProxy {
        timeStamp: number;
        timeToLive: number;
        constructor(proxyName?: string, data?: any);
    }
}
declare namespace gpts.services {
    class MessageProxy extends IMessageProxy {
        private _id;
        constructor(message: Message);
        onRegister(): void;
        private onTimeout();
        onRemove(): void;
    }
}
declare namespace gpts.services {
    import Model = puremvc.Model;
    import IProxy = puremvc.IProxy;
    class MessagesModel extends Model implements IMessageModel {
        private commands_map;
        constructor();
        registerProxy(proxy: IProxy): void;
        removeProxy(proxyName: string): IProxy;
        pendingCommand(commandName: string): boolean;
        getCommand(commandName: string): Message;
    }
}
declare namespace gpts {
    import LogOptions = gamy.LogOptions;
    class ELogger extends LogOptions {
        static RUNTIME_ERRORS: ELogger;
        static UNCAUGHT_ERRORS: ELogger;
        static MAPPING: ELogger;
        static STATE_MACHINE: ELogger;
        static APP_FACADE: ELogger;
        static GAME_DATA: ELogger;
        static PING: ELogger;
        static GAME: ELogger;
        static MEMORY_TRACKER: ELogger;
        static LATENCY: ELogger;
        static PORTAL: ELogger;
        static NAVIGATION_PROXY: ELogger;
        constructor(name: string, options?: any);
    }
}
declare namespace gpts.services {
    class Ping {
        lastMsgTimeStamp: number;
        private _id;
        private elapsed_time;
        private _interval;
        constructor(interval: number);
        start(): void;
        stop(): void;
        private onTick();
        elapsedTime: number;
        readonly running: boolean;
    }
}
declare namespace gpts.services {
    import SimpleCommand = puremvc.SimpleCommand;
    import INotification = puremvc.INotification;
    class SuccessMessageCommand extends SimpleCommand {
        execute(notification: INotification): void;
        private serialize(body);
        private map(message);
    }
}
declare namespace gpts.services {
    import SimpleCommand = puremvc.SimpleCommand;
    import INotification = puremvc.INotification;
    class SendMessageCommand extends SimpleCommand {
        execute(notification: INotification): void;
    }
}
declare namespace gpts.services {
    import Facade = puremvc.Facade;
    import IEventDispatcher = gamy.IEventDispatcher;
    class MessagesFacade extends Facade implements IEventDispatcher, IMessageModel {
        static NAME: string;
        static MESSAGE_SUCCESS: string;
        static SEND_MESSAGE: string;
        static CONNECTION_STATUS: string;
        static LOST_CONNECTION_INTERVAL: number;
        static PING_INTERVAL: number;
        static PING_TICK_INTERVAL: number;
        static REQUEST_RESPONSE_IDENTIFICATOR: string;
        private _socket;
        private _dispatcher;
        pingMessage: Message;
        services: Object;
        private _ping;
        getModuleName: (response: any) => string;
        private _connected;
        constructor();
        static getInstance(): MessagesFacade;
        initializeFacade(): void;
        initializeController(): void;
        initializeModel(): void;
        private configureListeners();
        private onSocketOpen(event);
        private onSocketMessage(event);
        private onSocketError(event);
        private onSocketClose(event);
        addEventListener(type: string, callback: Function, context: any): void;
        dispatchEvent(event: any): void;
        removeEventListener(type: string, callback: Function, context?: any): void;
        hasEventListener(type: string): boolean;
        pendingCommand(commandName: string): boolean;
        getCommand(commandName: string): Message;
        close(): void;
        send(data: Message, timeToLive?: Number): void;
        getServiceTimeout(moduleName: string, serviceName: string): number;
        isTimeoutRequestSkippable(moduleName: string, serviceName: string): boolean;
        readonly socket: WebSocket;
        readonly ping: Ping;
        readonly connected: boolean;
    }
}
declare namespace gpts {
    class DebugCode {
        constructor();
    }
}
declare namespace gpts {
    class ErrorTest {
        constructor(errorID: string);
    }
}
declare namespace gpts.abstract_games {
    class DataHandler {
        constructor();
        static set(view: any, data: GameData): void;
    }
}
declare namespace gpts.abstract_games {
    import Mediator = puremvc.Mediator;
    import INotification = puremvc.INotification;
    import IMediator = puremvc.IMediator;
    import MessagesFacade = gpts.services.MessagesFacade;
    class GameMediator extends Mediator implements IGameMediator, IMediator {
        static LOOSE_CONNECTION: string;
        static EVENTS: string;
        static SHOW: string;
        static SUCCESS: string;
        static RETURN_BETS: string;
        protected _events: Array<string>;
        protected messages_facade: MessagesFacade;
        constructor(gameType: string);
        listNotificationInterests(): string[];
        handleNotification(notification: INotification): void;
        onRemove(): void;
        readonly events: Array<string>;
        protected readonly _facade: AppFacade;
    }
}
declare namespace gpts {
    import SimpleCommand = puremvc.SimpleCommand;
    import INotification = puremvc.INotification;
    class LoginCommand extends SimpleCommand {
        execute(notification: INotification): void;
        private setInterests(gameType?);
        private displayCurrency(currencyISOFormat);
        private modifyGamesList(message);
        private spliceGamesListForAMiniPortal(message);
        private intersect(array1, array2);
    }
}
declare namespace gpts.abstract_games {
    import Message = gpts.services.Message;
    import IProxy = puremvc.IProxy;
    import Proxy = puremvc.Proxy;
    abstract class IGame extends Proxy implements IProxy {
        abstract interests(): string;
        abstract gameType(): string;
        abstract isVisible(): boolean;
        abstract handleTimeoutMessage(message: Message): void;
        abstract eventHandler(event: any): void;
        abstract getSettings(): void;
        abstract filtered(): boolean;
        abstract supportPortrait(): boolean;
        startGame(): void;
        settings: any;
        hasSettings: boolean;
        subscribed: boolean;
        iData: any;
        currentState: string;
        canContinueAfterFailure: boolean;
        constructor(proxyName?: string, data?: any);
    }
    interface IGameMediator {
        events: Array<string>;
    }
}
declare namespace gpts {
    import SimpleCommand = puremvc.SimpleCommand;
    import INotification = puremvc.INotification;
    class UpdateBalanceCommand extends SimpleCommand {
        execute(notification: INotification): void;
    }
}
declare namespace gpts {
    import SimpleCommand = puremvc.SimpleCommand;
    import INotification = puremvc.INotification;
    class DisposeCheckCommand extends SimpleCommand {
        execute(notification: INotification): void;
    }
}
declare namespace gpts {
    import Mediator = puremvc.Mediator;
    import IMediator = puremvc.IMediator;
    import MessagesFacade = gpts.services.MessagesFacade;
    class BaseMediator extends Mediator implements IMediator {
        protected portal_proxy: PortalProxy;
        protected app_facade: AppFacade;
        protected messages_facade: MessagesFacade;
        protected _router: Router;
        protected _stage: StageMediator;
        constructor(name?: string, view?: any);
        onRegister(): void;
        listNotificationInterests(): string[];
        sendFront(): void;
    }
}
declare namespace gpts {
    import IMediator = puremvc.IMediator;
    class GameInterfaceMediator extends BaseMediator implements IMediator {
        static NAME: string;
        private _events;
        constructor();
        onRegister(): void;
        private configureListeners(add?);
        private eventHandler(event);
        onRemove(): void;
    }
}
declare namespace gpts {
    import IMediator = puremvc.IMediator;
    class SessionClosedMediator extends BaseMediator implements IMediator {
        static NAME: string;
        constructor();
        onRegister(): void;
    }
}
declare namespace gpts {
    import Graphics = PIXI.Graphics;
    import Sprite = PIXI.Sprite;
    import Text = PIXI.Text;
    class GameLoading extends Holder {
        progressBar: Graphics;
        progressBarFixed: Graphics;
        background: Graphics;
        private _progress;
        star: Sprite;
        progressPercentage: Text;
        companyLogo: Sprite;
        constructor();
        progress: number;
    }
}
declare namespace gpts {
    import INotification = puremvc.INotification;
    class GameLoadingMediator extends BaseMediator {
        static NAME: string;
        private static PROGRESS_TIME;
        private _loader;
        private _integrated;
        private _game;
        constructor();
        onRegister(): void;
        private onStartLoadingGame(event);
        private onFailLoadingGame(event);
        private onCompleteLoadingGame(event);
        private configureListeners(add?);
        private onIntegratedProgress(event);
        private onIntegratedProgressComplete(event);
        handleNotification(notification: INotification): void;
    }
}
declare namespace gpts {
    import Text = PIXI.Text;
    class StaticControls extends Holder {
        currencyField: CurrencyTextField;
        usernameField: TextField;
        help: Button;
        fullscreen: Button;
        mute: Button;
        exit: Button;
        balance: SpriteSheet;
        selectGame: SpriteSheet;
        noConnection: SpriteSheet;
        languageBar: LanguageBar;
        clock: Text;
        constructor();
    }
}
declare namespace gpts {
    import Rectangle = PIXI.Rectangle;
    class MagnifierScroll {
        private _container;
        private _holder;
        private _frame;
        private _options;
        private _padding;
        constructor(container: Holder, holder: Holder, frame: Rectangle, options?: any);
        private _onMouseMove(event);
        start(): void;
        stop(): void;
        private _update(local, pos_metric, dim_metric);
        update(event: any): void;
        dispose(): void;
        frame: Rectangle;
    }
}
declare namespace gpts {
    class LanguageBar extends Holder {
        container: Holder;
        holder: Holder;
        scroll: MagnifierScroll;
        current: SpriteSheet;
        private special_height;
        constructor(languages: Array<string>, createFlag?: (lang: string) => Button, createCurrent?: (languages: Array<string>) => SpriteSheet, options?: any);
        prepareHolderBeforeScrollStart(): void;
    }
}
declare namespace gpts.services {
    class MessagesEvent {
        static MESSAGE: string;
        static TIME_OUT: string;
        static LOOSE_CONNECTION: string;
        private _data;
        private message_id;
        type: string;
        target: any;
        constructor(type: string, data?: any, messageId?: string);
        readonly data: any;
        readonly messageId: string;
    }
}
declare namespace gpts {
    import Mediator = puremvc.Mediator;
    import IMediator = puremvc.IMediator;
    class StageMediator extends Mediator implements IMediator {
        static NAME: string;
        static readonly gamesSupportingWideResolutions: string[];
        constructor();
        onRegister(): void;
        private shouldDisplayWideResolution();
        private onOrientationChange();
        readonly view: Stage;
    }
}
declare namespace gpts {
    class SliderNavigationItem extends Button {
        constructor(src?: SpriteSheet);
        setState(value: string): void;
        dispose(): void;
        setLabelText(value: string): void;
    }
}
declare namespace gpts {
    class SliderNavigation extends Holder {
        private max_visible;
        private selected_index;
        private visible_first_index;
        private visible_last_index;
        private _cyclic;
        private _getSlideId;
        constructor(options?: any);
        selectedIndex: number;
        private displayVisible();
        readonly cyclic: boolean;
    }
}
declare namespace gpts {
    abstract class ISlider {
        abstract setSlide(value: number, doNotAnimate: boolean): void;
        abstract attach(): void;
        abstract detach(): void;
        abstract dispose(): void;
        options: any;
        readonly slide: number;
        readonly oldSlide: number;
        readonly isSliding: boolean;
        readonly isDragging: boolean;
        readonly acceptClick: boolean;
        abstract getSlideId(serialNumber: number): number;
    }
}
declare namespace gpts {
    import Point = PIXI.Point;
    import DisplayObject = PIXI.DisplayObject;
    import InteractionData = PIXI.interaction.InteractionData;
    class Mouse {
        private _cm;
        private _pm;
        private _container;
        private _md;
        private mouse_down;
        private mouse_move;
        constructor(container: DisplayObject);
        start(data: InteractionData): void;
        move(data: InteractionData): void;
        end(): void;
        dispose(): void;
        cm: Point;
        pm: Point;
        readonly speedX: number;
        readonly speedY: number;
        readonly directionX: boolean;
        readonly directionY: boolean;
        readonly md: Point;
        readonly mouseDown: boolean;
        readonly mouseMove: boolean;
        readonly nearTheStartPosition: boolean;
        static distance(p1: Point, p2: Point): number;
    }
}
declare namespace gpts {
    import Container = PIXI.Container;
    class Slider extends ISlider {
        container: Container;
        holder: Container;
        private old_slide;
        private _slide;
        private _mouse;
        private holder_position_x;
        private dragged_sn;
        private primary_touch_point_id;
        constructor(container: Container, holder: Container, options?: any);
        private getSlideSerialNumber(data);
        private onCompleteSlideAnimation();
        setSlide(value: number, doNotAnimate?: boolean): void;
        private calculateTweenTime();
        getSlideId(serialNumber: number): number;
        dispose(): void;
        attach(): void;
        detach(): void;
        private configureMoveListeners(add?);
        private primaryTouchPointCheck(event);
        private onMouseDown(event);
        private onMouseMove(event);
        private onMouseUp(event?);
        private onMouseOut(event);
        readonly slide: number;
        readonly oldSlide: number;
        readonly isSliding: boolean;
        readonly isDragging: boolean;
        readonly acceptClick: boolean;
    }
}
declare namespace gpts {
    import Holder = gpts.Holder;
    class Slide extends Holder {
        id: number;
        constructor(id?: number);
        dispose(): void;
    }
}
declare namespace gpts {
    import Holder = gpts.Holder;
    import Sprite = PIXI.Sprite;
    class Navigation extends Holder {
        container: Holder;
        holder: Holder;
        sliderNavigation: SliderNavigation;
        prevNext: SliderPrevNext;
        marker: Sprite;
        private visible_slides;
        private _slides;
        private _slider;
        private draw_slide;
        constructor(slides: number, drawSlide: (slide: Slide) => Slide, options?: any);
        private onCompleteSlide(slide);
        private onStartSlide();
        private createSlide(serialNumber?);
        readonly slider: ISlider;
        dispose(): void;
    }
}
declare namespace gpts {
    import Sprite = PIXI.Sprite;
    class NavigationItem extends Button {
        private static OVER_ICON_POS;
        static BONUS_ICON_MARGIN_TOP: number;
        static BONUS_ICON_MARGIN_LEFT: number;
        activeGameIcon: Sprite;
        recoveryIcon: Sprite;
        jackpotIcon: Sprite;
        featuredIcon: Sprite;
        bonusIcon: Sprite;
        overIcon: Sprite;
        constructor(src?: SpriteSheet);
        onDown(event?: any): void;
        onOver(event?: any): void;
        onUp(event?: any): void;
        dispose(): void;
    }
}
declare namespace gpts {
    import Proxy = puremvc.Proxy;
    import Hash = gamy.Hash;
    class GameIcon {
        gameType: string;
        frames: Array<Frame>;
        constructor(gameType: string, frames: Array<Frame>);
    }
    class NavigationProxy extends Proxy {
        static NAME: string;
        static SLIDER_NAV_MAX_VISIBLE: number;
        static SLIDER_VISIBLE_WIDTH: number;
        static SLIDER_VISIBLE_HEIGHT: number;
        static GAME_THUMB_WIDTH: number;
        static GAME_THUMB_HEIGHT: number;
        static POSITIONS: Array<Array<number>>;
        static NAVIGATION_POS_Y: number;
        protected app_facade: AppFacade;
        private _list;
        private group_id;
        private _status;
        private _slides;
        private static _iconLoaderMap;
        constructor(groupId: string);
        onRegister(): void;
        private static configureIconLoaderListeners();
        private static onCompleteLoadingIcon(loader, options);
        static generateIconLoaderMap(): void;
        private filterGamesList();
        private sortGamesList();
        private updateStatusHash();
        getIcon(gameType: string): GameIcon;
        checkForIncorrectGameIdentificationNumber(gameIdentificationNumber: string): boolean;
        availableGINForGameType(gameType: string): Array<string>;
        private static getThumbPositions(rows, columns, thumbWidth, thumbHeight, slideWidth, slideHeight);
        readonly list: Array<any>;
        readonly status: Hash;
        readonly slides: number;
    }
}
declare namespace gpts {
    class SliderPrevNext extends Holder {
        prev: Button;
        next: Button;
        constructor(rightArrowFrames?: Array<Frame>);
        dispose(): void;
    }
}
declare namespace gpts {
    import INotification = puremvc.INotification;
    class NavigationMediator extends BaseMediator {
        static NAME: string;
        private group_id;
        private nav_proxy;
        private _selected;
        private click_condition_id;
        constructor(groupId: string);
        listNotificationInterests(): string[];
        onRegister(): void;
        private launchPreRequestedGame();
        private drawSlide(slide);
        private createNavigationItem(data);
        private onGameThumbOver(event);
        private onClickGameThumb(event);
        private playShowSoundOnAlreadyLoadedGame(gameIdentificationNumber);
        private onClickSliderNavigationItem(event);
        private onClickPrevNext(event);
        private onDisposeGameProxy(event);
        private onBonusSpinsChanged(event);
        private updateBonusIcon(item, data);
        private onGameCompleteRecovery(event);
        handleNotification(notification: INotification): void;
        private setSelected(target);
        onRemove(): void;
        private getGameThumbnailBy(gameIdentificationNumber);
        private getGameThumbnailsBy(gameIdentificationNumber);
        private centeredSlideContainsGameThumbWith(gameIdentificationNumber);
    }
}
declare namespace gpts {
    import Proxy = puremvc.Proxy;
    import EventDispatcher = gamy.EventDispatcher;
    class PortalProxy extends Proxy {
        static NAME: string;
        static PNG_EXT: string;
        static JPG_EXT: string;
        static STAGE_WIDTH: number;
        static STAGE_HEIGHT: number;
        static VISIBLE_WIDTH: number;
        static VISIBLE_HEIGHT: number;
        static SPECIAL_CURRENCY: string;
        static ICON: string;
        static BUTTON: string;
        static ACTIVE_GAME_ICON: string;
        static RECOVERY_ICON: string;
        static JACKPOT_ICON: string;
        static MARKER: string;
        static FEATURED_ICON: string;
        static BONUS_ICON: string;
        static DIAMOND_ICON: string;
        static HELP_ICON_IDLE: string;
        static HELP_ICON_DOWN: string;
        static HELP_ICON_OVER: string;
        static FULLSCR_ICON_ON: string;
        static FULLSCR_ICON_ON_DOWN: string;
        static FULLSCR_ICON_ON_OVER: string;
        static FULLSCR_ICON_OFF_DOWN: string;
        static FULLSCR_ICON_OFF_OVER: string;
        static FULLSCR_ICON_OFF: string;
        static MUTE_ICON_ON: string;
        static MUTE_ICON_ON_DOWN: string;
        static MUTE_ICON_ON_OVER: string;
        static MUTE_ICON_OFF_DOWN: string;
        static MUTE_ICON_OFF_OVER: string;
        static MUTE_ICON_OFF: string;
        static EXIT_BUTTON_IDLE: string;
        static EXIT_BUTTON_DOWN: string;
        static EXIT_BUTTON_OVER: string;
        static LANG_BAR_BACKGROUND: string;
        static LANG_BAR_BACKGROUND_SMALL: string;
        static STAR_ICON: string;
        static COMPANY_LOGO: string;
        static FOOTER_BACKGROUND: string;
        static HEADER_BACKGROUND: string;
        static RIGHT_ARROW: string;
        static NAVIGATION_ITEM_OVER: string;
        static GAMES_FILTER_CENTER: string;
        static GAMES_FILTER_LEFT: string;
        static BALANCE_LABEL: string;
        static SELECT_GAME_LABEL: string;
        static NO_CONNECTION_LABEL: string;
        static SLIDER_NAV_ITEM: string;
        onLoadResources: Function;
        private _atlas;
        constructor(onLoadResources?: Function);
        private static getDimensionFor(property);
        private libraryPath();
        onRegister(): void;
        preloadSound(url: string): Howl;
        getTexture(name: string, ext?: string): any;
    }
    var muted: boolean;
    class Fullscreen extends EventDispatcher {
        static CHANGE: string;
        private _requestFullscreen;
        private _cancelFullscreen;
        change: (fullscreen: boolean) => void;
        constructor();
        request(): void;
        cancel(): void;
        readonly supported: boolean;
    }
    const fullscreen: Fullscreen;
}
declare namespace gpts {
    class StaticControlsItem extends Button {
        constructor(src?: SpriteSheet, options?: any);
        onDown(event?: any): void;
        onOver(event?: any): void;
    }
}
declare namespace gpts {
    import INotification = puremvc.INotification;
    class StaticControlsMediator extends BaseMediator {
        static NAME: string;
        private static CURRENCY_FIELD;
        private static USERNAME_FIELD;
        private static HELP_FULLSCREEN_MUTE_PADDING;
        private static EXIT_BUTTON_Y;
        private static SELECT_GAME_LABEL_Y;
        private static CLOCK_POS;
        private static LANG_BAR_POS;
        private static EXIT;
        private static FULLSCREEN;
        private static HELP;
        private static MUTE;
        private lang_bar_is_active;
        constructor();
        onRegister(): void;
        private createCurrencyTextField();
        private createUserNameTextField();
        private createExitHelpMuteAndFullscreenButtons();
        private createLanguageBar();
        private createBalanceAndSelectGameTextFields();
        private createClock();
        private getTime();
        private onLooseConnection(event?);
        private onUpdateBalance(event?);
        private changeFullscreen(fullscreen);
        private onClickLanguageBar(event);
        private toggleLanguageBar(event?);
        private onClick(event);
        private toggleFullScreen();
        private displayHelp();
        private setMuteStatus();
        handleNotification(notification: INotification): void;
        private translateContent();
        listNotificationInterests(): string[];
    }
}
declare namespace gpts {
    import Sprite = PIXI.Sprite;
    import Text = PIXI.Text;
    class Loading extends Holder {
        companyLogo: Sprite;
        label: Text;
        constructor();
        dispose(): void;
    }
}
declare namespace gpts {
    import Mediator = puremvc.Mediator;
    class LoadingMediator extends Mediator {
        static NAME: string;
        private _id;
        private _stage;
        private static logoWidth;
        private static logoHeight;
        private _orientationChangeHandler;
        constructor();
        onRegister(): void;
        private onOrientationChange();
        private getDots(step);
        onRemove(): void;
    }
}
declare namespace gpts {
    import INotification = puremvc.INotification;
    class BackgroundMediator extends BaseMediator {
        static NAME: string;
        constructor();
        onRegister(): void;
        handleNotification(notification: INotification): void;
        listNotificationInterests(): string[];
    }
}
declare namespace gpts {
    class GamesFilter extends Holder {
        constructor(groups: Array<string>, createItem?: (groupID: string) => Button);
    }
}
declare namespace gpts {
    import INotification = puremvc.INotification;
    class GamesFilterMediator extends BaseMediator {
        static NAME: string;
        private static HEADER_HEIGHT;
        private selected_name;
        private item_height;
        private item_left_texture_width;
        constructor();
        onRegister(): void;
        private onClickFilterItem(event);
        handleNotification(notification: INotification): void;
        private translateContent();
        listNotificationInterests(): string[];
    }
}
declare namespace gpts {
    class FullscreenIOSMediator extends BaseMediator {
        static NAME: string;
        private _window;
        private _isFullscreen;
        private _fullscreenAnimation;
        constructor();
        onRegister(): void;
        private preventDefault(event);
        private checkFullscreenIOS();
    }
}
declare namespace gpts {
    class UnsupportedPortraitMediator extends BaseMediator {
        static NAME: string;
        constructor();
        onRegister(): void;
        private gameSupportPortrait();
        private onOrientationChange();
    }
}
declare namespace gpts {
    import Facade = puremvc.Facade;
    import IMediator = puremvc.IMediator;
    class Router extends Facade {
        static NAME: string;
        static CHANGE_PAGE: string;
        static CHANGE_LANG: string;
        static ICON_HAS_LOADED: string;
        static HOME_PAGE: string;
        static GAME_PAGE: string;
        static SINGLE_GAME_PAGE: string;
        static SESSION_CLOSED_PAGE: string;
        static LOADING_PAGE: string;
        private _parameters;
        private old_parameters;
        private _page;
        language: string;
        private mediator_names;
        constructor();
        static getInstance(): Router;
        redirectTo(pageName: string, parameters?: any): void;
        private manageMediatorsOnPageChange(pageName);
        private setMediators(...args);
        registerMediator(mediator: IMediator): void;
        removeMediator(mediatorName: string): IMediator;
        private processLanguageParam(parameters);
        readonly parameters: any;
        readonly page: string;
        readonly oldParameters: any;
    }
}
declare namespace gpts {
    import SimpleCommand = puremvc.SimpleCommand;
    import INotification = puremvc.INotification;
    class LaunchGameCommand extends SimpleCommand {
        execute(notification: INotification): void;
    }
}
declare namespace gpts {
    import SimpleCommand = puremvc.SimpleCommand;
    import INotification = puremvc.INotification;
    class RecoveryUpdateBalanceCommand extends SimpleCommand {
        execute(notification: INotification): void;
    }
}
declare namespace gpts {
    class GameEvent {
        static DESTROY: string;
        static BONUS_SPINS_CHANGED: string;
        static HIDE: string;
        static INTEGRATED_PROGRESS: string;
        static COMPLETE_INTEGRATION: string;
        static FAIL_INTEGRATION: string;
        gameIdentificationNumber: string;
        gameType: string;
        amount: number;
        state: string;
        target: any;
        type: string;
        constructor(type: string, gameIdentificationNumber?: string, gameType?: string, amount?: number, state?: string);
    }
}
declare namespace gpts {
    import SimpleCommand = puremvc.SimpleCommand;
    import INotification = puremvc.INotification;
    class ExitPlatformCommand extends SimpleCommand {
        execute(notification: INotification): void;
    }
}
declare namespace gpts {
    import SimpleCommand = puremvc.SimpleCommand;
    import INotification = puremvc.INotification;
    class PopUpOnEventCommand extends SimpleCommand {
        execute(notification: INotification): void;
        private formatCurrency(value);
        private exitPlatform();
        private notifyGameForResponibleGaming(message);
        private notifyGameForResponibleGamingCompletion();
    }
}
declare namespace gpts {
    import SimpleCommand = puremvc.SimpleCommand;
    import INotification = puremvc.INotification;
    class SoundCommand extends SimpleCommand {
        execute(notification: INotification): void;
    }
}
declare namespace gpts {
    import Facade = puremvc.Facade;
    import Hash = gamy.Hash;
    import IProxy = puremvc.IProxy;
    import IEventDispatcher = gamy.IEventDispatcher;
    class AppFacade extends Facade implements IEventDispatcher {
        static NAME: string;
        static UPDATE_BALANCE: string;
        static LOGIN: string;
        static DISPOSE_CHECK: string;
        static LAUNCH_GAME: string;
        static RECOVERY_UPDATE_BALANCE: string;
        static PLAY_SOUND: string;
        static EXIT_PLATFORM: string;
        static POPUP_ON_EVENT: string;
        static HIDE_GAME: string;
        static ROLLOVER_GAME_ICON: string;
        static SHOW_GAME: string;
        static FULLSCREEN_IN: string;
        static FULLSCREEN_OUT: string;
        static ARROW: string;
        static SLIDER_NAVIGATION_ITEM: string;
        static LANGUAGE_BAR_IN: string;
        static LANGUAGE_BAR_OUT: string;
        private _dispatcher;
        sessionKey: string;
        tcpHost: string;
        tcpPort: number;
        originalGamesList: any;
        gamesList: Hash;
        gamesRecoveryList: Hash;
        gamesWithBonusesList: Hash;
        subscribeMessagesIds: Array<string>;
        interests: Hash;
        gamesEnum: Hash;
        recoveryMessagesIds: Array<string>;
        singleGameMode: boolean;
        private _balance;
        _totalBet: number;
        _totalWin: number;
        currency: string;
        currencyISO: string;
        playerName: string;
        languages: Array<string>;
        isEGTCurrency: boolean;
        showRtp: any;
        autoplayLimit: any;
        immediatelyClosePopup: boolean;
        minimumSpinTime: number;
        sendTotalsInfo: boolean;
        doesOperatorAddWinToBalanceDuringBonusSpins: boolean;
        groups: Array<any>;
        gameIdentificationNumber: number;
        constructor();
        static getInstance(): AppFacade;
        initializeFacade(): void;
        initializeController(): void;
        registerProxy(proxy: IProxy): void;
        removeProxy(proxyName: string): IProxy;
        private gameIsDisposable(gameLoaderName);
        addEventListener(type: string, callback: Function, context: any): void;
        dispatchEvent(event: any): void;
        removeEventListener(type: string, callback: Function, context?: any): void;
        hasEventListener(type: string): boolean;
        balance: number;
        totalBet: number;
        totalWin: number;
        readonly activeGames: number;
        formatCurrency(value: number): string;
    }
}
declare namespace gpts {
    class EMessage {
        static PLATFORM_PACKAGE: string;
        static GAME_PACKAGE: string;
        static LOGIN: string;
        static PING: string;
        static EVENT: string;
        static CONFIG: string;
        static SESSION_TIMEOUT: string;
        static SESSION_OVERRIDE: string;
        static CONNECTION_CLOSED: string;
        static USE_MOBILE_DEVICES: string;
        static SESSION_SHUTDOWN: string;
        static REALITY_CHECK: string;
        static BET_LIMIT: string;
        static LOSS_LIMIT: string;
        static TIME_LIMIT: string;
        static RECOVERY: string;
        static NO_RECOVERY: string;
        static COMPLETE_RECOVERY: string;
        static PROGRESS_RECOVERY: string;
        static SUBSCRIBE: string;
        static UNSUBSCRIBE: string;
        static SETTINGS: string;
        static BET: string;
        static ACKNOWLEDGE_WIN: string;
        static FAILURE: string;
        static CLIENT_FAILURE: string;
        static CONNECTION_FAILURE: string;
        static HARDWARE_FAILURE: string;
        static BALANCE: string;
        static RESPONSIBLE_GAMING: string;
        static RESPONSIBLE_GAMING_COMPLETE: string;
        static REQUEST_TIMEOUT: string;
        static TIME_PROXIM_ALERT: string;
        static CREDIT_LEFT_ALERT: string;
        static SUCCESS: string;
        static IP_BLOCKED: string;
        static GAME_FILTER: string;
        static MAINTENANCE: string;
        static BONUS_ERROR: string;
        static HISTORY: string;
        static STATISTICS: string;
    }
}
declare namespace gpts.services.messages.request {
    class LoginRequest extends BaseRequest {
        platformType: string;
        mobileType: string;
        constructor(command?: string, sessionKey?: string, qName?: string);
        toString(): string;
    }
}
declare namespace gpts.services.messages.request {
    class ConfigRequest extends Message {
        login: string;
        scenario: string;
        sessionKey: string;
        constructor(command: string, sessionKey: string, qName: string, login: any, scenario: any);
        toString(): string;
    }
}
declare namespace gpts {
    import Proxy = puremvc.Proxy;
    class SocketProxy extends Proxy {
        static NAME: string;
        private messages_facade;
        private testServerSettings;
        constructor(testServer: any, login: any, scenario: any);
        onRegister(): void;
        private onOpenConnection(event);
        private onComingMessage(event);
        private onMessageTimeout(event);
        private onError(event);
        private onLooseConnection(event);
        private onRecoveryOfProgressGame(recovery);
        private onSubscribeOfProgressGame(subscribe);
        private checkForProgressGames();
        private goToPrimaryPage();
        protected readonly _facade: AppFacade;
    }
}
declare namespace gpts.services.messages.response {
    class GameEventResponse extends GameResponse {
        static className: string;
        state: string;
        winAmount: number;
        constructor(command?: string, eventTimestamp?: number, msg?: string, complex?: Object, reason?: string, gameIdentificationNumber?: number, gameNumber?: number, state?: string, winAmount?: number, qName?: string);
        toString(): string;
    }
}
declare namespace gpts.services.messages.response {
    class RecoverResponse extends GameResponse {
        static className: string;
        gameRecoveryType: string;
        winAmount: number;
        credit: number;
        constructor(command?: string, eventTimestamp?: number, msg?: string, complex?: Object, reason?: string, gameIdentificationNumber?: number, gameNumber?: number, gameRecoveryType?: string, winAmount?: number, credit?: number, qName?: string);
        toString(): string;
    }
}
declare namespace gpts.services.messages.response {
    class ConfigResponse extends Message {
        static className: string;
        login: string;
        scenario: string;
        constructor(command?: string, qName?: string);
        toString(): string;
    }
}
declare namespace gpts {
    import Container = PIXI.Container;
    class TestHolder extends Container {
        constructor();
    }
}
declare namespace gpts {
    import Text = PIXI.Text;
    import TextStyle = PIXI.TextStyle;
    enum Position {
        TOP = 0,
        BOTTOM = 1,
        LEFT = 2,
        RIGHT = 3,
    }
    class TextField extends Text {
        static MIN_FONT_SIZE: number;
        constructor(text?: string, style?: TextStyle, resolution?: number);
        private stretchBy(prop, max);
        constrain(w: number, h: number): void;
        alignTo(field: Text, position: Position): void;
    }
}
declare namespace gpts {
    import Rectangle = PIXI.Rectangle;
    import Sprite = PIXI.Sprite;
    class CurrencyTextField extends Holder {
        rect: Rectangle;
        moneyField: TextField;
        creditField: TextField;
        currencyField: TextField;
        specialCurrencyIcon: Sprite;
        specialCurrencyPaddingX: number;
        private _currency;
        private special_currency;
        private special_currency_icon_width;
        private special_currency_icon_height;
        private _useCredits;
        constructor(specialCurrency?: string);
        useCredits(flag: boolean): void;
        setCurrency(value: string): void;
        money(value: string): void;
        dispose(): void;
    }
}
declare namespace gpts {
    import Texture = PIXI.Texture;
    import Container = PIXI.Container;
    class Scale3Sprite extends Container {
        private _left;
        private _right;
        private _centerSprite;
        private _center;
        private has_right;
        private _width;
        private _height;
        constructor(width: number, height: number, left: Texture, center: Texture, right?: Texture);
        setWidth(value: number): void;
    }
}
declare namespace gpts {
    import Container = PIXI.Container;
    class Scale3MovieClip extends Container implements IMovieClip {
        private last_visible_label;
        constructor(frames: Array<{
            content: Scale3Sprite;
            label: string;
        }>);
        gotoAndStopToLabel(label: string): void;
        setWidth(value: number): void;
    }
}
declare namespace gpts {
    import PStage = PIXI.display.Stage;
    class Stage {
        protected _stage: PStage;
        protected _renderer: any;
        protected _content: any;
        protected _options: any;
        protected _window: JQuery<Window>;
        protected _windowWidth: number;
        protected _windowHeight: number;
        private visible_aspect;
        private stage_aspect;
        constructor(options?: any);
        private onResize(event?);
        private getWindowSize();
        overrideAspect(stageWidth: number, stageHeight: number, visibleWidth?: number, visibleHeight?: number): void;
        private preventDefault(event);
        private animate();
        readonly stage: PStage;
        readonly stageWidth: number;
        readonly stageHeight: number;
    }
}
declare namespace gpts.abstract_games {
    import GameLoader = gamy.GameLoader;
    import MessagesFacade = gpts.services.MessagesFacade;
    import LoaderEvent = gamy.LoaderEvent;
    import Message = gpts.services.Message;
    class GameProxy extends IGame {
        protected _iData: any;
        protected _subscribed: boolean;
        protected _settings: any;
        protected _loader: GameLoader;
        protected messages_facade: MessagesFacade;
        private _filtered;
        constructor(iData: any);
        onRegister(): void;
        getSettings(): void;
        protected configureListeners(add?: boolean): void;
        protected onErrorLoadingGameInterface(event: LoaderEvent): void;
        protected onLoadGameInterface(event: LoaderEvent): void;
        protected launchGame(): void;
        onRemove(): void;
        interests(): string;
        gameType(): string;
        isVisible(): boolean;
        handleTimeoutMessage(message: Message): void;
        eventHandler(event: any): void;
        setData(value: Object): void;
        supportPortrait(): boolean;
        readonly settings: any;
        readonly hasSettings: boolean;
        readonly subscribed: boolean;
        readonly iData: Object;
        protected readonly _facade: AppFacade;
        readonly currentState: string;
        readonly canContinueAfterFailure: boolean;
        filtered(): boolean;
    }
}
declare namespace gpts.services.messages.request {
    class BetRequest extends GameRequest {
        bet: any;
        constructor(command?: string, sessionKey?: string, gameIdentificationNumber?: number, gameNumber?: number, bet?: any, qName?: string);
        toString(): string;
    }
}
declare namespace gpts.abstract_games.b_h_slot {
    class EBHSlotMessage {
        static IDLE: string;
        static JACKPOT: string;
        static SET_RESULT: string;
        static SET_CHOICE: string;
    }
}
declare namespace gpts.abstract_games.b_h_slot {
    import GameEventResponse = gpts.services.messages.response.GameEventResponse;
    import Hash = gamy.Hash;
    import Message = gpts.services.Message;
    class BHSlotProxy extends GameProxy {
        protected current_state: string;
        protected game_number: number;
        protected subscribe_response: GameEventResponse;
        static cachedData: Hash;
        constructor(iData: any);
        eventHandler(event: any): void;
        handleTimeoutMessage(message: Message): void;
        readonly currentState: string;
        setData(value: any): void;
        readonly subscribeResponse: GameEventResponse;
        readonly canContinueAfterFailure: boolean;
    }
}
declare namespace gpts.abstract_games.a_r_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class ARJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_a_r_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FARJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.b_h_slot {
    import INotification = puremvc.INotification;
    class BHSlotMediator extends GameMediator {
        constructor(gameType: string);
        handleNotification(notification: INotification): void;
    }
}
declare namespace gpts.abstract_games.f_a_r_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FARJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.a_r_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class ARJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.c_d_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class CDJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.c_d_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class CDJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.b_h_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class BHJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.b_h_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class BHJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.b_h_s_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class BHSJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.b_h_s_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class BHSJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts {
    class Alert {
        private static TYPE_LABELS_ARRAY;
        private static _initialized;
        private static _container;
        private static _counter;
        constructor();
        static init(): void;
        private static overwriteCSSByMini();
        static show(text: string, type?: number, options?: any): void;
    }
    enum PopUpType {
        OK = 0,
        OK_EXIT = 1,
        EXIT_RELOAD = 2,
    }
}
declare namespace gpts.abstract_games.r_o_r_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class RORJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.r_o_r_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class RORJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.r_o_r_e_q_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class ROREQSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.r_o_r_e_q_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class ROREQSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.e_p_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class EPJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.e_p_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class EPJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.f_h_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FHJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.f_h_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FHJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_d_h_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FDHJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.f_d_h_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FDHJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.t_s_h_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class TSHJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.t_s_h_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class TSHJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.u_h_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class UHJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.u_h_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class UHJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_k_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FKJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_k_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FKJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.z_w_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class ZWJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.z_w_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class ZWJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.s_c_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class SCJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.s_c_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class SCJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.f_s_h_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FSHJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_s_h_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FSHJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.n_d_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class NDJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.n_d_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class NDJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.b_d_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class BDJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.b_d_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class BDJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.a_o_t_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class AOTJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.a_o_t_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class AOTJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.r_s_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class RSJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.r_s_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class RSJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.a_a_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class AAJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.a_a_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class AAJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.b_o_m_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class BOMJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.b_o_m_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class BOMJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.c_m_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class CMJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.c_m_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class CMJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.b_h_t_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class BHTJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.b_h_t_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class BHTJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.k_g_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class KGJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.k_g_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class KGJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.h_c_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class HCJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.h_c_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class HCJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.c_h_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class CHJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.c_h_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class CHJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.s_t_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class STJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.s_t_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class STJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.t_d_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class TDJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.t_d_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class TDJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.a_b_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class ABJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.a_b_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class ABJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.e_h_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class EHJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.e_h_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class EHJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.l_h_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class LHJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.l_h_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class LHJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.s_p_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class SPJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.s_p_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class SPJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.c_b_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class CBJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.c_b_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class CBJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.b_r_d_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class BRDJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.b_r_d_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class BRDJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.s_h_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class SHJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.s_h_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class SHJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.r_w_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class RWJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.r_w_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class RWJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.f_s_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FSJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_s_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FSJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.s_b_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class SBJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.s_b_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class SBJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.m_p_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class MPJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.m_p_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class MPJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.blackjack {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class BlackjackProxy extends BHSlotProxy {
        constructor(iData: any);
        supportPortrait(): boolean;
    }
}
declare namespace gpts.abstract_games.blackjack {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class BlackjackMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.f_b_h_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FBHJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_b_h_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FBHJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.w_t_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class WTJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.w_t_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class WTJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.t_w_w_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class TWWJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.t_w_w_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class TWWJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.i_g_t_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class IGTJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.i_g_t_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class IGTJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.t_s_f_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class TSFJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.t_s_f_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class TSFJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.o_c_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class OCJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.o_c_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class OCJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.d_r_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class DRJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.d_r_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class DRJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.c_i_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class CIJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.c_i_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class CIJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.w_c_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class WCJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.w_c_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class WCJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.f_h_s_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FHSJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_h_s_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FHSJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.q_o_r_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class QORJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.q_o_r_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class QORJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.h_s_h_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class HSHJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.h_s_h_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class HSHJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.f_m_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FMJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_m_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FMJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.t_b_h_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class TBHJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.t_b_h_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class TBHJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_d_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FDJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_d_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FDJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.f_b_h_t_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FBHTJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_b_h_t_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FBHTJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.g_e_t_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class GETJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.g_e_t_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class GETJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.t_b_j_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class TBJJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.t_b_j_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class TBJJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.m_s_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class MSJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.m_s_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class MSJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.f_h_d_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FHDJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_h_d_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FHDJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.t_d_r_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class TDRJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.t_d_r_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class TDRJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.d_o_r_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class DORJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.d_o_r_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class DORJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.h_d_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class HDJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.h_d_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class HDJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.f_b_d_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FBDJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_b_d_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FBDJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.t_b_d_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class TBDJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.t_b_d_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class TBDJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.r_t_s_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class RTSJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.r_t_s_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class RTSJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.s_d_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class SDJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.s_d_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class SDJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.m_b_h_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class MBHSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.m_b_h_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class MBHSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.m_s_h_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class MSHSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.m_s_h_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class MSHSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.m_u_h_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class MUHSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.m_u_h_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class MUHSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.t_h_s_d_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class THSDJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.t_h_s_d_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class THSDJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.a_s_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class ASJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.a_s_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class ASJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.f_b_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FBJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_b_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FBJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.c_r_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class CRJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.c_r_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class CRJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.d_q_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class DQJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.d_q_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class DQJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.e_s_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class ESJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.e_s_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class ESJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.l_b_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class LBJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.l_b_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class LBJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.t_s_o_a_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class TSOAJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.t_s_o_a_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class TSOAJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.casino_battle {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class CasinoBattleProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.casino_battle {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class CasinoBattleMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.p_s_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class PSJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.p_s_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class PSJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.m_f_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class MFJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.m_f_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class MFJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.o_g_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class OGJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.o_g_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class OGJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.g_o_c_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class GOCJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.g_o_c_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class GOCJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.r_q_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class RQJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.r_q_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class RQJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.v_g_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class VGJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.v_g_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class VGJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.v_n_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class VNJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.v_n_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class VNJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.a_g_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class AGJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.a_g_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class AGJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.r_l_t_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class RLTJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.r_l_t_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class RLTJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.j_p_j_poker {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class JPJPokerMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.j_p_j_poker {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class JPJPokerProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.j_o_b_j_poker {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class JOBJPokerMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.j_o_b_j_poker {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class JOBJPokerProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_o_k_b_j_poker {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FOKBJPokerMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.f_o_k_b_j_poker {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FOKBJPokerProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.h_w_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class HWJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.h_w_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class HWJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.r_d_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class RDJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.r_d_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class RDJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.f_b_h_s_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FBHSJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_b_h_s_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FBHSJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.d_a_r_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class DARJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.d_a_r_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class DARJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.f_h_n_c_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FHNCJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_h_n_c_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FHNCJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.x_s_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class XSJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.x_s_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class XSJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.x_j_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class XJJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.x_j_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class XJJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.r_m_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class RMJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.r_m_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class RMJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.g_o_l_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class GOLJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.g_o_l_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class GOLJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.t_b_h_t_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class TBHTJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.t_b_h_t_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class TBHTJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.h_n_c_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class HNCJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.h_n_c_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class HNCJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.l_a_w_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class LAWJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.l_a_w_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class LAWJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.m_l_a_w_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class MLAWJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.m_l_a_w_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class MLAWJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.m_d_a_r_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class MDARJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.m_d_a_r_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class MDARJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.w_h_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class WHJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.w_h_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class WHJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.s_o_a_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class SOAJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.s_o_a_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class SOAJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.t_s_o_l_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class TSOLJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.t_s_o_l_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class TSOLJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.a_p_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class APJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.a_p_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class APJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.d_g_r_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class DGRJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.d_g_r_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class DGRJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.v_d_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class VDJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.v_d_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class VDJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.t_e_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class TEJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.t_e_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class TEJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.f_r_s_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FRSJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_r_s_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FRSJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.j_a_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class JAJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.j_a_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class JAJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.k_l_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class KLJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.k_l_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class KLJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.f_l_k_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FLKJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_l_k_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FLKJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.f_m_c_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FMCJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_m_c_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FMCJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.h_b_h_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class HBHJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.h_b_h_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class HBHJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.l_a_d_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class LADJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.l_a_d_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class LADJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.m_l_a_d_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class MLADJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.m_l_a_d_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class MLADJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.g_e_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class GEJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.g_e_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class GEJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.p_q_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class PQJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.p_q_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class PQJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.i_w_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class IWJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.i_w_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class IWJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.i_m_d_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class IMDJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.i_m_d_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class IMDJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.b_c_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class BCJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.b_c_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class BCJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.g_a_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class GAJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.g_a_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class GAJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.s_l_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class SLJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.s_l_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class SLJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.t_d_h_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class TDHJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.t_d_h_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class TDHJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.g_e_o_l_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class GEOLJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.g_e_o_l_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class GEOLJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.s_c_h_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class SCHJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.s_c_h_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class SCHJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_s_d_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FSDJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.f_s_d_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FSDJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_g_s_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FGSJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.f_g_s_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FGSJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_a_b_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FABJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_a_b_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FABJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.o_r_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class ORJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.o_r_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class ORJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.l_r_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class LRJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.l_r_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class LRJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.t_s_d_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class TSDJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.t_s_d_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class TSDJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.d_h_i_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class DHIJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.d_h_i_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class DHIJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_u_r_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FURJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.f_u_r_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FURJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.t_j_r_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class TJRJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.t_j_r_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class TJRJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.t_s_w_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class TSWJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.t_s_w_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class TSWJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.g_t_s_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class GTSJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.g_t_s_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class GTSJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.roulette {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class RouletteMediator extends BHSlotMediator {
        constructor(gameType: string);
        handleNotification(note: puremvc.Notification): void;
    }
}
declare namespace gpts.abstract_games.roulette {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class RouletteProxy extends BHSlotProxy {
        private _currBet;
        private _betEventDate;
        constructor(iData: any);
        setData(value: any): void;
        eventHandler(event: any): void;
        updateSubscribeRemainingTime(): void;
        private updateSubscribe(value);
    }
}
declare namespace gpts.services.messages.response.roulette {
    class RouletteEventResponse extends GameEventResponse {
        protected win_number: number;
        protected win_bets: any;
        protected lose_bets: any;
        protected _remaining: number;
        constructor(command?: string, eventTimestamp?: number, msg?: string, complex?: any, reason?: string, gameIdentificationNumber?: any, gameNumber?: number, state?: string, winAmount?: number, winNumber?: number, winBets?: any, loseBets?: any, remaining?: number, qName?: string);
        winNumber: number;
        winBets: any;
        loseBets: any;
        remaining: number;
        toString(): string;
    }
}
declare namespace gpts.services.messages.response.roulette {
    class RouletteRecoverResponse extends RecoverResponse {
        protected win_number: number;
        protected win_bets: any;
        protected lose_bets: any;
        constructor(command?: string, eventTimestamp?: number, msg?: string, complex?: any, reason?: string, gameIdentificationNumber?: any, gameNumber?: number, gameRecoveryType?: string, winAmount?: number, credit?: number, winNumber?: number, winBets?: any, loseBets?: any, qName?: string);
        winNumber: number;
        winBets: any;
        loseBets: any;
        toString(): string;
    }
}
declare namespace gpts.services.messages.response.roulette {
    class RouletteSubscribeComplex extends Message {
        protected current_state: RouletteEventResponse;
        protected _statistics: any;
        protected _history: any;
        constructor(command?: string, currentState?: RouletteEventResponse, statistics?: any, history?: any);
        currentState: RouletteEventResponse;
        statistics: any;
        history: any;
        toString(): string;
    }
}
declare namespace gpts.services.messages.response.roulette {
    class RouletteSubscribeResponse extends GameResponse {
        constructor(command?: string, eventTimestamp?: number, msg?: string, complex?: any, reason?: string, gameIdentificationNumber?: any, gameNumber?: number, qName?: string);
    }
}
declare namespace gpts.abstract_games.f_j_f_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FJFJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.f_j_f_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FJFJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.t_h_b_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class THBJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.t_h_b_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class THBJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.e_o_w_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class EOWJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.e_o_w_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class EOWJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.h_s_d_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class HSDJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.h_s_d_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class HSDJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.b_d_i_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class BDIJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.b_d_i_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class BDIJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.r_b_d_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class RBDJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.r_b_d_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class RBDJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.m_d_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class MDJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.m_d_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class MDJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_t_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FTJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.f_t_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FTJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.d_s_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class DSJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.d_s_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class DSJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.a_m_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class AMJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.a_m_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class AMJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.r_g_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class RGJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.r_g_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class RGJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.c_r_b_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class CRBJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.c_r_b_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class CRBJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.i_d_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class IDJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.i_d_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class IDJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_h_e_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class FHEJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.f_h_e_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class FHEJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.a_d_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class ADJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.a_d_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class ADJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.r_l_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class RLJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.r_l_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class RLJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.i_v_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class IVJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.i_v_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class IVJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.k_h_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class KHJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.k_h_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class KHJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.v_w_j_slot {
    import BHSlotProxy = gpts.abstract_games.b_h_slot.BHSlotProxy;
    class VWJSlotProxy extends BHSlotProxy {
        constructor(iData: any);
    }
}
declare namespace gpts.abstract_games.v_w_j_slot {
    import BHSlotMediator = gpts.abstract_games.b_h_slot.BHSlotMediator;
    class VWJSlotMediator extends BHSlotMediator {
        constructor(gameType: string);
    }
}
declare namespace gpts.abstract_games.lottery {
    import GameEventResponse = gpts.services.messages.response.GameEventResponse;
    import Hash = gamy.Hash;
    import Message = gpts.services.Message;
    class LotteryProxy extends GameProxy {
        protected current_state: string;
        protected game_number: number;
        protected subscribe_response: GameEventResponse;
        static cachedData: Hash;
        constructor(iData: any);
        eventHandler(event: any): void;
        handleTimeoutMessage(message: Message): void;
        readonly currentState: string;
        setData(value: any): void;
        readonly subscribeResponse: GameEventResponse;
        readonly canContinueAfterFailure: boolean;
    }
}
declare namespace gpts.abstract_games.lottery {
    import INotification = puremvc.INotification;
    class LotteryMediator extends GameMediator {
        constructor(gameType: string);
        handleNotification(notification: INotification): void;
    }
}
declare namespace gpts.abstract_games.lotto_five_thirty_five {
    import LotteryProxy = gpts.abstract_games.lottery.LotteryProxy;
    class LottoFiveThirtyFiveProxy extends LotteryProxy {
        private _betEventDate;
        private _appReady;
        private _startMsg;
        private _subscribeTime;
        constructor(iData: any);
        setData(value: any): void;
        protected handleSubscribe(value: any): void;
        protected handleEvent(value: any): void;
        protected handleDefaultEvent(value: any): void;
        clearStartMsg(): void;
        private sendStart();
        eventHandler(event: any): void;
        startGame(): void;
    }
}
declare namespace gpts.abstract_games.lotto_five_thirty_five {
    import LotteryMediator = gpts.abstract_games.lottery.LotteryMediator;
    class LottoFiveThirtyFiveMediator extends LotteryMediator {
        constructor(gameType: string);
        listNotificationInterests(): string[];
        handleNotification(note: puremvc.Notification): void;
    }
}
declare namespace gpts {
    class StageInfo {
        private static readonly MiniWidth;
        private static readonly MiniHeight;
        private static readonly MobWidth;
        private static readonly MobHeight;
        private static readonly MobWidthIPhoneX;
        static readonly isTallDevice: boolean;
        static readonly width: number;
        static readonly height: number;
        static readonly visibleWidth: number;
        static readonly visibleHeight: number;
        static readonly landscapeWidth: number;
        static readonly landscapeHeight: number;
        static readonly landscapeVisibleWidth: number;
        static readonly landscapeVisibleHeight: number;
    }
}
declare var DEBUG: boolean;
declare var VERSION: string;
declare var BUILD: number;
declare var BUILD_DATE: string;
declare var MINI: boolean;
declare var MOB: boolean;
declare namespace gpts {
    import UncaughtErrorsHandler = egtLibrary.UncaughtErrorsHandler;
    class Main {
        static PLATFORM: string;
        static CONTENT: string;
        static GAME_INTERFACE: string;
        static CANVAS_ID: string;
        static EGT: string;
        protected _handleError: UncaughtErrorsHandler;
        constructor(options?: any);
        protected handleUncaughtErrors(): void;
        protected sendStatisticUsage(): void;
        protected onUncaughtError(e: any): void;
    }
    enum Environment {
        desktop = 0,
        mobile = 1,
        mini = 2,
    }
    function environment(): Environment;
}
