function Config()
{
    this.reelWidth = 132 ;
    this.reelHeight = 396;
    this.reelSpacing = 16;

    this.portraitReelWidth = 96;
    this.portraitReelSpacing = 12;

    this.numImages = 11;
    this.numReels = 5;
    this.numReelCards = 3;
    this.wildIndex = 8;
    this.linesCount = [1, 2, 3, 4, 5];
    this.fixedLinesCount = true;
    this.iOSSelectedElements = ['#PaytableContent .paytableLine'];
    this.coinAnimationCoef = 25;

    this.linesSelectActiveColor = 0xffff00;
    this.linesSelectInactiveColor = 0xffffff;
    this.linesSelectActiveGlowColor = 0xbf0000;
    this.linesSelectInactiveGlowColor = 0x303030;
    this.gameNumberTimeHelpColor = 0x74a81e;
    this.labelsColor = 0xffee32;
    this.paytableExitColor = 0x02323c;
    this.bonusPopUpStrokeColor = 0xbcba1b;

    this.toolTipMainTextColor = 0xFFFFFF;
    this.toolTipUsernameTextColor = 0xebf460;
    this.toolTipWinAmountTextColor = 0xFFFFFF;
    this.toolTipCurrencyTextColor = 0xebf460;
    this.toolTipDateTextColor = 0xbfbfbf;
    this.toolTipNumberOfWinnersTextColor = 0xebf460;
    this.toolTipDateSeparator = "/";

    this.landscapeReelsBackgroundPosition = {x: 56, y: 53}
    this.portraitReelsBackgroundPosition = {x: 3, y: 142}

    this.paytablePageCount = 4;
    this.paytableGamblePage = 1;

    this.portraitGameNameBackgroundColor = '#024b1e'
    this.gambleBackgroundBorderColor = 0xc1b916
    this.jackpotBackgroundColorStart = '#000000';
    this.jackpotBackgroundColorEnd = '#007939';
    this.jackpotBackgroundBorderColor = '#C1B916';

    this.scatterConfig  = [
        {index: 9, minCount: 3, validReels: [ true, false, true, false, true ],
            stopSounds:["stopScatterSound", null, "stopScatterSound", null, "stopScatterSound"]},
        {index: 10, minCount: 3, validReels: [ true, true, true, true, true ],
            stopSounds:["stopScatterSound", "stopScatterSound", "stopScatterSound", "stopScatterSound", "stopScatterSound"]}];

    this.reelVideos = [
        {src:["images/videos/00-0.json"], fps: 8, loopIndex: 23},
        {src:["images/videos/01-0.json"], fps: 8, loopIndex: 23},
        {src:["images/videos/02-0.json"], fps: 8, loopIndex: 23},
        {src:["images/videos/03-0.json"], fps: 8, loopIndex: 23},
        {src:["images/videos/04-0.json"], fps: 8, loopIndex: 23},
        {src:["images/videos/05-0.json"], fps: 8, loopIndex: 23},
        {src:["images/videos/06-0.json"], fps: 8, loopIndex: 23},
        {src:["images/videos/07-0.json"], fps: 8, loopIndex: 23},
        {src:["images/videos/08-0.json"], fps: 8, loopIndex: 23},
        {src:["images/videos/09-0.json"], fps: 8, loopIndex: 23},
        {src:["images/videos/10-0.json"], fps: 8, loopIndex: 23}];

    this.expandVideo = {src:["images/videos/expand.json"], fps: 8, scale: 1};

    this.reelImages = ["reelImages.json"];

    this.linesCoords = [
        {coords:[124,256, 835,256], color:0xfff221},
        {coords:[124,124, 835,124], color:0xf9af0c},
        {coords:[124,394, 835,394], color:0x17e614},
        {coords:[124,123, 183,123, 480,448, 775,123, 835,123], color:0xdf3d3d},
        {coords:[124,408, 183,408, 480,79, 775,408, 835,408], color:0xc90404}
    ];

    this.fullLineSounds = [
        {card:0, name:"fullLine1"}, {card:1, name:"fullLine1"},
        {card:2, name:"fullLine1"}, {card:3, name:"fullLine1"},
        {card:4, name:"fullLine2"}, {card:5, name:"fullLine3"},
        {card:6, name:"fullLine3"}, {card:7, name:"fullLine4"}];

    this.gameSounds = [
        {
            src: "shortSounds.mp3", sounds:[
                {name: "stopWildSound", start:0, duration: 0.6},
                {name: "stopScatterSound", start:1, duration: 0.4}]
        },
        {
            src: "winSounds.mp3", sounds:[
                {name: "win0", start:0, duration: 1.4},
                {name: "win1", start:2, duration: 1.7},
                {name: "win2", start:4, duration: 2.25},
                {name: "win3", start:7, duration: 1.65},
                {name: "win4", start:9, duration: 2.1},
                {name: "win5", start:12, duration: 1.5},
                {name: "win6", start:14, duration: 2.1},
                {name: "win7", start:17, duration: 2.7},
                {name: "win9", start:20, duration: 4.4},
                {name: "win10", start:25, duration: 1.75},
                {name: "creditAnimationSound", start:27, duration: 10.0},
                {name: "expandSound", start:38, duration: 1.2}]
        }];

    this.helpLanguages = ["en", "bg", "ro", "es", "pt", "it", "da", "sv", "cs", "ru", "de", "el"];
    this.paytableLanguages = ['en', 'bg', 'ru', 'mk', 'fr', 'nl', 'es','ro', "pt", 'it','da','hu','sv','de', 'cs', 'el'];
}

window["egtGlobal"].Config = Config;
